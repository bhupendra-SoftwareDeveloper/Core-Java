package list;
import java.util.ArrayList;
import java.util.Iterator;
public class ArrayListProg
{
	void m1()
	{
		System.out.println("------------Implementing ArrayList------------");
		ArrayList <Object>al=new ArrayList<Object>();
		al.add(10);
		al.add(55);
		al.add(75);
		al.add("Java");
		al.add(null);
		al.add(96);
		al.add(12);
		al.add(10);
		System.out.println(al.size());
	//	al.clear();
	//	System.out.println(al.size());
		System.out.println("contains(): "+al.contains(55));
		System.out.println(al);
		al.add(4, 69);//to add in between
		System.out.println(al);
		System.out.println(al.remove((Object)10));
		System.out.println(al);
		System.out.println("get(): "+al.get(6));//for retrieving
		
		System.out.println("Retriving using size() & get(): ");
		for(int i=0;i<al.size();i++)
			System.out.println(al.get(i));
		
		System.out.println("Remove(): "+al.remove(4));
		System.out.println(al);
		System.out.println("Retriving using for loop: ");
		System.out.println("using int: ");
	//	for(int x:al)System.out.println(x);
		
		System.out.println("using Integer: ");
	//	for(Integer x:al)System.out.println(x);
		
		System.out.println("using Object: ");
			for(Object x:al)System.out.println(x);
		
		System.out.println("Retriving using Iterator(): ");
		Iterator x=al.iterator();
		while(x.hasNext())
			System.out.println(x.next());
	}
	
	public static void main(String[] args)
	{
		new ArrayListProg().m1();	
	}
}
/*
----------------I.M.P-----------------------------------------------
 (1)Insertion Order maintained.
 (2)Null values allowed.
 (3)Available from 1.2v
 (4)NOT SYNCHRONIZED
 (5)Duplicate values are allowed
 (6)Default capacity is 10 if increase it becomes nearly half((current capacity*3/2)+1)
 (7)Hetrerogeneous data allowed
*/