package list;
import java.util.ArrayList;
import java.util.LinkedList;
public class ConstructionTime
{
	private static Object arr[];
	
	static {
		arr=new Object[100000];
		for(int i=0;i<arr.length;i++)
			arr[i]=new Object();
	}
	void arrayList()
	{
		long start,end;
		ArrayList <Object>al=new ArrayList<Object>();
		start=System.currentTimeMillis();
		for(Object x:arr)al.add(x);
		end=System.currentTimeMillis();
		System.out.println("Construction Time of ArrayList: "+(end-start));
	}
	void linkedList()
	{
		long start,end;
		LinkedList <Object>al=new LinkedList<Object>();
		start=System.currentTimeMillis();
		for(Object x:arr)al.add(x);
		end=System.currentTimeMillis();
		System.out.println("Construction Time of LinkedList: "+(end-start));
	}
	public static void main(String[] args)
	{
		ConstructionTime ct=new ConstructionTime();
		ct.arrayList();
		ct.linkedList();
	}
}
