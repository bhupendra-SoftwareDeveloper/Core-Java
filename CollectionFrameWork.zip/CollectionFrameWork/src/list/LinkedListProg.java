package list;
import java.util.LinkedList;
import java.util.ListIterator;
public class LinkedListProg
{
	void m1()
	{
		LinkedList<Object> ll=new LinkedList<Object>();
		ll.add(10);
		ll.add("Java");
		ll.add(null);
		ll.add(85);
		ll.add(12);
		ll.add(96);
		ll.add(22);
		ll.add(10);
		ll.add(45);
		
		System.out.println(ll);
		ListIterator<Object> li=ll.listIterator();
		System.out.println("------Forward direction------");
		while(li.hasNext())
			System.out.println(li.next());
		System.out.println("------Backward direction------");
		while(li.hasPrevious())
			System.out.println(li.previous());
		
		System.out.println("removeFirst(): "+ll.removeFirst());
		System.out.println("removeLast(): "+ll.removeLast());
		System.out.println("getFirst(): "+ll.getFirst());
		System.out.println("getLast(): "+ll.getLast());
		ll.addFirst("Linked");
		ll.addLast("List");
		System.out.println(ll);
	}
	public static void main(String[] args)
	{
		new LinkedListProg().m1();
	}
}

/*
----------------I.M.P-----------------------------------------------
 (1)Insertion Order maintained.
 (2)Null values allowed.
 (3)Available from 1.2v
 (4)NOT SYNCHRONIZED
 (5)Duplicate values are allowed
 (6)Default capacity is 0 if increase it becomes double
 (7)Hetrerogeneous data allowed
 (8)Data stored in form of node
*/