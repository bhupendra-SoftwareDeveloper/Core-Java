package list;

import java.util.ArrayList;
public class RetrieveList
{
	public static void main(String[] args) {
	ArrayList<String>a=new ArrayList<String>();
	a.add("core java");
	a.add("advanced java");
	a.add("hibernate");
	a.add("spring");
	a.add("project");
	System.out.println("List Contains:"+a);
	System.out.println("Retrieve List Element by Using Basic For Loop");
	int size=a.size();
	for(int i=0;i<size;i++)
		System.out.println(a.get(i));
	
	System.out.println("Retrieve List Element by Using Enhanced For Loop");
	for(String s:a)
		System.out.println(s);
	System.out.println("Retrieve List Element by While Loop");
	int x=0;
	while(a.size()>x)
	{
		System.out.println(a.get(x));
		x++;	
	}
 }
}
