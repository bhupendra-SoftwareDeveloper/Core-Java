package list;
import java.util.Vector;
import java.util.Enumeration;
public class VectorProg
{
	void m1()
	{
		System.out.println("--------------Implementing Vector--------------");
		Vector <Object>v=new Vector<Object>();
		v.add(10);
		v.add("Java");
		v.add(null);
		v.add(85);
		v.add(1);
		v.add(96);
		v.add(10);
		
		System.out.println(v);
		System.out.println("-------------Using for loop-------------");
		for(int i=0;i<v.size();i++)
			System.out.println(v.get(i));
		
		System.out.println("-------------Using for Enumration-------------");
		Enumeration ev=v.elements();
		while(ev.hasMoreElements())
			System.out.println(ev.nextElement());
		
		v.addElement("Java is awesome");
		v.removeElement(1);
		System.out.println("-----------------------------------------");
		System.out.println(v);
		v.removeElementAt(0);
		System.out.println("After performing removeElementAt(): "+v);
		System.out.println("elementAt(): "+v.elementAt(3));
		System.out.println("lastElement(): "+v.lastElement());
		System.out.println("firstElement(): "+v.firstElement());
		v.removeAllElements();
		System.out.println("After performing removeAllElements(): "+v);

	}
	public static void main(String[] args)
	{
		new VectorProg().m1();
	}
}

/*
----------------I.M.P-----------------------------------------------
 (1)Insertion Order maintained.
 (2)Null values allowed.
 (3)Available from 1.0v
 (4)SYNCHRONIZED
 (5)Duplicate values are allowed
 (6)Default capacity is 10 if increase it becomes double
 (7)Hetrerogeneous data allowed
*/