package map_Root_Interface;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
public class HashMapProg
{
    void meth1()
    {
        System.out.println("Implementing Map Interface");
       
        HashMap map=new HashMap(); // Insertion order is not maintained
       
        map.put(101,"Java"); // Heterogeneous Keys & Heterogeneous values are allowed
        map.put("Java",5000);// null Keys & null values are allowed
        map.put(null,null); // Duplicate values are allowed
        map.put(102,"Python");// Duplicate Keys are not allowed
        map.put(103,5000);// It is available from Java 1.2v
        map.put(104,"HTMl"); // Default capacity : 16 & Load factor  is 0.75
        map.put(105,"CSS"); //It is NOT SYNCHRONIZED
        System.out.println(map);
        map.put(105, "Kishan");
        System.out.println(map);
        System.out.println("===================================");
        
        System.out.println("containsKey(): "+map.containsKey(105));
        System.out.println("containsValue(): "+map.containsValue("Java"));
        
        System.out.println("get(): "+map.get(105));
        System.out.println("===================================");
        HashSet hs1=new HashSet(map.keySet());
        System.out.println("Keys : "+hs1);
        map.remove(105);
        System.out.println("-----------------After remove()-----------------");
        HashSet hs2=new HashSet(map.entrySet());
        System.out.println("Entries : "+hs2);
        System.out.println("===================================");
       
        Iterator i=hs2.iterator();
        while(i.hasNext())
        {
            System.out.println(i.next());
            //Entry e=(Entry)i.next();
            //System.out.println(e.getKey()+"      "+e.getValue());
        }   
    }
    public static void main(String[] args)
    {
        new HashMapProg().meth1();   
    }
}