package map_Root_Interface;
import java.util.Hashtable;

public class HashTableProg
{
    void meth1()
    {
        System.out.println("Implementing Map Interface");
       
       
        Hashtable map=new Hashtable(); // Insertion order is not maintained
        map.put(101,"Java"); // Heterogeneous Keys are allowed & Heterogeneous values are allowed
        map.put("Java",5000);// null Keys & null values are NOT allowed
        map.put(50,1000); // Duplicate values are allowed
        map.put(102,"Python");// Duplicate Keys are not allowed
        map.put(103,5000);// It is available from Java 1.0v
        map.put(104,"HTMl"); // Default capacity : 16 & Load factor  is 0.75
        map.put(105,"CSS"); //It is  SYNCHRONIZED
        System.out.println(map);
        map.put(105, "Kishan");
        System.out.println(map);    
    }
    public static void main(String[] args)
    {
        new HashTableProg().meth1();        
    }
}