package map_Root_Interface;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map.Entry;

public class LinkedHashMapProg
{
    void meth1()
    {
        System.out.println("Implementing Map Interface");
       
        LinkedHashMap map=new LinkedHashMap(); // Insertion order is maintained in LHM (Java 1.4)
       
        map.put(101,"Java"); // Heterogeneous Keys & Heterogeneous values are allowed
        map.put("Java",5000);// null Keys & null values are allowed
        map.put(null,null); // Duplicate values are allowed
        map.put(102,"Python");// Duplicate Keys are not allowed
        map.put(103,5000);// It is available from Java 1.4v
        map.put(104,"HTMl"); // Default capacity : 16 & Load factor  is 0.75
        map.put(105,"CSS"); //It is NOT SYNCHRONIZED
        System.out.println(map);
        map.put(105, "Kishan");
        System.out.println(map);
        System.out.println("===================================");
       
        HashSet hs1=new HashSet(map.keySet());
        System.out.println("Keys : "+hs1);
       
        HashSet hs2=new HashSet(map.entrySet());
        System.out.println("Entries : "+hs2);
        System.out.println("===================================");
       
        Iterator i=hs2.iterator();
        while(i.hasNext())
        {
            System.out.println(i.next());
            //Entry e=(Entry)i.next();
            //System.out.println(e.getKey()+"      "+e.getValue());
        }
        System.out.println("===================================");
       
        LinkedHashSet lhs=new LinkedHashSet(map.entrySet());
        Iterator i2=lhs.iterator();
        while(i2.hasNext())
        {
            Entry e=(Entry)i2.next();
            System.out.println(e.getKey()+"      "+e.getValue());
        }
    }
    public static void main(String[] args)
    {
        new LinkedHashMapProg().meth1();   
    }
}