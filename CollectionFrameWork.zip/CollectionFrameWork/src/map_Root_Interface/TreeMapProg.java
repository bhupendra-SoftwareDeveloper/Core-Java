package map_Root_Interface;

import java.util.TreeMap;

public class TreeMapProg
{
    void meth1()
    {
        System.out.println("Implementing Map Interface");
        TreeMap map=new TreeMap(); // Insertion order is not maintained  BUT sorting order of Keys is maintained    
        map.put(101,"Java"); // Heterogeneous Keys are not allowed BUT Heterogeneous values are allowed
      //  map.put(null, "Hii");
        map.put(50,5000);// null Keys are not BUt null values are allowed
        map.put(80,null); // Duplicate values are allowed
        map.put(102,"Python");// Duplicate Keys are not allowed
        map.put(103,5000);// It is available from Java 1.2v
        map.put(104,"HTMl"); // Default capacity : 16 & Load factor  is 0.75
        map.put(105,"CSS"); //It is NOT SYNCHRONIZED
        System.out.println(map);
        map.put(105, "Kishan");
        System.out.println(map);    
    }
    public static void main(String[] args)
    {
        new TreeMapProg().meth1();        
    }
}