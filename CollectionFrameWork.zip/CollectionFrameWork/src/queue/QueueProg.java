package queue;
import java.util.Iterator;
import java.util.PriorityQueue;

public class QueueProg
{
	void m1()
	{
		PriorityQueue<Object> pq=new PriorityQueue<Object>();
		pq.offer(45);
	//	pq.offer("Java");
	//	pq.offer(null);
		pq.offer(45);
		pq.offer(78);
		pq.offer(4);
		pq.offer(12);
		pq.offer(78);
		System.out.println(pq);
		
		Iterator<Object> i=pq.iterator();
		System.out.println("Using while loop with iterator()");
		while(i.hasNext())
			System.out.println(i.next());
		
		System.out.println("poll(): "+pq.poll());
		System.out.println("after poll(): "+pq);
		System.out.println("remove(): "+pq.remove());
		System.out.println("after remove(): "+pq);
		System.out.println("peek(): "+pq.peek());
		System.out.println("after peek(): "+pq);
	}
	public static void main(String[] args)
	{
		new QueueProg().m1();
	}
}
/*
 ----------------I.M.P-----------------------------------------------
  (1)Insertion Order NOT maintained.
  (2)Null values NOT allowed.
  (3)Available from 1.5v
  (4)NOT SYNCHRONIZED
  (5)Duplicate values are allowed
  (6)Default capacity is 11 if increase it becomes double
  (7)LinkedList can implements both queue and list
  (8)Hetrerogeneous data NOT allowed
  (9)The first priority will goes to smallest data only for first element not others
*/