package set;
import java.util.Iterator;
import java.util.HashSet;

public class HashSetProg
{
	void m1()
	{
		HashSet<Object> hs=new HashSet<Object>();
		hs.add(45);
		hs.add("Java");
		hs.add(null);
		hs.add(45);
		hs.add(78);
		hs.add(4);
		hs.add(12);
		hs.add(78);
		System.out.println(hs);
		
		Iterator<Object> i=hs.iterator();
		System.out.println("Using while loop with iterator()");
		while(i.hasNext())
			System.out.println(i.next());
	}
	public static void main(String[] args)
	{
		new HashSetProg().m1();
	}
}
/*
 ----------------I.M.P-----------------------------------------------
  (1)Insertion Order NOT maintained.
  (2)Null values allowed.
  (3)Available from 1.2v
  (4)NOT SYNCHRONIZED
  (5)Duplicate values are not allowed
  (6)Default capacity is 16 if increase it becomes double
  (7)load factor:0.75
  (8)Hetrerogeneous data allowed
*/