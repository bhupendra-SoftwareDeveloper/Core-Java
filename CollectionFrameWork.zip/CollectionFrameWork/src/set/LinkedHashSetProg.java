package set;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetProg
{
	void m1()
	{
		LinkedHashSet<Object> lhs=new LinkedHashSet<Object>();
		lhs.add(45);
		lhs.add("Java");
		lhs.add(null);
		lhs.add(45);
		lhs.add(78);
		lhs.add(4);
		lhs.add(12);
		lhs.add(78);
		System.out.println(lhs);
		
		Iterator<Object> i=lhs.iterator();
		System.out.println("Using while loop with iterator()");
		while(i.hasNext())
			System.out.println(i.next());
	}
	public static void main(String[] args)
	{
		new LinkedHashSetProg().m1();
	}
}
/*
 ----------------I.M.P-----------------------------------------------
  (1)Insertion Order maintained.
  (2)Null values allowed.
  (3)Available from 1.4v
  (4)NOT SYNCHRONIZED
  (5)Duplicate values are not allowed
  (6)Default capacity is 16 if increase it becomes double
  (7)load factor:0.75
  (8)Hetrerogeneous data allowed
*/