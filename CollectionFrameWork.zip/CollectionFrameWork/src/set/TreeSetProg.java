package set;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetProg
{
	void m1()
	{
		TreeSet<Object> ts=new TreeSet<Object>();
		ts.add(45);
	//	lhs.add("Java");
	//	lhs.add(null);
		ts.add(45);
		ts.add(78);
		ts.add(4);
		ts.add(12);
		ts.add(78);
		System.out.println(ts);
		
		Iterator<Object> i=ts.iterator();
		System.out.println("Using while loop with iterator()");
		while(i.hasNext())
			System.out.println(i.next());
		
		System.out.println("headSet(): "+ts.headSet(45));
		System.out.println("tailSet(): "+ts.tailSet(45));
	}
	public static void main(String[] args)
	{
		new TreeSetProg().m1();
	}
}
/*
 ----------------I.M.P-----------------------------------------------
  (1)Insertion Order NOT maintained But Soting Order Maintained.
  (2)Null values NOT allowed.
  (3)Available from 1.2v
  (4)NOT SYNCHRONIZED
  (5)Duplicate values are not allowed
  (6)Default capacity is 16 if increase it becomes double
  (7)load factor:0.75
  (8)Hetrerogeneous data NOT allowed
  (9)It's work as balanced binary tree algorithm
*/