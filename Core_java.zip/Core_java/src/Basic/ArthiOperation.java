package Basic;

public class ArthiOperation 
{
	public void sub()
	{
		int a=20;
		int b=15;
		System.out.println("Subtraction of a&b="+(a-b));
		ArthiOperation op=new ArthiOperation();
		op.div();
		op.multi();
	}
	public void div()
	{
		int a=20;
		int b=10;
		int c;
		c=a/b;
		System.out.println("Division of a&b="+c);
	}
	public void multi()
	{
		int a=20;
		int b=15;
		System.out.println("Multiplication of a&b="+(a*b));
	}
	public static void main(String args[])
	{
		int a=20;
		int b=15;
		System.out.println("Subtraction of a&b="+(a-b));
		ArthiOperation op=new ArthiOperation();
		op.sub();
	}
}
