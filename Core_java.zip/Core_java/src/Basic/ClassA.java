package Basic;

public class ClassA 
{
	public int meth1(String s)
	{
		System.out.println("s");
		return 100;	
	}
	public int meth2(int a)
	{
		System.out.println("Meth2() called");
		return 10+a;
	}
	public int meth3(int a,int b)
	{
		System.out.println("Meth3() called");
		return a*b;
	}
	public static void main(String args[])
	{
		ClassA obj=new ClassA();
		obj.meth1("Java Is Awesome");
		
		int result=obj.meth2(5);
		System.out.println("Result="+result);
		
      	System.out.println("Meth3 is returning:"+obj.meth3(5,2));
	}
}
