package Basic;

public class ClassA0102 
{
	void m1() {
	System.out.println("Hello");
	}
}
