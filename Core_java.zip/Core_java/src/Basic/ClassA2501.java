package Basic;

public class ClassA2501 
{
	public void meth1()
	{
		System.out.println(10);
		System.out.println(64);
		System.out.println("End");
	}
	int meth2(int a,int b,int c)
	{
		System.out.println(a);
		ClassA2501 bob=new ClassA2501();
		String s=bob.meth5(100,"java is awesome");
		System.out.println(s);
		return a-b;
	}
	String meth3(String s,int b,int d)
	{
		System.out.println(b+d);
		return s;
	}
	int meth4(int c,int k)
	{
		System.out.println(k);
		ClassA2501 bob=new ClassA2501();
		int result=bob.meth2(50,50,50);
		System.out.println(result);
		return k+10;
	}
	String meth5(int a,String L)
	{
		System.out.println(a+a);
		ClassA2501 bob=new ClassA2501();
		String s=bob.meth3("Hii",5,10);
		System.out.println(s);
		return L;
	}
	public static void main(String args[])
	{
		ClassA2501 bob=new ClassA2501();
		System.out.println("START");
		int result=bob.meth4(20,10);
		System.out.println(result);
		bob.meth1();
	}
}
