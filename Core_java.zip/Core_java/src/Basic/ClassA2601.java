package Basic;

public class ClassA2601 
{
	void display()
	{
		System.out.println("HIII");
	}
	public static void main(String[] args) 
	{
		ClassA2601 obj=new ClassA2601();
		//obj.display();
		new ClassA2601().display();
	}
}
