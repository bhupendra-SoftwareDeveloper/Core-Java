package Basic;

public class ClassA2701 
{
	int meth1(int a,int b,char c)
	{
		System.out.println(c);
		int result=new ClassA2701().meth2("JAVA",100,'Y');
		return 10+a+result;
	}
	int meth2(String s,int a,char c)
	{
		System.out.println(s);
		System.out.println(c);
		return 20;
	}
	public static void main(String[] args) 
	{
		System.out.println(new ClassA2701().meth1(10,20,'X'));
	}
}
