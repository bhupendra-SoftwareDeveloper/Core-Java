package Basic;

 public class ClassB0102 
{
	public void m2()
	{
		System.out.println("hii");
	}
	public static void main(String[] args) {
		new ClassA0102().m1();
	}
}
