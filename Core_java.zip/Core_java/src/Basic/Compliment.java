package Basic;

public class Compliment
{
	  void m1()
	  {
	    int a=10;int b=-10;
		System.out.println("a1="+a);
		System.out.println("b2="+b);
		System.out.println("a3="+(~a));
		System.out.println("b4="+(~b));
		System.out.println("a="+(~++a));
	    System.out.println("b="+(~++b));
		System.out.println("a5="+(~a++));
		System.out.println("b6="+(~b++));
		int c=a;	
		System.out.println("c7="+c);
		System.out.println("c8="+(~c));
		System.out.println("c="+(~++c));
		System.out.println("c9="+(~c++));
	  }
	public static void main(String areg[])
	 {
	   new Compliment().m1();}
}
