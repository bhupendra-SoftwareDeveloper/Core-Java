package Basic;

public class Cricket 
{
	public void wide()
	{
	   System.out.println("You threw wide ball");	
	}

	public static void noball()
	{
	   System.out.println("You threw no ball");
	   Cricket ball=new Cricket();		//we can create same name object in other method in java programe
	   ball.wide();	
	}

	public void match()
	{
	   /*Cricket ball=new Cricket();*/
	   //noball();				//calling noball() method without creating object because noball() method is static if we not using 												static in no ball that time we have to create an object
	   Cricket.noball();			//we can use Class name.method name also when method is static
	   System.out.println("You are in match method");	

	}

	public static void main(String args[])
	{
	   System.out.println("You are in main method");
	   Cricket ball=new Cricket();				//creating a object
	   ball.match();					//calling match() method
	   System.out.println("You are again in main method");
	}
}
