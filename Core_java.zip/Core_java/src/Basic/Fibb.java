package Basic;

public class Fibb 
{
	public static void main(String args[])
	{
		int n=10,i,num1=0,num2=1,num3=0;
		/*int i;
		int num1=0;
		int num2=1;
		int num3=0;*/
		for(i=0;i<=10;i++)
		{
		
			System.out.println(num3);
			num1=num2;
			num2=num3;
			num3=num1+num2;
		}
	}
}
