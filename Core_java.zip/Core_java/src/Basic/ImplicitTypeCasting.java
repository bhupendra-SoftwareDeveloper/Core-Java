package Basic;

public class ImplicitTypeCasting 
{
	void implicit()
	{
		System.out.println("Performing Implicit Type Casting");
		byte b=50;
		int i=b;
		System.out.println("Byte value="+b);
		System.out.println("Int value="+i);
		System.out.println("-------------------------");
		char c='A';
		int x=c;
		System.out.println("Char value="+c);
		System.out.println("Int value="+x);
		System.out.println("M1 method() is returning="+new ImplicitTypeCasting().m1('a',3));
	}
	
	int m1(int a,int b)
	{
		System.out.println("M1 method called="+(a+b));
		return 'A';
	}
	void explicit()
	{
		System.out.println("Performing Expilicit Type Casting");
		int a=500;
		byte b=(byte)a;
		System.out.println("Int value="+a);
		System.out.println("Byte value="+b);
		System.out.println("----------------------------");
		float f=10.9999f;
		byte b2=(byte)f;
		System.out.println("float value="+f);
		System.out.println("Byte value="+b2);
	}
	
	public static void main(String[] args)
	{
		ImplicitTypeCasting aobj=new ImplicitTypeCasting();
		aobj.implicit();
		System.out.println("--------------------------------");
		aobj.explicit();
	}
}
