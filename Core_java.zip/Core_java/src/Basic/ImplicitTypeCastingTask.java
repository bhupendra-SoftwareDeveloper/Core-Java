package Basic;

public class ImplicitTypeCastingTask 
{
	void implicit()
	{
		byte b=10;
		System.out.println("Byte value is="+b);
		short s=b;
		System.out.println("Short value is="+s);
		s++;
		int i=s++;
		System.out.println("Int value is="+i);
		System.out.println("Short value is="+s);
		long l=i;
		System.out.println("Long value is="+(--l));
		float f=l;
		System.out.println("The value of Float is="+(f+b));
		double d=(--f);
		System.out.println(f);
		System.out.println("The value of double is="+d);
		show();
		
		if(!(d==f))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
	
	public static void main(String[] args)
	{
		ImplicitTypeCastingTask a=new ImplicitTypeCastingTask();
		a.implicit();
	}
	
	static void show()
	{
		char c='A';
		int a=++c;
		System.out.println(a);
		ImplicitTypeCastingTask obj=new ImplicitTypeCastingTask();
		String s=obj.m1();
		System.out.println(s);
	}
	
	String m1()
	{
		String s="Implicit Type Casting done by computer automatically";
		return s;
	}
}
