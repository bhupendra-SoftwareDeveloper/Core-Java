package Basic;

public class Modifier_28FEb_Aclass
{
	public void m1()
	{
		System.out.println("Hello this is Basic package, Modifier_28FEb class, m1() method");
	}
}
