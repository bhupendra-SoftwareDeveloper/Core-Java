package Basic;

public class NareshIT 
{
	int m1(){
	     int trainee_no=01;
	       String trainee_name="laxmi";
	         String tech="full stack java";
	           String trainee_status="good";
	          System.out.println(trainee_no);
	 return 0;
	   }
	 public static void main(String []args){
	        NareshIT nit=new NareshIT();
	            System.out.println(nit.m1());
	          //System.out.println(trainee_no);
	          // System.out.println(trainee_name);
	            //   System.out.println(nit.tech);
	              //    System.out.println//(nit.trainee_status);
	}
}
