package Basic;

public class Palindrome 
{
	public void Palindrome()
	{	
		int a,rem,rev=0;
		System.out.println("Number is 111");
		a=111;
		while(a!=0)
		{
			rem=a%10;
			rev=rev*10+rem;
			a/=10;
		}
		if(111==rev)
			System.out.println("Number 111 is Palindromedrome");
		else
      		   System.out.println("Number 111 is not Palindromedrome");
	}
	public static void main(String args[])
	{	
		int a,rem,rev=0;
		System.out.println("Number is 110");
		a=110;
		while(a!=0)
		{
			rem=a%10;
			rev=rev*10+rem;
			a/=10;
		}
		if(110==rev)
			System.out.println("Number 110 is Palindromedrome");
		else
      		   System.out.println("Number 110 is not Palindromedrome");
		Palindrome p=new Palindrome();
		p.Palindrome();
	}
}
