package Basic;

public class Prac 
{
	public void p()
	{
		System.out.println("Hello this is p method");
		Prac b=new Prac();
		b.meth2(9,5,"Java");
		System.out.println("Hello again");
		String result=b.meth3("Good","Best",100);
		System.out.println(result);
	}
	public int meth1(int a,String s,int b )
	{
		System.out.println("a="+a);
		return a*b;
	}
	public String meth2(int a,int b,String s)
	{
		System.out.println("Complex=="+(a*b/2));
		return s;
	}
	public String meth3(String s,String b,int a)
	{
		System.out.println(a+a+a*a);
		return s;	
	}
	public String meth4(String s,String b,String a)
	{
		System.out.println("This is meth4()");
		Prac c=new Prac();
		c.p();
		return s;	
	}
	public static void main(String args[])
	{
		System.out.println("I am starter");
		Prac b=new Prac();
		int result=b.meth1(12,"JavaScript",54);
		b.meth4("Phir","hera","pheri");
		System.out.println(result);		
	}
}
