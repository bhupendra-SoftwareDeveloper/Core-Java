package Basic;

public class Prime 
{
	public static void main(String args[])
	{
		int a=57,i,c=0;
		
		for(i=2;i<=a;i++)
		{
			if(a%i==0)
				c++;
		}
		if(c==1)
			System.out.println("It is Prime");
		else
			System.out.println("It is Not Prime");
	}
}
