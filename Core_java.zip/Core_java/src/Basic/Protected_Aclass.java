package Basic;

public class Protected_Aclass
{
	protected void display()
	{
		System.out.println("Today is Awesome");
	}
	public static void main(String[] args)
	{
		new Protected_Aclass().display();
	}
}
