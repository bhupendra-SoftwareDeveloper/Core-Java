package Basic;

public class Protected_Bclass
{
	public static void main(String[] args)
	{
		new Protected_Aclass().display();
	}
}
