package Basic;

public class ReemaParty 
{
	public int beer(int a,int b,String s)
	{int r;

		System.out.println("This is beer");
		r=a*b/b+a+a+b;
		return r;
	}
	public static void main(String args[])
	{
	  System.out.println("Welcome To The ReemaParty");
	  System.out.println("Entry Fees Is:750 Rupees");
	  ReemaParty l=new ReemaParty();
	  //new ReemaParty().beer();	//we can call like this also
	  //int result=l.beer(9,7);		//storing the value for printing
	  System.out.println(l.beer(9,7,"Hello"));	//printing value without storing 
	}
}
