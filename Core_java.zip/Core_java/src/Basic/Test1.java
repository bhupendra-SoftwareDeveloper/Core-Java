package Basic;

public class Test1 
{
	public String testMethod()
	{
		System.out.println(35);
		return new Test1().testMethod3(new Test1().testMethod2())+new Test1().testMethod4("here");	
	}
	public int testMethod2()
	{
		System.out.println(25);
		return 25+5;		
	}
	public String testMethod3(int a)
	{
		System.out.println(15);
		return "is";
	}
	public String testMethod4(String s)
	{
		System.out.println(45);
		return "awesome";
	}
	 public static void main(String[] java)//we can write anything string type in place of java
	 {
	 	Test1 t=new Test1();
		System.out.println("java"+t.testMethod());//java stores in s.o.p after that it is calling to testMethod()
	}
}
