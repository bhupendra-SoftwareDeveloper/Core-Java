package Basic2;
import Basic.ClassB0102;
public class ClassX0102 
{
	public static void main(String[] args) {
		new ClassB0102().m2();
	}
}
