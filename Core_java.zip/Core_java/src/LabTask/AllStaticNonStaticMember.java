package labPractice;

public class AllStaticNonStaticMember
{
	static int a=10;
	int b=20;
	
	static {
				System.out.println("Static block executed");//1
				System.out.println("Static variable:"+a);//2
			}
	{
		System.out.println("Non static block executed");//5
		System.out.println("Static variable:"+a);//6
		System.out.println("Non Static variable:"+b);//7
	}
	
	static void m1()
	{
		System.out.println("Static method called");//3
		System.out.println("Static variable:"+a);//4
	}
	void m2()
	{
		System.out.println("Non static method called");//8
		System.out.println("Static variable:"+a);//9
		System.out.println("Non Static variable:"+b);//10
	}
	public static void main(String[] args)
	{
		AllStaticNonStaticMember.m1();
		new AllStaticNonStaticMember().m2();
	}
}
