package LabTask;

public class Pattern
{
	static int i,j;
	
	public void m1()
	{
		System.out.println("======1st Pattern======");

		for(i=1;i<=5;i++)
		{
			for(j=1;j<=9;j++)
			{
				if(j>=6-i&&j<=4+i)
				{	
					if(i%2==1)
						{if(j%2==1)
				        	System.out.print(i);
						
						System.out.print(" ");
						}
					else{if(j%2==0)
						 System.out.print("*");
						System.out.print(" ");
						}
				}
				else
					System.out.print(" ");
			}
			System.out.println();//ln stands for new line
		}
		System.out.println();
	}
	
	public void m2()
	{
		System.out.println("======2nd Pattern======");

		int k,m=0;
		for(i=1;i<=5;i++)
		{
		  k=m+i;

		   for(j=1;j<=5;j++)
			{
			   if(j>=i&&j<=5)
				{
				  System.out.print(k);
				  k++;
				}
			   else
				System.out.print(0);
			}
		   System.out.println();
		   m++;
		}
		System.out.println();
	}
	
	public void m3()
	{
		int c=65;
		System.out.println("======3rd Pattern======");
		for(i=5;i>=1;i--)
		{
			for(j=5;j>=1;j--)
			{
				if(i<=j)
					System.out.print(i);
				else
					System.out.printf("%c",c);
			}
			c++;
			System.out.println();
		}
		System.out.println();
	}
	
	public void m4()
	{
		System.out.println();
		System.out.println("======4th Pattern======");
		for(i=1;i<=5;i++)
		{
			for(j=1;j<=5;j++)
			{
				if(j<=i)
					System.out.print(i);
				else
					System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void m5()
	{
		System.out.println();
		System.out.println("======5th Pattern======");
		int k=1,l=1,r;
		for(i=1;i<=3;i++)
		{
			for(j=1;j<=3;j++)
			{
				//System.out.print((Integer.toBinaryString(k++)+"   "));
				while(k!=0)
				{
					r=k%2;
					if(r!=1) System.out.print("0");
					else System.out.print(r);
					k/=2;
				}k++;
			}	
			System.out.println();
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		Pattern ob=new Pattern();
		ob.m1();
		ob.m2();
		ob.m3();
		ob.m4();
		ob.m5();
	}
}