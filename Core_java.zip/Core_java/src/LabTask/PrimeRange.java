package labPractice;

public class PrimeRange 
{
	void m1(int a,int b)
	{int i,j,c;
		for(i=a;i<=b;i++)
		{c=0;
			for(j=1;j<=i;j++)
			{
				if(i%j==0)
					c++;
			}
			if(c==2)System.out.println(i);
		}
	}
	public static void main(String[] args)
	{
		PrimeRange obj=new PrimeRange();
		obj.m1(1,20);
	}
}
