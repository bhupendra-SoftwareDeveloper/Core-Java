package LabTask;
class Q10_2
 {
   static{
		System.out.println("SB1");
	}
static void m1()
 {
   System.out.println("m1()");
  }
public static void main(String []args) 
  {
    Q10_2.m1();
  }
}
