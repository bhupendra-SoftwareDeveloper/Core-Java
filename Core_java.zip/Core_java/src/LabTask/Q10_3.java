package LabTask;
class Q10_3 {
	int a;
		{
		Q10_3 obj = new Q10_3();  
		System.out.println(a);
	}
	public static void main(String[] args) {
		Q10_3 obj=new Q10_3();
		System.out.println(obj); 
	}
}
