package LabTask;
class Q10_5 {
	int a;//0
		{
		Q10_5 obj = new Q10_5();  
		System.out.println(a);
	}
	public static void main(String[] args) {
		Q10_5 obj=new Q10_5();
		System.out.println(obj); 
	}
}
//Stack OverFlow