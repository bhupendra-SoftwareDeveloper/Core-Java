package LabTask;
class Laptop
{
	void access()
	{
		System.out.println("Copy java soft copies....");
	}
}
class Faculty
{
	static Q11_5 password = new Q11_5();
}
class Q11_5 
{
	public static void main(String[] args) 
	{
		Faculty.password.access();
	}
}