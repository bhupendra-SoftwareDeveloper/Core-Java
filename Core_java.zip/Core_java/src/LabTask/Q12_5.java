package LabTask;
class Q12_5
{
	int x=10;
	int y=20;
	
	public static void main(String[] args)
	{
		Q12_5 e1=new Q12_5();
		Q12_5 e2=new Q12_5();
		System.out.println(e1.x+"...."+e1.y);//10....20
		System.out.println(e2.x+"...."+e2.y);//10....20
	}
}