package LabTask;
class Q13_2
 {
   static
    {
	System.out.println("Test13 : SB1 called");
    }
  static void m1()
  {
	 System.out.println("Test13 : m1() called");
  }
}
