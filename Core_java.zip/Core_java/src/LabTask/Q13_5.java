package LabTask;
class Q13_5
{
	int a=10;//e1=50 
	int b=20;//e2=60 
	
	public static void main(String[] args)
	{
		Q13_5 e1=new Q13_5();
		Q13_5 e2=new Q13_5();
		System.out.println(e1.a+"...."+e1.b);//10...20
		System.out.println(e2.a+"...."+e2.b);//10...20
		
		e1.a=50;
		e2.b=60;
		System.out.println(e2.a+"...."+e2.b);//10...60
		System.out.println(e2.a+"...."+e2.b);//10...60
	}
}