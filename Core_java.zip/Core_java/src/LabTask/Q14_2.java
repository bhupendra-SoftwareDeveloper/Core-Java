package LabTask;
class Q14_2
 {
  static int x =100;
  static
  {
	System.out.println("x :"+x);
	System.exit(0);
   }
}
