package LabTask;
class Q14_5
{
	int eid;//7279
	String ename;//Sreenivas
	String company;//Naresh IT
	
	public String toString(){
	return "eid:"+eid+"\n"+"ename:"+ename+"\n"+"company:"+company+"\n";
	}
	public static void main(String[] args)
	{
		Q14_5 e1=new Q14_5();
		e1.eid=7279;
		e1.ename="Sreenivas";
		e1.company="Naresh IT";
		//System.out.println(e1);
		//System.out.println(e1.toString());
	}
}