package LabTask;
class Q15_2Super
 {
	int x =10;
	static void m1()
         {
		System.out.println("Q15_2Super : m1()");
	}
	static {
			System.out.println("Q15_2Super : SB1 called");
	      }
}
	
class Q15_2Sub extends Q15_2Super
 {
	static int x =20;
	static {
			System.out.println("Q15_2Sub : SB1 called");
		}
	static void m2()
	{
		m1();
		System.out.println("Q15_2Sub : m2()");
	}
	public static void main(String[] args)
       {
		m2();
	}
}