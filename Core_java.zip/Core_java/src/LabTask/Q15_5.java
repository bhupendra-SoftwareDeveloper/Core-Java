package LabTask;
class Q15_5
{
	static int a=10;
	static int b=20;

	int x=30;
	int y=40;

	public static void main(String[] args)
	{
		Q15_5 e1=new Q15_5();
		Q15_5 e2=new Q15_5();

		Q15_5 e3=null;

		e1.a=50;
		e1.b=60;

		e1.x=70;
		e1.y=80;
	}
}