package LabTask;
class Q16_2
 {	
   int x =10;
   static int a = 20;
//non-static block
  {
	System.out.println("Q16_2 : NSB1 called");
	System.out.println("X : "+x);
	System.out.println("A : "+a);
  }
	//static block
static {
	System.out.println("Q16_2 : SB1 called");
	System.out.println("X : "+x);	//non static variable we can not access inside static content
	System.out.println("A : "+a);
	}
//main method
public static void main(String[] args)
 {
   //no-operation
  }
}
/*-----------------------------------------------------------------------
 error: non-static variable x cannot be referenced from a static context
        System.out.println("X : "+x);
------------------------------------------------------------------------*/