package LabTask;
class Q16_5
{
	void m1(){
	System.out.println("m1() method");
	}

	public static void main(String[] args)
	{
		System.out .println("main method");
		Q16_5 t=new Q16_5();
		t.m1();
	}

}