package LabTask;
class Q17_2Super
 {
	static void m2() {
			System.out.println("Q17_2Super : m2()");
			}
 }
class Q17_2Sub extends Q17_2Super
 {
	public static void m1()
        {
		System.out.println("Q17_2Sub : m1()");
		Super.m2();
	}
	public static void m2() {
			System.out.println("Q17_2Sub : m2() ");
		 	}

public static void main(String[] args)
 {
	Q17_2Sub.m1();
  }
}
