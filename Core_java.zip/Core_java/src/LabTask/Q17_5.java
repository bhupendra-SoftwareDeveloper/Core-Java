package LabTask;
class Q17_5
{
	int x;//0//1+3=4//4+1=5+3=8
	int y;//0//2+4=6//6+2=8+4=12

	void m1(Q17_5 t){
	
	x=x+1;
	y=y+2;

	t.x=t.x+3;
	t.y=t.y+4;
	}

	public static void main(String[] args)
	{
		Q17_5 t1=new Q17_5();
		Q17_5 t2=new Q17_5();

		t1.m1(t2);
		System.out.println(t1.x+"...."+t1.y);//1..2
		System.out.println(t2.x+"...."+t2.y);//3..4

		t2.m1(t1);
		System.out.println(t1.x+"...."+t1.y);//4...6
		System.out.println(t2.x+"...."+t2.y);//4...6

		t1.m1(t1);
		System.out.println(t1.x+"...."+t1.y);//8...12
		System.out.println(t2.x+"...."+t2.y);//4...6

		t2.m1(t2);
		System.out.println(t1.x+"...."+t1.y);//8...12
		System.out.println(t2.x+"...."+t2.y);//8...12
	}
}