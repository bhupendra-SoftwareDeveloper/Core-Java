package LabTask;
class Q18_2 {
		static int a = 20;
		public static void main(String[] args)
		 {
			Q18_2 t1 = new Q18_2();
			Q18_2 t2 = new Q18_2();
			
			System.out.println("A : "+a);
			System.out.println("t1.A : "+t1.a);
			System.out.println("t2.A : "+t2.a);
			t1.a=30;
			System.out.println("t1.A : "+t1.a);
			System.out.println("t2.A : "+t2.a);
			t2.a=40;
			System.out.println("t1.A : "+t1.a);
			System.out.println("t2.A : "+t2.a);
		}
	}
