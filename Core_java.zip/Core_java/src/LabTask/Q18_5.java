package LabTask;
class Q18_5
{
	int x;//0
	int y;//0

	void m1(Q18_5 t){
	System.out.println("\t t:"+t);//string formate2
	t=new Q18_5();
	System.out.println("\t t:"+t);//string formate
	
	}

	public static void main(String[] args)
	{
		Q18_5 t1=new Q18_5();
		Q18_5 t2=new Q18_5();
		
		System.out.println("t2:"+t2);//string formate2	
		t1.m1(t2);
		System.out.println("t2:"+t2);//string formate2
	}
}