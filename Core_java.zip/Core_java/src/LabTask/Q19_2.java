package LabTask;
class Q19_2 {
		int x =10;
		{
			System.out.println("Q19_2 : NSB1");
		}
		void m1() {
			System.out.println("Q19_2 : m1()");
		}

		public static void main(String[] args) {
			//no-operation
		}
	}
