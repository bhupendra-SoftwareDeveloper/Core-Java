package LabTask;
class Q19_5 
{ 
  
    int a = 10; 
  
    public static void main(String[] args) 
    { 
        
        Q19_5 t = new Q19_5(); 
  
        System.out.println("Non static variable"+ " accessed using instance"
                           + " of a class"); 
        System.out.println("Non Static variable "+ t.a); 
    } 
}