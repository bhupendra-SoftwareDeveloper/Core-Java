package LabTask;
public class Q1_2
{
  int rollNo;
  String name;
   
  public void m1()
  {
    System.out.println("Roll NO:"+rollNo);
    System.out.println("Student Name:"+name);
  }
  public static void main(String agr[])
 {
    Q1_2 ob=new Q1_2();
    ob.rollNo=2;
    ob.name="RAHUL";
    ob.m1();
 }
}
