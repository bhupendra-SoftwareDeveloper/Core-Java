package LabTask;
class Q1_3
{
  int a;
  Q1_3()
   {
     System.out.println("Constrructor");
   }
  {
    System.out.println("Non static Block"); 
  }
  public static void main(String agr[])
  {
    System.out.println("Main method");
     new Q1_3();
  }
} 