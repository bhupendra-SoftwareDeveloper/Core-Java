package LabTask;
class Q1_5 {
	int a ; 
	Q1_5(){
		System.out.println("Constructor");//3
}

{
System.out.println("Non-static block");//2
}
 public static void main(String[] args) {
		System.out.println("main method");//1
		new Q1_5(); 
	}
}