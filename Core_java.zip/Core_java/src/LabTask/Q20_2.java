package LabTask;
class Q20_2 {
		int x=100;
		static {
			x = 200;
			System.out.println(x);
		}
		static void m1() {
			x = 300;
			System.out.println("m1 X :"+x);
		}
		public static void main(String []args) {
			System.out.println("main X :"+x);
		}
	}
