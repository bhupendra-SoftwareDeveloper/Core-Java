package LabTask;
class Q20_5
{
	int m1()
	{
		System.out.println("m1 method");//1//3
		return 10;
	}

	void m2()
	{
		System.out.println("m2 method");//5
	}

	public static void main(String[] args)
	{
		Q20_5 t=new Q20_5();
		int x=t.m1();
		System.out.println("return value="+x);//2-->10
		System.out.println("return value="+t.m1());//4-->10
		t.m2();
			}
}