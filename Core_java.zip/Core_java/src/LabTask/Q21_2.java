package LabTask;
class Q21_2
 {
   static int x = m1();
	static int  m2()
	 {
		System.out.println("Q21_2 : m2() called");
		return 10;
	}
	static int m1()
	 {
		System.out.println("Q21_2 : m1() called");
		return 20;
	}
public static void main(String[] args)
 {
	System.out.println("X : "+x);
  }
}
