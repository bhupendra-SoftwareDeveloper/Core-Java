package LabTask;
class Q21_5
{
	int val1;//0
	int val2;//0
	void values(int val1, int val2)//10,20
	{
		System.out.println(val1);//1-->10
		System.out.println(val2);//2-->20
		int a=val1;
		int b=val2;
	}
	void add()
	{
		System.out.println(val1+val2);//3-->0
	}
	void mul()
	{
		System.out.println(val1*val2);//4-->0
	}
	
	public static void main(String[] args)
	{
		Q21_5 t=new Q21_5();
		t.values(10,20);
		t.add();
		t.mul();
	}
}