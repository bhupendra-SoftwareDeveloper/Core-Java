package LabTask;

public class Q23_5
{
	public int sumOfRoundedValues(int a,int b,int c)
	{int r,r2,r3,sum=0;
		r=a%10;
		a=a-r;
		if(r>=5) a=a+10;
		r2=b%10;
		b=b-r2;
		if(r2>=5) b=b+10;
		r3=c%10;
		c=c-r3;
		if(r3>=5) c=c+10;
		return sum=a+b+c;
	}
	
	public static void main(String[] args)
	{
		Q23_5 ob= new Q23_5();
		System.out.println("sum of round values="+ob.sumOfRoundedValues(23,34,66));
	}
}
