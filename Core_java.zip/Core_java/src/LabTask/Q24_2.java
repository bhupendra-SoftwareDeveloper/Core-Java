package LabTask;
class Q24_2
 {
	static int a = 20;
	static {
		System.out.println("SB1 : "+Q24_2.a);
		System.out.println("SB1 : "+a);
		}
	static {
		System.out.println("SB2 : "+Q24_2.b);
		}	
static int b = 30;
public static void main(String[] args)
 {
	System.out.println("A : "+a);
	System.out.println("B : "+b);
  }
}
