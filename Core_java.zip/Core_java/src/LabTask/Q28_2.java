package LabTask;
class Q28_2
 {
	public static void main(String[] args) {
			System.out.println("Main Method....");
		}
	
	static {
			System.out.println("Static Block...");
		}
	}
