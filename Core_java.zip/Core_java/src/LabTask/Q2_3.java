package LabTask;
class Q2_3
{
	public static void main(String[] args)
	 {
	   Q2_3 t=new Q2_3();
		t.fun(); 
	} 
      void fun()
	{
          System.out.println("User method...");
	}
}