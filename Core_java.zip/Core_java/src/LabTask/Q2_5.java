package LabTask;
class Q2_5 {
	public static void main(String[] args) {
	Q2_5 t=new Q2_5();
		t.fun(); 
	}
void fun()
	{
	System.out.println("User method...");
	}
}