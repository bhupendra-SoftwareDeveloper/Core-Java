package LabTask;
class Q31_2 {
		public static void main(String[] args) {
			System.out.println("Main Method....");
		}
		static  void fun() {
			System.out.println("User Defined Method...");
		}
	}
