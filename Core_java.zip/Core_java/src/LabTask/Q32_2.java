package LabTask;
class Q32_2 {
		public static void main(String[] args) {
			System.out.println("Main Method Starts....");
			Q32_2.fun();
			System.out.println("Main Method Ends....");
		}
		static  void fun() {
			System.out.println("User Defined Method...");
		}
	}
