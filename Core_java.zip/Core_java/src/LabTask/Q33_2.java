package LabTask;
class Q33_2 {
		public static void main(String[] args) {
			System.out.println("Main Method Starts....");
			Q33_2.m1();
			System.out.println("Main Method Ends....");
		}
		static  void m1() {
			System.out.println("User Defined Method...");
		}
		static {
			System.out.println("Static Block Starts...");
			Q33_2.m1();
			System.out.println("Static Block Ends...");
		}

	}
