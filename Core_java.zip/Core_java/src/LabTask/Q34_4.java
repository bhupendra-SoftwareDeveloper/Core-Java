package LabTask;
class Q34_4 {
		static  void m1() {
			System.out.println("Control in m1 method");//3//10
		}

		public static void main(String[] args) {
			System.out.println("Main Method Starts....");//6
			System.out.println("Calling m2 method");//7
			Q34_4.m2();
			System.out.println("Control Back to main from m2 method...");//13
			System.out.println("Main Method Ends....");//14
		}

		static  void m2() {
			System.out.println("Control in m2 method");//8
			System.out.println("Calling m1 method");//9
			Q34_4.m1();
			System.out.println("Control Back to m2 from m1 method...");//11
			System.out.println("m2 method ends...");//12

		}
		
		static {
			System.out.println("Static Block Starts...");//1
			System.out.println("Calling m1 method");//2
			Q34_4.m1();
			System.out.println("Control Back to Static Block from m1");//4
			System.out.println("Static Block Ends...");//5
		}

	}
