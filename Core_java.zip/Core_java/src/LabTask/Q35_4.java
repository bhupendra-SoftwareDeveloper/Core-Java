package LabTask;
class Q35_4 {
		public static void main(String[] args) {
			int a;
			System.out.println(a);
			a=10;
			System.out.println(a);
		}
	}
