package LabTask;
class Q36_4 {

		static {
			int x =10;
			System.out.println(x);

		}
		public static void main(String[] args) {
			System.out.println(x);
		}
	}
