package LabTask;
class Q37_4 {

		static {
			System.out.println("Static Block");//1
			System.out.println(Q37_4.a);//2-->0
		}

		public static void main(String[] args) {
			System.out.println("Main Method");//3
			System.out.println(a);//4-->50
		}

		static int a=50;
	}
//Static block & static var has same priority so execution will be inorder for as written