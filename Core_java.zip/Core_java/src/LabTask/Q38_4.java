package LabTask;
class Q38_4 {
		static int x =100;
		
		public static void main(String[] args) {
			System.out.println(Q38_4.x);//100
			System.out.println(x);//100
		}
	}
