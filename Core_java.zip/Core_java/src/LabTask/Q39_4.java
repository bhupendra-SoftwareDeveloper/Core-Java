package LabTask;
class Q39_4 {
		static int x =100;
		
		public static void main(String[] args) {
			int x = 200;
			System.out.println(Q39_4.x);//100
			System.out.println(x);//200
		}
	}
