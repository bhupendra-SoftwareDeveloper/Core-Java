package LabTask;
class Q3_2 
{
	public static  void  main(String[] args) 
	{
	  int a;
          System.out.println("A : "+a);
	} 
}
