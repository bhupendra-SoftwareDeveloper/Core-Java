package LabTask;
class Q3_3 {
	public static void main(String[] args) {
		new Q3_3(); 
	}
	Q3_3()
	{
		System.out.println("Constructor");
	}
}
