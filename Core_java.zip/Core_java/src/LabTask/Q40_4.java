package LabTask;
class Q40_4 {
		static int x =50;
		
		public static void main(String[] args) {
			int x = 60;
			Q40_4.x = Q40_4.x+x;//110
			x = x+Q40_4.x;//170
			
			Q40_4.x = Q40_4.x+x+Q40_4.x;//110+170+110
			
			System.out.println(Q40_4.x);//390
			System.out.println(x);//170
		}
	}