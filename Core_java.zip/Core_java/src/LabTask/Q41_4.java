package LabTask;
class Q41_4  {
		static {
			int a = 10;

			System.out.println("Class Level A : "+Q41_4.a);//0
			Q41_4.a = Q41_4.a+a;//0+10
		}

		static int a = 20;

		public static void main(String[] args) {
			System.out.println("Class Level A : "+Q41_4.a);//20
		}
	}
