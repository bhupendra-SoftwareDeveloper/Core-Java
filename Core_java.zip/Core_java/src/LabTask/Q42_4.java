package LabTask;
class Q42_4  {
		static {
			int a = 50;
			
			Q42_4.a = Q42_4.a+a;
			a = a+Q42_4.a;
			Q42_4.a = a+a;//200
		}

		static int a = 60;

		public static void main(String[] args) {
			System.out.println("Class Level A : "+Q42_4.a);//60 
		}
	
}