package LabTask;
class Q43_4 {
		static {
			int x = 10;
			Q43_4.x = x+x;//20
		}

		static int x;
		
		public static void main(String[] args) {
			System.out.println("Class Level X : "+Q43_4.x);
		}

		static {
			x = x+Q43_4.x;
		}
	}
