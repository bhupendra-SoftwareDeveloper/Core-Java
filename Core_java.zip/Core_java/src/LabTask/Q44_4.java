package LabTask;
class Q44_4 {
		static int a;//50
		
		public static void main(String[] args) {
			System.out.println(Q44_4.a);//0
			Q44_4.a = Q44_4.initialize();//60
			System.out.println(Q44_4.a);//60
		}

		static int initialize() {
			Q44_4.a = 50;
			return 60;
		}
		
	}
