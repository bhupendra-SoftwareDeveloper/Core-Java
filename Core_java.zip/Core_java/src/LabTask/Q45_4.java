package LabTask;
class Q45_4 {
		static int x = Q45_4.m1();//10//20

		public static void main(String[] args) {
			System.out.println(Q45_4.x);//2-->20
		}

		static int m1() {
			Q45_4.x = 10;

			return Q45_4.m2();
		}

		static int m2() {
			System.out.println(Q45_4.x);//1-->10
			return 20;
		}
	}
