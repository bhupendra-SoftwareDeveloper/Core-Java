package LabTask;
class Q46_4 {
		static int x = 10;

		public static void main(String[] args) {
			System.out.println(Q46_4.m2()+Q46_4.m1()+Q46_4.x);//-90+10+10
		}

		static int m1() {
			Q46_4.x = Q46_4.x+100;//10
			return Q46_4.x;
		} 
		static int m2() {
			Q46_4.x = Q46_4.x-100;//-90
			return Q46_4.x;
		}
	}
