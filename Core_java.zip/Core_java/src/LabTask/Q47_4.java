package LabTask;
class Q47_4 {
		static int x = m1();//50//100//120

		public static void main(String[] args) {
			System.out.println(Q47_4.x);//3-->120
		}

		static {
			System.out.println(x);//2-->100
			Q47_4.x = x+20;//120
		}

		static int m1() {
			Q47_4.x = 50;
			return m2();		
		} 

		static int m2() {
			System.out.println(Q47_4.x);//1-->50
			return 100;
		}
	}
