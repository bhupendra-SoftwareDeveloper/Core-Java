package LabTask;
class Q48_4 {
		static {
			Q48_4.a = m1();//50//50//100
		}

		static int a = 50;//30//50//30

		public static void main(String[] args) {
			System.out.println(a);//3-->100
		}

		static {
			Q48_4.a = Q48_4.a+m1();//50+50
		}

		static int m1() {
			Q48_4.a = 30;
			return m2();
		}

		static int m2() {
			System.out.println(a);//1-->30, 2-->30
			return Q48_4.a+20;//30+20=50,50
		}
	}
