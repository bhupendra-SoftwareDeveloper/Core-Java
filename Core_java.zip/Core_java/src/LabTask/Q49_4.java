package LabTask;
class Q49_4 {
		static int a = 50;

		public static void main(String[] args) {
			int a = 60;

			a = a;

			System.out.println(a);//60
			System.out.println(Q49_4.a); //50
		}
	}
