package LabTask;
class Q4_2 
{static  int x;
   public static void main(String[] args) 
    {
	
	System.out.println(x);
    }
}
