package LabTask;
class Q4_3 
{
	Q4_3()
	{
		System.out.println("Object initialization process....");
	}
 
	{
		System.out.println("Object creation process....");
	}
 
	public static void main(String[] args) 
	{
		new Q4_3(); 
		new Q4_3();
		new Q4_3();
	}
}
