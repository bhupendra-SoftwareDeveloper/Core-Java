package LabTask;
class Q4_5 
{
	Q4_5()
	{
		System.out.println("Object initialization process....");
	}
 
	{
		System.out.println("Object creation process....");
	}
 
	public static void main(String[] args) 
	{
		new Q4_5(); 
		new Q4_5();
		new Q4_5();
	}
}