package LabTask;
class Q50_4 { 
	public static void main(String[] args) 
	{ 
		int x = 20; 
		System.out.println(x); 
	} 
	static
	{ 
		int x = 10; 
		System.out.print(x + " ");
	} 
}
//OUTPUT-->10 20