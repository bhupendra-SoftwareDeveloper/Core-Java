package LabTask;
class Q53_4 { 
	int x = 10; 
	public static void main(String[] args) 
	{ 
		System.out.println(Q53_4.x); 
	} 
	static
	{ 
		int x = 20; 
		System.out.print(x + " "); 
	} 
}
//OUT-->Error