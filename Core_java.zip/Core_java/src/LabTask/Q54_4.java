package LabTask;
class Q54_4 { 
	static  int x = 10; //20
	public  static void main(String[] args) 
	{ 
		Q54_4 t1 = new Q54_4(); 
		Q54_4 t2 = new Q54_4(); 

		t1.x = 20; 
		System.out.print(t1.x + " ");
		System.out.println(t2.x); 
	} 
}
//OP-->20 20