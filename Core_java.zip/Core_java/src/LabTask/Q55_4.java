package LabTask;
class Q55_4 { 
		static  int i = 1; 
	public static void main(String[] args) 
	{ 
		for (int i = 1; i < 10; i++) { 		
			i = i + 2; 
			System.out.print(i + " "); 
		} 
	} 
}
//OP-->3 6 9