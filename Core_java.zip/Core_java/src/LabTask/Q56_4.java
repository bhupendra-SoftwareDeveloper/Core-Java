package LabTask;
class Q56_4 { 
	static  int i = 1;//1,2,3,4,5,6,7,8,9
	public static void main(String[] args) 
	{ 
		int i = 1;//3,5,7,9,11,13,15,17,19
		for (Q56_4.i = 1; Q56_4.i < 10; Q56_4.i++) { 
			i = i + 2; 
			System.out.print(i + " "); 
		} 
	} 
}
//OP-->3 5 7 9 11 13 15 17 19