package LabTask;
class Q57_4 { 
	static  int i = 1;
	public static void main(String[] args) 
	{ 
		static int i = 1; 
		for (Q57_4.i = 1; Q57_4.i < 10; Q57_4.i++) { 
			i = i + 2; 
			System.out.print(i + " "); 
		} 
	} 
}
//OP-->Error Static never declared as local variable