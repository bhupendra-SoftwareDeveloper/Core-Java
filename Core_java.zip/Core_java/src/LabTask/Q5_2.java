package LabTask;
class Q5_2 
{
  static int x = 10;
   void m1() 
    {
	System.out.println("m1 X : "+x);
    }
  public static void main(String[] args) 
   {	
	System.out.println("main X : "+x);			
   }
}
