package LabTask;
public class Q60_4 
{
    static int a =10;//20
    public static void main(String args[]){
        Q60_4 s1 = new Q60_4();
        Q60_4 s2 = new Q60_4();
        System.out.println("s1.a value :"+s1.a);//1-->10
        System.out.println("s2.a value :"+s2.a);//2-->10
        //Change s1 a value alone
        s1.a=20;
        System.out.println("s1.a value :"+s1.a);//3-->20
        System.out.println("s2.a value :"+s2.a);//4-->20
    }
}
