package LabTask;
class Q6_2 
{
   int a = 10;
  public static void main(String[] args) 
  { 
	System.out.println("A  value :  "+a);
   }
}
