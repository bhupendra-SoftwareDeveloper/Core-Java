package LabTask;
class Q6_3 
{
	Q6_3( ) 
	{
		System.out.println(this);
		
		System.out.println(this.hashCode());
	}
	public static void main(String args[ ])
	{
		new Q6_3( );	
	}
}
