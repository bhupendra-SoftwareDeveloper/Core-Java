package LabTask;
class Q6_5 
{
	Q6_5( ) 
	{
		System.out.println(this);
		System.out.println(this.hashCode());
	}
	public static void main(String args[ ])
	{
		new Q6_5( );
	}
}