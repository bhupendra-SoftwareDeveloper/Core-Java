package LabTask;
class Q7_2 
{
   //static variable a
  static int a = 20;
 public static void main(String[] args) 
 {
   //System.out.println("A value is="+a);	//first
   System.out.println("A value is="+(new Q7_2().a));//second
 }
}
