package LabTask;
class Q7_3 
{
	static int a ;
	public static void main(String args[ ])
	{
		Q7_3 n=new Q7_3();
		System.out.println(this.a);
	}
	{
		System.out.println(this);
		
		this.a = 100 ;
	}
	Q7_3()
	{
		System.out.println(this.a);
	}
}
