package LabTask;
class Q7_5 
{
	int a ;//0//100
	public static void main(String args[ ])
	{
		new Q7_5();
	}
	{
		System.out.println(this.a);//1-->0
		this.a = 100 ;
	}
	Q7_5()
	{
		System.out.println(this.a);//2-->100
	}
}