package LabTask;
class Q8_2 
{
 static void m1()
 {
  System.out.println("Test8 : m1() called");
 }

 public static void main(String[] args)
 {
    //m1();
    new Q8_2().m1();
 }
}
