package LabTask;
class Q8_3 
{
	Q8_3( ) 
	{
		System.out.println("Object address inside constructor : "+this);
	}
	public static void main(String args[ ])
	{
		Q8_3 obj = new Q8_3();
		System.out.println("Object address inside main : "+obj);
	}
}
