package LabTask;
class Q8_5 
{
	Q8_5( ) 
	{
		System.out.println("Object address inside constructor : "+this);
	}
	public static void main(String args[ ])
	{
		Q8_5 obj = new Q8_5();
		System.out.println("Object address inside main : "+obj);
	}
}