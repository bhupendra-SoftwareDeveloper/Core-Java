package LabTask;
class Q9_3 
{
	int eno ;
	String ename ;
	float esal ;
	public static void main(String[] args) 
	{
		Q9_3 e = new Q9_3();
		System.out.println("Eno : "+e.eno);
		System.out.println("Ename : "+e.ename);
		System.out.println("Esal : "+e.esal);
	}
}
