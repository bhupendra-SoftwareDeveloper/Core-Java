package LabTask;
class Q9_5 
{
	int eno ;//0
	String ename ;//null
	float esal ;//0.0
	public static void main(String[] args) 
	{
		Q9_5 e = new Q9_5();
		System.out.println("Eno : "+e.eno);//0
		System.out.println("Ename : "+e.ename);//null
		System.out.println("Esal : "+e.esal);//0.0
	}
}