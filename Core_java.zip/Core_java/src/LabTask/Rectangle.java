package LabTask;
class Square
{
  public void area(int a)
  {
    System.out.println("Area of Square:"+a*a);
  }
  public void perimeter(int l)
   {
     System.out.println("Perimeter of Square:"+(4*l));  
   } 
}

public class Rectangle
{
  public void area(int l,int b)
 {
   System.out.println("Area of Rectangle:"+(l*b)); 
  }
  public void perimeter(int l,int b)
 {
  
    System.out.println("Area of Rectangle:"+(2*(l+b)));  
  }

public static void main(String args[])
{
  Rectangle r=new Rectangle();
   r.area(5,4);
   r.perimeter(5,4);
 Square s=new Square();
    s.area(5);
   s.perimeter(4);
}
}