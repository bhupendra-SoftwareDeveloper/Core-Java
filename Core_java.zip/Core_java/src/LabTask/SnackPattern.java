package pattern;
public class SnackPattern
{
  public static void main(String argd[])
  {
    int i,j,r=0,n=7;
	for(i=1;i<=n;i++)
	{	if(i%2==0)
		{
			--r;
			r+=i;
		}
		else r+=i;
		for(j=1;j<=i;j++)
		{
			if(i%2==1)System.out.printf("%3d",r++);
			else System.out.printf("%3d",r--);
		}
		System.out.println();
	}
  }
}