package LabTask;
public class Square {
 
    public static void main(String[] args) {
        int result, n;
        
        n = 3	//error because there is no semicolon
        result = square(n);
        System.out.println("Square of 3 is: " + result);
        
        n = 4	//error because there is no semicolon
        result = square(n); 
        System.out.println("Square of 4 is: " + result);
    }

	static int square(int i) {
        return i * i;
    }
}