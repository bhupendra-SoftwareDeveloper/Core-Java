package LabTask;
class SquareMain 
{
    public static void main(String[] args) 
    {
        int result;
        result = square(); 
        System.out.println("Squared value of 10 is: " + result);
    }

    public static int square() 
     {
        // return statement
        return 10 * 10;
     }

}