package labPractice;

public class StaticNonStaticShadowing
{
	static int a=10;
	
	void m1()
	{
		int a=30;
		System.out.println("Instance Variable:"+a);
		System.out.println("Class Level Variable:"+new StaticNonStaticShadowing().a);
	}
	public static void main(String[] args)
	{
		new StaticNonStaticShadowing().m1();
	}
}
