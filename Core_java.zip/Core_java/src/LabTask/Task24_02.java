package LabTask;

public class Task24_02
{
	int mul(int x, int y)
	{
		int mul=0;
		for(var i=1;i<=y;i++) {
			mul+=x;
		}
	return mul;
	
	}
	int mod(int x,int y) {
		int mod=x;
		for(var i=1;mod>=y;i++)mod-=y;
		return mod;
	}
	
	int div(int x,int y) {
		int count=0;
		int mod=x;
		for(int i=1;mod>=y;i++,count++)
			mod-=y;
		return count;
	}
	
	int sub(int x, int y) {
		return (x+~y+1);
	}
	
	public int luckySum(int a, int b,int c)
	{		
		System.out.println("==========1st Whatsapp Programme==========");

		int sum=0;
		if(a==13);
		else if(b==13) sum=a;
		else if(c==13) sum=a+b;
		else sum=a+b+c;
		
		return sum;
	}

	public boolean beerParty(int beers, boolean isWeekend)
	{
		System.out.println("==========2nd Whatsapp Programme==========");

		if(isWeekend==false&&beers>=40)
			return true;
		else if(isWeekend==true&&beers>=40&&beers<=60)
			return true;
		else return false;
	}
	
	public static void main(String[] args)
	{
		Task24_02 ob=new Task24_02();
		System.out.println("Multiplication : "+ob.mul(5,8));
		System.out.println("Modulus : "+ob.mod(202,10));
		System.out.println("Division : "+ob.div(18,9));
		System.out.println("Sub : "+ob.sub(10, 5));
		System.out.println(ob.luckySum(30,1,13));
		System.out.println(ob.beerParty(43,false));
	}
}