package LabTask;

public class Task25_Feb
{	static int sum,r1,r2,r3;
	public boolean countBoolean(boolean a,boolean b,boolean c)
	{ 
		System.out.println("==========1st Whatsapp Programme==========");

		int count=0;
		if(a==true)
		{
			count++;
			if(b==true)
				count++;
				if(c==true)
					count++;
		}
		else
		{
			if(b==true)
				count++;
				if(c==true)
					count++;
		}
		if(count>1)
			return true;
		else return false;
	}
	
	public int sumOfMultiples(int a,int b,int c)
	{
		System.out.println("==========2nd Whatsapp Programme==========");

		if(a<=0||b<=0||c<=0)
			return sum=-1;
		
		else if(a%2==1||b%2==1||c%2==1)
		{
			if(a%2==1)
				sum=a*a*a;
			else if(b%2==1)
				sum=b*b*b;
			else if(c%2==1)
				sum=c*c*c;
			return sum;
		}
		else
		{
			if(a%10==0)
				System.out.println(a+" Is Multiple of 10");
			r1=a%10;
			if(r1!=0)
			{
				a=a-r1;
				a=a+10;
			}
			else a+=r1;
		
			if(b%10==0)
				System.out.println(b+" Is Multiple of 10");
			r2=b%10;
			if(r2!=0)
			{
				b=b-r2;
				b=b+10;
			}
			else b+=r2;
		
			if(c%10==0)
				System.out.println(c+" Is Multiple of 10");
			r3=c%10;
			if(r3!=0)
			{
				c=c-r3;
				c=c+10;
			}
			else c+=r3;
			
			return sum=a+b+c;
		}

	}
	String underLine()
	{
		return "==========================================";
	}
	public static void main(String[] args)
	{
		Task25_Feb ob=new Task25_Feb();
	//	System.out.println(ob.countBoolean(true,true,true)+"\n"+ob.underLine()+"\n");
		System.out.println(ob.sumOfMultiples(5,7,9)+"\n"+ob.underLine()+"\n");
		/*
		 * System.out.println(ob.sumOfMultiples(12,50,0)+"\n"+ob.underLine()+"\n");
		 * System.out.println(ob.sumOfMultiples(12,-9,78)+"\n"+ob.underLine()+"\n");
		 * System.out.println(ob.sumOfMultiples(3,50,40)+"\n"+ob.underLine()+"\n");
		 */
	}
}