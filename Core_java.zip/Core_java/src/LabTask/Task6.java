package LabTask;

public class Task6
{
	static int r,sum;
	public int getSumOfDigits(int a)
	{
		//int sum=0;
		System.out.println("==========1st program==========");
		
		while(a!=0)
		{
			sum+=a%10;
			a/=10;
		}
		return sum;
	}
	
	public int getDiffOfDigits(int a)
	{
		System.out.println("==========2nd program==========");
		int diff=0;
	
			diff=a/10;
			diff-=a%10;
		return diff;
	}
	
	public int getNextMultipleOf100(int a)
	{
		System.out.println("==========3rd program==========");

		a-=a%100;
		a+=100;
		return a;
	}
	
	public int sumOfRoundedValues(int a,int b,int c)
	{
		System.out.println("==========4th program==========");

		int r2,r3;
		r=a%10;
		a=a-r;
		if(r>=5) a=a+10;
		r2=b%10;
		b=b-r2;
		if(r2>=5) b=b+10;
		r3=c%10;
		c=c-r3;
		if(r3>=5) c=c+10;
		return sum=a+b+c;
	}
	
	public static void main(String[] args)
	{
		Task6 ob=new Task6();
		System.out.println(ob.getSumOfDigits(40));
		System.out.println(ob.getDiffOfDigits(98));
		System.out.println(ob.getNextMultipleOf100(738));
		System.out.println(ob.sumOfRoundedValues(23,34,66));
	}
}


