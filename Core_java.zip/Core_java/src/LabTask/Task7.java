
class MAin 
{

   public static void main(String[] args) 
   {

       Output obj = new Output();
       System.out.println("About to encounter a method.");

       // calling myMethod() of Output class
       obj.myMethod();

       System.out.println("Method was executed successfully!");
   }
}