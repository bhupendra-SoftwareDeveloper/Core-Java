package LabTask;

public class Test2
{
  final int x = 10;
	
   void m1()
   {
     x = 20;
     System.out.println("X : "+x);
   }	

   public static void main(String[] args)
   {
	Test2 t1 = new Test2();
	t1.m1();
   }
}

--------------------------------------------------------
/*op=> error: cannot assign a value to final variable x*/
--------------------------------------------------------