package LabTask;
 class Test2_2 
{
	static 
      {
		System.out.println("Test2 class Static Block");
      }
public static void main(String[] args)
  {
	System.out.println("Test2 class main method");
  } 
} 
