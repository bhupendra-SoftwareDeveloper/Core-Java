package LabTask;

public class Test3
{
 final int x;
	
  void m1()
  {	
    System.out.println("X : "+x);
  }	

  public static void main(String[] args)
  {
	Test3 t1 = new Test3();
	t1.m1();
   }
}

/*----------------------------------------------------------------
op=> error: variable x not initialized in the default constructor
    final int x ;
------------------------------------------------------------------*/