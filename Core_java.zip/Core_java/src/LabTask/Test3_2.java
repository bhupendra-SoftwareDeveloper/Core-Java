package LabTask;
class Test3 
 {
	public static void  main(String[] args)
       {
	int a;
	System.out.println("A : "+a);
       } 
}
