package LabTask;

public class Test4
{
       
 int x;
    Test4()	//It is a class constructor
    {
      System.out.println("dd");
    }
{
x=10;
x=20;
}
 	
    void m1()
    {
      System.out.println(x);
    }


   public static void main(String jhd[])
    {
	Test4 t1=new Test4(); //first goes to class constructor
	t1.m1(); //after constructor
    }
}

/*--------------------
op=> x=30
--------------------*/