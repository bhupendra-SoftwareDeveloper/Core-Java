package LabTask;
public class Test5
{
 int y=50;
   final int x ;
    {
     x = 60;
    }
 public static void main(String[] args)
   {	
	Test5 t = new Test5();
	System.out.println(t.y);
   }
}

/*-----------------------------------
op=> 60 we can call a variable also
-------------------------------------*/