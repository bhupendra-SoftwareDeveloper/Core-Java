package array;
import java.util.Scanner;
public class March_03
{
	Scanner sc=new Scanner(System.in);
	
	void m1()
	{
		int arr1[];//Declaration
		arr1 = new int[5]; //Instantiation 1st way
		int arr2[]=new int[5];	//2nd way
		int arr3[]= {10,20,30,40,50};	//3rd way
		int arr4[]=new int[]{10,20,30,40,50}; //4th way
		
		String s="java";
		System.out.println("Length() Vs Length");
		System.out.println("Length() of string:"+s.length());
		System.out.println("Length of an array:"+arr1.length);
		arr1[3]=40;
		System.out.println(arr1[3]);
		System.out.println(arr1[4]);
		
	//	System.out.println(arr3[5]);  //Exception out of bound
		System.out.println("Asking the user to enter the data in array");
		System.out.println("enter the "+arr2.length+" int values:");
		for(int i=0;i<arr2.length;i++)
			arr2[i]=sc.nextInt();
		System.out.println("Data Entered...");
		System.out.println("Retriving Data from Array...");
		for(int y:arr2)
			System.out.println(y);
	}
	
	int[] m2(int[]a,int b[])
	{
		System.out.println("Method2() called");
		int arr[]= {a[0],b[0],a[a.length-1],b[b.length-1]};
		return arr;
	}
	
	public static void main(String[] args)
	{
		int input1[]= {10,20,30};
		int input2[]= {100,200};
		March_03 ob=new March_03();
		ob.m1();
		int result[]=ob.m2(input1,input2);
		for(int z:result)
			System.out.println(z);
	}
}
