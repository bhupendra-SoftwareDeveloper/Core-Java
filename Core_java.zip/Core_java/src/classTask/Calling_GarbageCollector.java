package classTask;

public class Calling_GarbageCollector
{
	void m1()
	{
		System.out.println("Method 1 called..");
		Calling_GarbageCollector cgc2=new Calling_GarbageCollector(); //3rd way
	}
	protected void finalize()
	{
		System.out.println("Garbage Collected..");
	}
	
	public static void main(String[] args)
	{
		Calling_GarbageCollector cgc=new Calling_GarbageCollector();
		Calling_GarbageCollector cgc2=new Calling_GarbageCollector();
		cgc.m1();
	//	cgc=null;	//1st way
	//	Runtime r=Runtime.getRuntime();
	//	r.gc();
	//	cgc2=cgc;	//2nd way
		System.gc();
	}
}
