package classTask;

class Clone implements Cloneable
{
	int a,b;
	Clone show() throws CloneNotSupportedException
	{
		return (Clone)super.clone();
	}
}

class Clone2 implements Cloneable
{
	int x,y;
	Clone2 display() throws CloneNotSupportedException
	{
		return (Clone2)super.clone();
	}
}

public class Clone_Method
{	
	public static void main(String[] args) throws Exception
	{
		Clone c=new Clone();
		Clone2 b2= new Clone2();
		c.a=10;
		c.b=20;
		System.out.println(c.a+" "+c.b);
		
		Clone c2=c;
		c2.b=30;
		System.out.println(c.a+" "+c.b+" "+c2.b);
		
		Clone c3=c.show();
		c3.b=55;
		System.out.println(c.a+" "+c.b+" "+c3.a+" "+c3.b);
		
		b2.x=1000;
		b2.y=2000;
		System.out.println(b2.x+" "+b2.y);
		
		Clone2 b3=b2.display();
		b3.y=9;
		System.out.println(b2.x+" "+b2.y+" "+b3.x+" "+b3.y);
	}
}