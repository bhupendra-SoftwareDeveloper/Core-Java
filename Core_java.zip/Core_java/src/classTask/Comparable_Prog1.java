package classTask;

public class Comparable_Prog1 implements Comparable<Comparable_Prog1>
{
	private String empName;
	private int empSal;
	private int empId;
	public Comparable_Prog1(String empName, int empSal, int empId)
	{
		super();
		this.empName = empName;
		this.empSal = empSal;
		this.empId = empId;
	}
	protected String getEmpName() {
		return empName;
	}
	protected int getEmpSal() {
		return empSal;
	}
	protected int getEmpId() {
		return empId;
	}
	
	@Override
	public String toString() {
		return "Comparable_Prog1 [empName=" + empName + ", empSal=" + empSal + ", empId=" + empId + "]";
	}
	public int compareTo(Comparable_Prog1 ob1)
	{
		return this.empSal-ob1.empSal;
	}
}
