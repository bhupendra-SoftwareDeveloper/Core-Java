package classTask;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
public class Comparable_Prog2
{
	public static void main(String[] args)
	{
		ArrayList <Comparable_Prog1> al=new ArrayList<Comparable_Prog1>();
		al.add(new Comparable_Prog1("Bhupendra",6000,101));
		al.add(new Comparable_Prog1("Satyam",7000,102));
		al.add(new Comparable_Prog1("Aman",8000,104));
		al.add(new Comparable_Prog1("Akash",4000,103));
		al.add(new Comparable_Prog1("Suraj",6600,105));
	
		/*	Collections.sort(al);	//Comparable
		System.out.println(al);		
		System.out.println("----------------------------------------");
		Iterator<Comparable_Prog1> i=al.iterator();
		while(i.hasNext())
			System.out.println(i.next());*/
		
		System.out.println("----------------------------------------");
		System.out.println("-------------Before Sorting-------------");
		Iterator<Comparable_Prog1> i=al.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		System.out.println("-------------After Sorting-------------");
		Collections.sort(al,new Comparator_Prog1_EmpName());
		Iterator<Comparable_Prog1> i2=al.iterator();
		while(i2.hasNext())
			System.out.println(i2.next());
	//	System.out.println(al); 
		
	/*	System.out.println("----------------------------------------");
		System.out.println("-------------Before Sorting-------------");
		Iterator<Comparable_Prog1> i=al.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		System.out.println("-------------After Sorting-------------");
		Collections.sort(al,new Comparator_Prog1_EmpId());
		Iterator<Comparable_Prog1> i2=al.iterator();
		while(i2.hasNext())
			System.out.println(i2.next()); */
		
	/*	System.out.println("----------------------------------------");
		System.out.println("-------------Before Sorting-------------");
		Iterator<Comparable_Prog1> i=al.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		System.out.println("-------------After Sorting-------------");
		Collections.sort(al,new Comparator_Prog1_EmpSal());
		Iterator<Comparable_Prog1> i2=al.iterator();
		while(i2.hasNext())
			System.out.println(i2.next());
		Collections.sort(al,Collections.reverseOrder()); //For descending Order
		System.out.println("-------------Reverse-------------");
		Iterator<Comparable_Prog1> i3=al.iterator();
		while(i3.hasNext())
			System.out.println(i3.next());	*/
	}

}
