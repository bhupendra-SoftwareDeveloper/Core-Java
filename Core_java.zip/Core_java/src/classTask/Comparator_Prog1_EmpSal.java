package classTask;
import java.util.Comparator;

public class Comparator_Prog1_EmpSal implements Comparator<Comparable_Prog1>
{
	public int compare(Comparable_Prog1 ob1,Comparable_Prog1 ob2)
	{
		return ob1.getEmpSal()-ob2.getEmpSal();
	}
}
