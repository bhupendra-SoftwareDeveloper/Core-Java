package classTask;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

class DriverDataStreams
{
	void writing() throws Exception
	{
		DataOutputStream dos=new DataOutputStream(new FileOutputStream("D:\\Let's Do It\\IOStreams\\DataStream.txt"));
		dos.writeInt(1000);
		dos.writeChar('B');
		dos.writeBoolean(true);
		dos.writeInt(2000);
		System.out.println("Data Entered...");
		dos.close();
	}
	void reading() throws Exception
	{
		DataInputStream dis=new DataInputStream(new FileInputStream("D:\\Let's Do It\\IOStreams\\DataStream.txt"));
		System.out.println(dis.readInt());
		System.out.println(dis.readChar());
		System.out.println(dis.readBoolean());
		System.out.println(dis.readInt());
		dis.close();
	}
}

public class DataStreams
{
	public static void main(String[] args) throws Exception
	{
		DriverDataStreams dds=new DriverDataStreams();
	//	dds.writing();
		dds.reading();
	}
}
