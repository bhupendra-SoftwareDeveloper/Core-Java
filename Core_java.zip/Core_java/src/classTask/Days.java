package classTask;

public enum Days
{
	Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday;
}
