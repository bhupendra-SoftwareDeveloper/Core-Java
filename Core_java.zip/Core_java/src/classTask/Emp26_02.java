package classTask;
import java.util.Scanner;
public class Emp26_02
{
	static String name,dep,add;
	static int id;
	static double sal;
	Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		Emp26_02 ob=new Emp26_02();
		System.out.println("Eneter Employee Name: ");
		name=ob.sc.nextLine();
		System.out.println("Enter Employee ID: ");
		id=ob.sc.nextInt();
		ob.sc.nextLine();
		System.out.println("Enter Employee Department: ");
		dep=ob.sc.nextLine();
		System.out.println("Enter Employee Salary: ");
		sal=ob.sc.nextDouble();
		ob.sc.nextLine();
		System.out.println("Enter Employee Address: ");
		add=ob.sc.nextLine();
		System.out.println(name+"\n"+id+"\n"+dep+"\n"+sal+"\n"+add);
	}
}
