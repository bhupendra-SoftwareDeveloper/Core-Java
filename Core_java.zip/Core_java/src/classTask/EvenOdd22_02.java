package classTask;

public class EvenOdd22_02
{
	public void m1(int a,int b,String s)
	{int i;
		switch(s)
		{
			case "Even":
				for(i=a;i<=b;i++)
				{
					if(i%2==0) System.out.println(i+" ");
				}
				break;
			case "Odd":
				for(i=a;i<=b;i++)
				{
					if(i%2==1) System.out.println(i+" ");
				}
				break;
		}
	}
	
	public static void main(String[] args)
	{
		EvenOdd22_02 ob=new EvenOdd22_02();
				ob.m1(10,20,"Odd");
	}
}
