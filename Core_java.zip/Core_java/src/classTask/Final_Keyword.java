package classTask;

public class Final_Keyword
{
	final int a=5;
	void m1()
	{
	//	System.out.println(a++); //final variables are constants
		System.out.println(a);
	}
	
	final void m2()
	{
		System.out.println("This is final method");
	}
	
	public static void main(String[] args)
	{
		new Final_Keyword().m1();
	}
}
