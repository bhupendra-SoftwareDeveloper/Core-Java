package classTask;

public class Final_Keyword2 extends Final_Keyword//we can not inherit final class
{
//	void m2()// we can not override final method
	{
		
	}
	public static void main(String[] args)
	{
		new Final_Keyword2().m2();//we can inherit final method
	}
}
