package classTask;

public class Foreach25_02
{
	void m1()
	{
		int arr[]= {10,20,30,40,23,244,128,98};
		System.out.println("Value 1st position="+arr[1]);
	 //System.out.println(arr[4]); //Exception will occure
		System.out.println("Implementation for loop to retrive the element from array");
		
		for(int i=0;i<5;i++)
		 System.out.println(arr[i]);
		System.out.println("Compiler came out from for loop");
		
		for(int x:arr)
			System.out.println(x);
	}
	public static void main(String[] args)
	{
		new Foreach25_02().m1();
	}
}
