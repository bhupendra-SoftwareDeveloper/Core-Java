package classTask;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
class Task
{
	void op(int ch) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		String tuserName="Kishan";
		String tPassword="Java";
		String tun,tpass,task="Question:- ",sun,spass,sans="\nAnswer:- ";
		String studuserName="Bhupendra";
		String studPassword="5196";
		int r=0;
		if(ch==1)
		{
			System.out.println("Enter User Name: ");
			tun=sc.nextLine();
			System.out.println("Enter Password: ");
			tpass=sc.nextLine();
			if((tun.equals(tuserName))&&(tpass.equals(tPassword)))
			{
				System.out.println("If You want to give task for today then press-->1\nIf You want to give Remark for previous task then press-->2");			
				r=sc.nextInt();
				sc.nextLine();
				if(r==1)
				{
					System.out.println("Enter Task for Today: ");
					task=task.concat(sc.nextLine());
					FileOutputStream fos=new FileOutputStream("D:\\Let's Do It\\IOStreams\\SirTask.txt");
					byte arr[]=task.getBytes();
					fos.write(arr);
					fos.close();
					System.out.println("Task Added...");
				}
				else if(r==2)
				{
					String remk="\nRemark:- ";
					FileInputStream fis=new FileInputStream("D:\\Let's Do It\\IOStreams\\SirTask.txt");
					int i;
					while((i=fis.read())!=-1)
						System.out.print((char)i);
					System.out.println();
					System.out.println("Enter Reamark: ");
					remk=remk.concat(sc.nextLine());
					FileWriter fos=new FileWriter("D:\\Let's Do It\\IOStreams\\SirTask.txt",true);
					fos.write(remk);
					System.out.println("Remark added...");
					fis.close();
					fos.close();
					sc.close();
				}
				else
				{
					try
					{
						Invalid inv=new Invalid("Invalid UserName Or Password!!!");
						throw inv;
					}
					catch(Invalid inv)
					{
						inv.printStackTrace();
					}
				}
			}
			
			else
			{
				try
				{
					Invalid inv=new Invalid("Invalid Selection!!");
					throw inv;
				}
				catch(Invalid inv)
				{
					inv.printStackTrace();
				}
			}
		}
		else if(ch==2)
		{
			System.out.println("Enter User Name: ");
			sun=sc.nextLine();
			System.out.println("Enter Password: ");
			spass=sc.nextLine();
			if((sun.equals(studuserName))&&(spass.equals(studPassword)))
			{
				FileInputStream fis=new FileInputStream("D:\\Let's Do It\\IOStreams\\SirTask.txt");
				int i;
				while((i=fis.read())!=-1)
					System.out.print((char)i);
				System.out.println();
				System.out.println("Enter Answer for Today's Task: ");
				sans=sans.concat(sc.nextLine());
				FileOutputStream fos=new FileOutputStream("D:\\Let's Do It\\IOStreams\\SirTask.txt",true);
				byte arr[]=sans.getBytes();
				fos.write(arr);
				fis.close();
				fos.close();
				System.out.println("Answer Submitted...");
			}
			else
			{
				{
					try
					{
						Invalid inv=new Invalid("Invalid UserName Or Password!!!");
						throw inv;
					}
					catch(Invalid inv)
					{
						inv.printStackTrace();
					}
				}
			}
		}
		else System.out.println("Invalid Selection!!");
	}
}

class Invalid extends Exception
{
	Invalid(String s)
	{
		super(s);
	}
}

public class IOStreamTaskBySir
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("If you are Teacher then press->1\nIf you are Student then press->2");
		int i=sc.nextInt();
		Task t=new Task();
		t.op(i);
		sc.close();
	}
}
