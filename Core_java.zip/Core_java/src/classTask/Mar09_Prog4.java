package classTask;
import java.util.Scanner;
public class Mar09_Prog4
{
	static Scanner sc=new Scanner(System.in);
	String s;
	public boolean m2(int[]a)
	{  int c=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==2||a[i]==3)
			{   c++;
				break;
			}
		}
		if(c==1) return false;
		else return true;
	}
	public static void main(String[] args)
	{
		Mar09_Prog4 m=new Mar09_Prog4();
		System.out.println("Enter array size:");
		int n=sc.nextInt();
		int a[]= new int [n];
		System.out.println("Enter "+n+" integer values:");
		for(int i=0;i<a.length;i++)
			a[i]=sc.nextInt();
		System.out.println(m.m2(a));
	}
}
