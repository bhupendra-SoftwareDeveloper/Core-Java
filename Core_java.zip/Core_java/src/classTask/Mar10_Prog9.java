/*Given an int array, return a new array with double
the length where its last element is the same as original
array and all the others element are 0.The original array
will be length 1 or more.NOTE:-by default,a new int array
contains all 0's.
ex:-[1,2,3]=[000003]
 	[6,4]=[0004]
 	[5]=[05]*/

package classTask;
import java.util.Scanner;
public class Mar10_Prog9
{	static Scanner sc=new Scanner(System.in);

	public int[] makeLast(int[]nums)
	{
		int b[]=new int [nums.length*2];
		b[b.length-1]=nums[nums.length-1];
		return b;
	}
	public static void main(String[] args)
	{
		System.out.println("Enter array size:");
		int n=sc.nextInt();
		System.out.println("Enter "+n+" Integer values:");
		int a[]=new int[n];
		for(int i=0;i<a.length;i++)
			a[i]=sc.nextInt();
		for(int x:new Mar10_Prog9().makeLast(a))
			System.out.print(x);
	}
}
