package classTask;
public class Modifier_28FEb_Xclass
{
	public static void main(String[] args)
	{
		new Modifier_28Feb_Bclass().m2();
	}
}