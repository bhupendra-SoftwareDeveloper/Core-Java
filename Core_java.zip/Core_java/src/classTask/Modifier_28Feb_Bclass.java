package classTask;
import Basic.*;
//import Basic.Modifier_28FEb; //2nd way
public class Modifier_28Feb_Bclass
{
	public void m2()
	{
		System.out.println("Hello this is classTask package, Modifier_28FEbB_class class, m2() method");
	}
	public static void main(String[] args)
	{
		new Modifier_28FEb_Aclass().m1();
	//	new Basic.Modifier_28FEbA_class().m1(); //3rd way
	}
}
