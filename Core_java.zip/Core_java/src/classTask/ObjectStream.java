package classTask;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class DriverObjectStream1 implements Serializable
{
	int a=10,b=20;
}

class DriverObjectStream2 implements Serializable
{
	int x=50,y=100;
}

public class ObjectStream
{
	public static void main(String[] args) throws Exception
	{
		DriverObjectStream1 dosa1=new DriverObjectStream1();
		DriverObjectStream2 dosb1=new DriverObjectStream2();
		
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("D:\\Let's Do It\\IOStreams\\ObjectStream1.ser"));
		oos.writeObject(dosa1);
		oos.writeObject(dosb1);
		
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream("D:\\Let's Do It\\IOStreams\\ObjectStream1.ser"));
		DriverObjectStream1 dosa2=(DriverObjectStream1)ois.readObject();
		DriverObjectStream2 dosb2=(DriverObjectStream2)ois.readObject();
		
		System.out.println(dosa2.a+" "+dosa2.b);
		System.out.println("==================");
		System.out.println(dosb2.x+" "+dosb2.y);
		oos.close();
		ois.close();
	}
}
