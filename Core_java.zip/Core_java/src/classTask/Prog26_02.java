package classTask;
import java.util.Scanner;
public class Prog26_02
{
	Scanner sc=new Scanner(System.in);
	
	void m1()
	{
		System.out.println("m1() called");
		System.out.println("Enter 1st value: ");
		int a=sc.nextInt();
		System.out.println("Enter 2nd value: ");
		int b=sc.nextInt();
		System.out.println("1st value:"+a+"\n2nd value:"+b);
		int c=a+b;
		System.out.println("Addition of entered two value: "+c);
	}
	
	void m2(int a)
	{
		System.out.println("m2() called");
		System.out.println("Please enter the number to multiply with "+a);
		System.out.println("Multiplication of two values "+a*sc.nextInt());
	}
	
	int m3(int a,int b)
	{
		System.out.println("m3() called");
		System.out.println("Please enter a number: ");
		return a+b-sc.nextInt();
	}
	
	public static void main(String[] args)
	{
		Prog26_02 ob=new Prog26_02();
		ob.m1();
		System.out.println("Enter a integer value for m2() method");
		ob.m2(ob.sc.nextInt());
		System.out.println("Enter 2 integer value for m3() method");
		System.out.println(ob.m3(ob.sc.nextInt(),ob.sc.nextInt()));
	}
}
