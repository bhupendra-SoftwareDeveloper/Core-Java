package classTask;
import Basic.Protected_Aclass;

public class Protected_Xclass extends Protected_Aclass
{
	public static void main(String[] args)
	{
		Protected_Xclass ob=new Protected_Xclass();
		ob.display();
	}
}
