package classTask;

public class Purchase23_02
{
	public void m1(int a, int b)
	{
		int c;
		c=a*b;
		if(c>=1000) c-=c*.10;
		System.out.println("Total Cost="+c);
	}
	public static void main(String[] args)
	{
		new Purchase23_02().m1(5,100);
	}
}
