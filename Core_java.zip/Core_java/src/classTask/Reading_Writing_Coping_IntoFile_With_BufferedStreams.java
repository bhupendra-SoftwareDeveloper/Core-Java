package classTask;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.util.Scanner;

class BufferedStream
{
	void readingbyBufferedByteStream() throws Exception
	{
		BufferedInputStream bis=new BufferedInputStream(new FileInputStream("D:\\Let's Do It\\IOStreams\\BufferedStreams.txt"));
		int i;
		while((i=bis.read())!=-1)
			System.out.print((char)i);
		bis.close();
	}
	void writingbyBufferedByteStream() throws Exception
	{
		Scanner sc=new Scanner(System.in);
		BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream("D:\\Let's Do It\\IOStreams\\BufferedStreams.txt"));
		System.out.println("Enter the Contant: ");
		byte arr[]=sc.nextLine().getBytes();
		bos.write(arr);
		System.out.println("Data entered...");
		bos.close();
		sc.close();
	}
	void copingbyBufferedByteStream()throws Exception
	{
		BufferedInputStream bis=new BufferedInputStream(new FileInputStream("D:\\Let's Do It\\IOStreams\\BufferedStreams.txt"));
		BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream("D:\\Let's Do It\\IOStreams\\BufferedStreams2.txt"));
		int i;
		while((i=bis.read())!=-1)
			bos.write(i);
		System.out.println("Data copied...");
		bis.close();
		bos.close();
	}
	
	void readingbyBufferedCharacterStream() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("D:\\Let's Do It\\IOStreams\\BufferedStreamsByCharacter.txt"));
		int i;
		while((i=br.read())!=-1)
			System.out.print((char)i);
		br.close();
	}
	void writingbyBufferedCharacterStream() throws Exception
	{
		Scanner sc=new Scanner(System.in);
		BufferedWriter bw=new BufferedWriter(new FileWriter("D:\\Let's Do It\\IOStreams\\BufferedStreamsByCharacter.txt"));
		System.out.println("Enter The Contant: ");
		bw.write(sc.nextLine());
		System.out.println("Data Entered...");
		bw.close();
		sc.close();
	}
	void copingbyBufferedCharacterStream()throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("D:\\Let's Do It\\IOStreams\\BufferedStreamsByCharacter.txt"));
		BufferedWriter bw=new BufferedWriter(new FileWriter("D:\\Let's Do It\\IOStreams\\BufferedStreamsByCharacter2.txt"));
		int i;
		while((i=br.read())!=-1)
			bw.write(i);
		System.out.println("Data copied...");
		br.close();
		bw.close();
	}
}

public class Reading_Writing_Coping_IntoFile_With_BufferedStreams
{
	public static void main(String[] args) throws Exception
	{
		BufferedStream bs=new BufferedStream();
	//	bs.writingbyBufferedByteStream();
	//	bs.readingbyBufferedByteStream();
	//	bs.copingbyBufferedByteStream();
	//	bs.writingbyBufferedCharacterStream();
	//	bs.readingbyBufferedCharacterStream();
		bs.copingbyBufferedCharacterStream();
	}
}
