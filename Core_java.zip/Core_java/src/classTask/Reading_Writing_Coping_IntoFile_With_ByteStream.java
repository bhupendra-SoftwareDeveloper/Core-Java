package classTask;
import java.io.FileInputStream;
import java.io.FileOutputStream;
class Driver
{
	void readingFromfile() throws Exception
	{
		//Reading from file
		FileInputStream fis=new FileInputStream("D:\\Let's Do It\\IOStreams\\file1.txt");
		int i;
		while((i=fis.read())!=-1)
			System.out.print((char)i);
		fis.close();
	}
	
	void writingIntoFile() throws Exception
	{
		//Writing Into File
		FileOutputStream fos= new FileOutputStream("D:\\Let's Do It\\IOStreams\\file1.txt",true);
		String data=" And I am Java Full Stack Developer..";
		byte arr[]=data.getBytes();
		fos.write(arr);
		System.out.println("Data entered...");
		fos.close();
	}
	
	void copingIntoFile() throws Exception
	{
		FileInputStream fis=new FileInputStream("D:\\Let's Do It\\IOStreams\\file1.txt");
		FileOutputStream fos=new FileOutputStream("D:\\Let's Do It\\IOStreams\\file2.txt");
		int i;
		while((i=fis.read())!=-1)
			fos.write(i);
		System.out.println("Data copied...");
		fis.close();
		fos.close();
	}
}
public class Reading_Writing_Coping_IntoFile_With_ByteStream
{
	public static void main(String[] args) throws Exception
	{
		Driver d=new Driver();
	//	d.readingFromfile();
	//	d.writingIntoFile();
		d.copingIntoFile();
	}
}
