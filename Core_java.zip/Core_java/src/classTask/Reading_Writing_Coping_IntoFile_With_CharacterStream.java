package classTask;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

class CharacterStream
{
	void reading() throws Exception
	{
		FileReader fr=new FileReader("D:\\Let's Do It\\IOStreams\\CharacterStream.txt");
		int i;
		while((i=fr.read())!=-1)
			System.out.print((char)i);
		fr.close();
	}
	void writing() throws Exception
	{
		Scanner sc=new Scanner(System.in);
		FileWriter fw=new FileWriter("D:\\Let's Do It\\IOStreams\\CharacterStream.txt");
		System.out.println("Enter the Content: ");
		fw.write(sc.nextLine());
		System.out.println("Data entered...");
		fw.close();
		sc.close();
	}
	void coping() throws Exception
	{
		FileReader fr=new FileReader("D:\\Let's Do It\\IOStreams\\CharacterStream.txt");
		FileWriter fw=new FileWriter("D:\\Let's Do It\\IOStreams\\CharacterStream1.txt");
		int i;
		while((i=fr.read())!=-1)
			fw.write(i);
		System.out.println("Data copied...");
		fr.close();
		fw.close();
	}
}
public class Reading_Writing_Coping_IntoFile_With_CharacterStream
{
	public static void main(String[] args) throws Exception
	{
		CharacterStream cm=new CharacterStream();
	//	cm.writing();
	//	cm.reading();
		cm.coping();
	}
}
