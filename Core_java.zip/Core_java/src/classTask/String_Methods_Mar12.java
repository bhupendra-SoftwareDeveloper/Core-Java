package classTask;

public class String_Methods_Mar12
{
	public void display()
	{
		String s1="Java";
		String s2=new String("Java");
		String s3="Java";
		String s4=new String("Java");
		
		/* "==" -> it will compare the address location of the Strings
		   ".equals()" -> it will compare the content of the Strings 
		     both == & .equals() & startsWith() return result in boolean*/
		
		System.out.println("===============================");
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s2==s4);
		System.out.println(s1=="Java");
		System.out.println(s2==new String("Java"));
		System.out.println("===============================");
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals("java"));
		System.out.println("Java".equalsIgnoreCase("java"));
		System.out.println("===============================");
		System.out.println(s1.concat(" is awesome"));
		System.out.println(s1);
		String s5=s1.concat(" is awesome");
		System.out.println("s5 length():"+s5.length());
		System.out.println("charAt:"+s5.charAt(10));	//character at (index no)	
		System.out.println("charAt:"+"Java".charAt(1));
		System.out.println("charAt:"+"I Love".concat("India").charAt(6));
		System.out.println("startsWith():"+s5.startsWith(s1));	//checks both string start with same string or not
		System.out.println("startsWith():"+s5.startsWith("Java"));
		System.out.println("toLowerCase():"+s5.toLowerCase());
		System.out.println(s5);
		System.out.println("===============================");
		String s6="I Love India";
		System.out.println("subString():"+s6.substring(7));	//returns string from entered index no to the end of string
		System.out.println("subString():"+s6.substring(2,6));//returns string from entered index no to the entered index no +1
		System.out.println("subString():"+s6.substring(4,10));
		System.out.println("subString():"+s6.substring(s6.length()-3));
		System.out.println("===============================");
		System.out.println("replace():"+s1.replace('a', 'A'));
		String s7=" Hello World ";
		System.out.println("s7 lenght:"+s7.length());
		System.out.println("trim():"+s7.trim().length());	//removes only spaces from start of the string & end of the string
		System.out.println(s7.length());		
		System.out.println("indexOf():"+s7.indexOf('o'));	//returns index no of entered character 
		System.out.println("lastIndexOf():"+s7.lastIndexOf('o'));
	}
	
	public static void main(String[] args)
	{
		String_Methods_Mar12 s=new String_Methods_Mar12();
		s.display();
	}
}
