package classTask;

public class String_Methods_Mar15
{
	void m1()
	{
		StringBuffer buff1=new StringBuffer();
		buff1.append("abcdefghijklmnop");
		System.out.println("Default Capacity of StringBuffer: "+buff1.capacity());
		System.out.println(buff1);
		System.out.println("After enter 16 char Capacity of StringBuffer: "+buff1.capacity());
		System.out.println("Length of StringBuffer: "+buff1.length());
		buff1.append("q");
		System.out.println(buff1);

		//(current capacity*2)+2

		System.out.println("After enter 16 char & append 1 char Capacity of StringBuffer: "+buff1.capacity());
		System.out.println("Length of StringBuffer: "+buff1.length());
		System.out.println("charAt(): "+buff1.charAt(5));
		System.out.println("subString(): "+buff1.substring(buff1.length()-2));
		System.out.println("delete(): "+buff1.delete(5,15)); //deletes indxNo 5 to 15-1
		System.out.println("deleteCharAt(): "+buff1.deleteCharAt(1)); //delete char at indxNo
		System.out.println("reverse(): "+buff1.reverse());
	}
	
	public static void main(String[] args)
	{
		String_Methods_Mar15 s= new String_Methods_Mar15();
		s.m1();
	}
}
