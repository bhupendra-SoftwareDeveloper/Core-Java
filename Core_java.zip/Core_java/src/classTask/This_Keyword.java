package classTask;

public class This_Keyword
{
	This_Keyword m1()
	{
		System.out.println("Method1() called");
		return this;
	//	return new This_Keyword();	we can also use this
	}
	
	This_Keyword m2()
	{
		System.out.println("Method2() called");
		return this;
	}
	
	void m3()
	{
		System.out.println("Method3() called");
	}
	
	public static void main(String[] args)
	{
		new This_Keyword().m1().m2().m3();
	}
}
