package classTask;

public class This_Keyword2
{
	void m1()
	{
		System.out.println("Method1() called");
	}
	
	This_Keyword2()
	{
		this("Java is awesome");
		System.out.println("Default Constructor");
		this.m1();
	//	new This_Keyword2("Java is awesome");
	}
	
	This_Keyword2(String s)
	{
		System.out.println("Parameterized Constructor");
		System.out.println(s);
	}
	
	public static void main(String[] args)
	{
		new This_Keyword2(); 
	}
}
