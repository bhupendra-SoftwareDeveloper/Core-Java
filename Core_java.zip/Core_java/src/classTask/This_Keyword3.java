package classTask;

public class This_Keyword3
{
	public int m1(int a,int b)//ret=30
	{
		System.out.println("Method1() called");//3
		System.out.println(100);//4
		return (a+b)+10+(a-b);//30
	}
	
	public int m2()//ret=10
	{
		System.out.println("Methd2() called");//1
		return this.m3()+0;
	}
	
	public This_Keyword3()
	{
		this("Java is awesome");
		System.out.println(50);//10-->50
	}
	
	int m3()//ret=10
	{
		System.out.println("Method3() called");//2
		return 10;
	}
	
	public String m4(int a,String s)//a=30,s=java
	{
		System.out.println("Method4() called");//5
		a=a+4;//a=34
		System.out.println("a value is="+a);//6-->34
		System.out.println("s value is="+s);//7-->java
		return s+" is object oriented programming language";
	}
	
	public This_Keyword3(String s)//s=java is awesome
	{
		String result=this.m4(this.m1(this.m2(),5),"java");//this.m4(30,java)
		System.out.println(result);//8-->java is object oriented programming language
		System.out.println(s);//9-->java is awesome
	}
	
	public static void main(String[] args)
	{
		new This_Keyword3();
	}
}
