package classTask;

public class Using_Enum 
{
	void enumIn_Switch()
	{
		Days d=Days.Saturday;
	//	System.out.println("Today is: "+d);
		
		switch(d)
		{
			case Sunday:
				System.out.println("Today is: "+d);
				break;
			case Monday:
				System.out.println("Today is: "+d);
				break;
			case Tuesday:
				System.out.println("Today is: "+d);
				break;
			case Wednesday:
				System.out.println("Today is: "+d);
				break;
			case Thursday:
				System.out.println("Today is: "+d);
				break;
			case Friday:
				System.out.println("Today is: "+d);
				break;
			case Saturday:
				System.out.println("Today is: "+d);
				break;
		}
	}
	void enumIn_Array()
	{
		Days[] s=Days.values();
		for(Days d:s)System.out.println(d);
	}
	public static void main(String[] args) 
	{
		Using_Enum ue=new Using_Enum();
	//	ue.enumIn_Switch();
		ue.enumIn_Array();
	}

}
