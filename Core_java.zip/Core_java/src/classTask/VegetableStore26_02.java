package classTask;
import java.util.Scanner;
public class VegetableStore26_02
{
	Scanner sc=new Scanner(System.in);
	static double amt=1;
	double m1(String choice)
	{
		double dis;
		String c=choice.toLowerCase();
		switch(c)
		{
			case "onion":
			case "1":
				System.out.println("\nOnion\n1KG Onion is 30\nHow many KG you need?");
				amt=30*sc.nextFloat();
				
				if(amt>=500)
				{
					System.out.println(+amt/30+" KGs Onion Amount: "+amt);
					dis=amt*.05;
					System.out.println("5% Discount: "+dis);
					System.out.print("Net amount: ");
					return amt-dis;
				}
				else
				{
					System.out.print(+amt/30+"KGs Onion Amount: ");
					return amt;
				}
				
			case "chilli":
			case "2":
				System.out.println("\nChilli\n1KG Chilli is 60\nHow many KG you need?");
				amt=60*sc.nextFloat();
				
				if(amt>=500)
				{
					System.out.println(+amt/60+" KGs Chilli Amount: "+amt);
					dis=amt*.05;
					System.out.println("5% Discount: "+dis);
					System.out.print("Net amount: ");
					return amt-dis;
				}
				else
				{
					System.out.print(+amt/60+" KGs Chilli Amount: ");
					return amt;
				}
				
			case "tomato":
			case "3":
				System.out.println("\nTomato\n1KG Tomato is 55\nHow many KG you need?");
				amt=55*sc.nextFloat();
				
				if(amt>=500)
				{
					System.out.println(+amt/55+" KGs Tomato Amount: "+amt);
					dis=amt*.05;
					System.out.println("5% Discount: "+dis);
					System.out.print("Net amount: ");
					return amt-dis;
				}
				else
				{
					System.out.print(+amt/55+" KGs Tomato Amount: ");
					return amt;
				}
				
			case "brinjal":
			case "4":
				System.out.println("\nBrinjal\n1KG Brinjal is 50\nHow many KG you need?");
				amt=50*sc.nextFloat();
				
				if(amt>=500)
				{
					System.out.println(+amt/50+" KGs Brinjal Amount: "+amt);
					dis=amt*.05;
					System.out.println("5% Discount: "+dis);
					System.out.print("Net amount: ");
					return amt-dis;
				}
				else
				{
					System.out.print(+amt/50+" KGs Brinjal Amount: ");
					return amt;
				}
			case "ladies finger":
			case "5":
				System.out.println("\nLadies Finger\n1KG Ladies Finger is 40");
				amt=40*sc.nextFloat();

				if(amt>=500)
				{
					System.out.println(+amt/40+" KGs Ladies Finger Amount: "+amt);
					dis=amt*.05;
					System.out.println("5% Discount: "+dis);
					System.out.print("Net amount: ");
					return amt-dis;
				}
				else
				{
					System.out.print(+amt/40+" KGs Ladies Finger Amount: ");
					return amt;
				}
				
			default	: System.out.println("!!!Please select only mentioned Vegetable");
		}
		return 0;
	}
	public static void main(String[] args)
	{
		VegetableStore26_02 ob=new VegetableStore26_02();
		System.out.println("Welcome To Our Vegetable Store\n1.Onion\n2.Chilli\n3.Tomato\n4.Brinjal\n5.Ladies Finger\n\nPlease Choose Vegetable: ");
		System.out.println(ob.m1(ob.sc.nextLine())+"\nThank you for shopping with us....Visit Again");
	}
}
