package exam;
	
	public class Feb26 {
		static int sum=0;
		static int getDimentionalSum(int arr[][]) {
			if(arr.length<3)return -1;
			for(var a=0;a<arr.length;a++) {
				sum=sum+arr[a][a];
			}
			return sum;
		}
		public static void main ( String [ ] args ) {
			int arr[][]= {{1,2,3},{1,8,3}};
			System.out.println ( getDimentionalSum(arr) );
		}
	}	
