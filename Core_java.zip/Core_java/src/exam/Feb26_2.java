package exam;

public class Feb26_2
{
		static int getElePosition(int a,int[]b) {
			if(b.length==0)return -2;
			if(a<1)return -3;
			for(var c=0;c<b.length;c++) if(b[c]<0)return -4;
			for(var d=0;d<b.length;d++) if(b[d]==a)return (d+1);
			return -1;
		}
		public static void main ( String [ ] args ) {
			int[]arr= {606,4,54,54,5};
			System.out.println ( getElePosition(50,arr) ) ;
		}
	}
