package exception_Handling;
//   NOTE:-
//------------
//(1) if we are writing multiple catch blocks then child class exception
//		must followed by parent class exception
//(2) if we are handling two exception in one catch block then there should not be 
//		parent child relationship between the exception classes.
public class Basic
{
	void m1()
	{
		System.out.println(10);
		try
		{
			System.out.println(20/0);
		}
		catch(ArithmeticException a)
		{
			System.out.println("Exception caught");
		//	System.out.println(a.getMessage()); //will print reason of Exception
		//	System.out.println(a.toString()); //will print reason & name of Exception
			a.printStackTrace();
		//printStackTrace()-->will print reason of & name with full information with method/block name and caller name too Exception
		}
		finally
		{
			System.out.println("Finally block executed");
		}
		
		System.out.println(30);
	}
	
	public static void main(String[] args)
	{
		new Basic().m1();
	}
}
