package exception_Handling;

public class ThrowKeyword
{
	int avl_amt=1000;
	void with_draw(int wd_amt)
	{
		if(avl_amt<wd_amt)
			throw new RuntimeException("Insufficent balance!");
		else
			System.out.println("Transaction Successfully..");
	}
	public static void main(String[] args)
	{
		ThrowKeyword tk=new ThrowKeyword();
		tk.with_draw(500);
	}
}
