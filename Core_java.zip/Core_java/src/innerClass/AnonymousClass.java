package innerClass;

public class AnonymousClass 
{
	static OuterClassAnonymous out=new OuterClassAnonymous()
	{
		void print()
		{
			super.print();
			System.out.println("I am from Anonymous class...");
		}
	};
	
	public static void main(String[] args) 
	{
		out.print();
	}
}
