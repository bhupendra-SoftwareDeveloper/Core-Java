package innerClass;

public class Method_Local_InnerClass 
{
	void m1()
	{
		String x="Java";
		class InnerClass
		{
			void display()
			{
				System.out.println("This is "+x);
			}
		}
		new InnerClass().display();
	}
	public static void main(String[] args) 
	{
		Method_Local_InnerClass mli=new Method_Local_InnerClass();
		mli.m1();
	}
}
