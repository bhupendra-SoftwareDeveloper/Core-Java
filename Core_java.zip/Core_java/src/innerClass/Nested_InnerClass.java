package innerClass;

public class Nested_InnerClass 
{
	void outMeth()
	{
		System.out.println("This Is Method of Outer Class");
	}
	
	public Nested_InnerClass()
	{
		System.out.println("Outer Class Constructor");
	}
	
	class InnerClass
	{
		void innMeth()
		{
			System.out.println("This Is Method of Innner Class");
		}
		
		public InnerClass()
		{
			System.out.println("Inner Class Constructor");
		}
	}
	
	public static void main(String[] args)
	{
		Nested_InnerClass.InnerClass ic=new Nested_InnerClass().new InnerClass();
		ic.innMeth();
		Nested_InnerClass ni=new Nested_InnerClass();
		ni.outMeth();
	}
}
