package innerClass;

public class OuterClassAnonymous 
{
	void print()
	{
		System.out.println("This is print method of of OuterClassAnonymous..");
	}
}
