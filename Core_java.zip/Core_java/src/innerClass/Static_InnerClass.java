package innerClass;

public class Static_InnerClass 
{
	void instance()
	{
		System.out.println("Instance method called of Outer Class");
	}
	static void staticinstance()
	{
		System.out.println("Static method called of Outer Class");
		new InnnerClass().instance();
	}
	
	static {
		System.out.println("Static Block of Outer class ");
	}
	
	
	static class InnnerClass
	{
		void instance()
		{
			System.out.println("Instance method called of Inner Class");
		}
		static void staticinstance()
		{
			System.out.println("Static method called of Inner Class");
		}
		static {
			System.out.println("Static Block of Inner class ");
		}
		public static void main(String[] args)
		{
			System.out.println("Main method executed of inner class");
		//	new Static_InnerClass().instance();
			Static_InnerClass.staticinstance();
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Main method executed of Outer class");
	//	new Static_InnerClass().instance();
		Static_InnerClass.staticinstance();
	//	Static_InnerClass.InnnerClass inn=new Static_InnerClass.InnnerClass();
	//	inn.instance();
	}
}
