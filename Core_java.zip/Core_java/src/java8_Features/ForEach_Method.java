package java8_Features;
import java.util.ArrayList;
public class ForEach_Method
{
	void m1()
	{
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(4);
		al.add(45);
		al.add(52);
		al.add(95);
		al.add(37);
		al.add(15);
		al.add(10);
		al.add(95);
		
		System.out.println("Retriving using for-each loop...");
		for(Integer i:al)System.out.println(i);
		System.out.println();
		System.out.println("Retriving using forEach() method...");
		al.forEach(data->System.out.println(data));
	}
	public static void main(String[] args) 
	{
		new ForEach_Method().m1();
	}
}
