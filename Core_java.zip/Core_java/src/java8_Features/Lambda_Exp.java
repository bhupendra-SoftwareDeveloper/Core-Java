package java8_Features;

public class Lambda_Exp
{
	void display()
	{
		Lambda_InterfaceA x=()->System.out.println("Hello this is first lambda...");
		x.m1();
		
		System.out.println();
		Lambda_InterfaceB y=(int p,int q)->System.out.println(p+q);
		y.m2(10,30);
		System.out.println();
		Lambda_InterfaceC z=(int j,int k)->
		{
			if(j<10) return j+10;
			else return k-j;
		};
		int data=z.m3(5,25);
		System.out.println(data);
	}
	public static void main(String[] args)
	{
		new Lambda_Exp().display();
	}
}
