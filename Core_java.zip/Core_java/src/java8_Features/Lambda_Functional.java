package java8_Features;

public class Lambda_Functional
{
	void display()
	{
		Lambda_Functional_Interface x=data->System.out.println("Hello");
		x.m1("Java");
	}
	
	public static void main(String[] args)
	{
		new Lambda_Functional().display();
	}
}
