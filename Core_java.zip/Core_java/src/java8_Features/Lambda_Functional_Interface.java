package java8_Features;

public interface Lambda_Functional_Interface
{
	void m1(String s);
}
