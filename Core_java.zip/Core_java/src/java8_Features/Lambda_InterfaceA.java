package java8_Features;

public interface Lambda_InterfaceA
{
	void m1();
}
