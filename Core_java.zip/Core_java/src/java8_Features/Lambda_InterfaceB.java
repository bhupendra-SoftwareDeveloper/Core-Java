package java8_Features;

public interface Lambda_InterfaceB
{
	void m2(int a,int b);
}
