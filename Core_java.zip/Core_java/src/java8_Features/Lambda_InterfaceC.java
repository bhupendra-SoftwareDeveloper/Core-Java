package java8_Features;

public interface Lambda_InterfaceC
{
	int m3(int d,int e);
}
