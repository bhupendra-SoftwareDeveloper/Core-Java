package java8_Features;

public class Method_ReferenceA 
{
	void m1(String s)
	{
		System.out.println("Non-static method");
		System.out.println(s);
	}
	static void m2(String s)
	{
		System.out.println("Static method");
		System.out.println(s);
	}
	Method_ReferenceA(String s)
	{
		System.out.println("Constructor");
		System.out.println(s);
	}
}
