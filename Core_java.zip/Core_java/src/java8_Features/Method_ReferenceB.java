package java8_Features;

public class Method_ReferenceB 
{
	public static void main(String[] args)
	{
	//	Method_Reference_Interface x=new Method_ReferenceA()::m1;//for Non static method
	
		Method_Reference_Interface x=Method_ReferenceA::m2;// for Static method
		
	//	Method_Reference_Interface x=Method_ReferenceA::new;//for Constructor call
		x.display("Java");
	}
}
