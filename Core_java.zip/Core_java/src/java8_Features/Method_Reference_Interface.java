package java8_Features;

public interface Method_Reference_Interface
{
	void display(String s);
}
