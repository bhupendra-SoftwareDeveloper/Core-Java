package java8_Features;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class Prac1_StreamApI_Methods 
{
	void m1()
	{
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(15);
		al.add(5);
		al.add(67);
		al.add(96);
		al.add(45);
		al.add(78);
		al.add(9);
		al.add(67);
		
		System.out.println("Original Data: "+al);
		Stream<Integer>s=al.stream().sorted();
		List<Integer>li=s.collect(Collectors.toList());
		System.out.println("Sorted Data: "+li);
		Collections.sort(li,Collections.reverseOrder());
		System.out.println("Reversed Data: "+li);	
		
	/*	Stream <Integer>s=al.stream().filter(data->data>80);
		long l=s.count();
		System.out.println(l);	*/
		
	/*	Stream<Integer> s=al.stream().map(data->data*5);
		List<Integer>li=s.collect(Collectors.toList());
		System.out.println(li);	*/
	}
	
	public static void main(String[] args) 
	{
		new Prac1_StreamApI_Methods().m1();
	}
}
