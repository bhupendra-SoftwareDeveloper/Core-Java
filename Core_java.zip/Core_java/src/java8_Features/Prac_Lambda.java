package java8_Features;

public class Prac_Lambda
{
	void perform()
	{
		Prac_Lambda_Interface1 op=(int a,int b,char c)->{
			if(c=='+')return a+b;
			else if(c=='*')return a*b;
			else if(c=='/')return a/b;
			else return a-b;
		};
		int k=op.m1(10, 20, '-');
		System.out.println(k);
	}
	public static void main(String[] args)
	{
		new Prac_Lambda().perform();
	}

}
