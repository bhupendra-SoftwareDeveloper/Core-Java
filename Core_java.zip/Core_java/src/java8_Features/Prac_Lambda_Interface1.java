package java8_Features;

public interface Prac_Lambda_Interface1
{
	int m1(int x,int y,char c);
}
