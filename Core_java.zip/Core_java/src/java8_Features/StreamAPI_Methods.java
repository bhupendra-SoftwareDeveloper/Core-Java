package java8_Features;
import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.List;
public class StreamAPI_Methods
{
	void m1()
	{
		ArrayList<String> al=new ArrayList<String>();
		al.add("Kishan");
		al.add("Radha");
		al.add("Seeta");
		al.add("Ram");
		al.add("Meera");
		al.add("devanshi");
		al.add("Radhika");
		al.add("Rashmika");
		
	/*	Stream<String>s1=al.stream();
		Stream<String>s2=s1.filter(data->data.length()>5);
	*/
		Stream <String>s2=al.stream().filter(data->data.length()>5);
		long l=s2.count();
		System.out.println(l);
	}
	
	void m2()
	{
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(4);
		al.add(45);
		al.add(52);
		al.add(95);
		al.add(37);
		al.add(15);
		al.add(10);
		al.add(95);
		
		System.out.println("Data in ArrayList: "+al);
		
	/*	Stream<Integer>s1=al.stream();
		Stream<Integer>s2=s1.map(x->x*x);
	*/
		Stream<Integer>s2=al.stream().map(x->x*x);
		List<Integer> li=s2.collect(Collectors.toList());
	//	ArrayList<Integer>li=(ArrayList<Integer>)s2.collect(Collectors.toList());
	
		System.out.println(li);
		
	}
	
	void m3()
	{
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(4);
		al.add(45);
		al.add(52);
		al.add(95);
		al.add(37);
		al.add(15);
		al.add(10);
		al.add(95);
		
		System.out.println("Data in ArrayList: "+al);
		
	/*	Stream<Integer>s1=al.stream();
		Stream<Integer>s2=s1.sorted();
	*/
		Stream<Integer> s2=al.stream().sorted();
		
		List<Integer>li=s2.collect(Collectors.toList());
		System.out.println("Natural Sorting: "+li);
		
		Collections.sort(li,Collections.reverseOrder());
		System.out.println("Reverse Order: "+li);
	}
	public static void main(String[] args)
	{
		StreamAPI_Methods sam=new StreamAPI_Methods();
	//	sam.m1();
	//	sam.m2();
		sam.m3();
	}
}
