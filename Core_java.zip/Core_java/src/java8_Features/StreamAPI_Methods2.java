package java8_Features;
import java.time.LocalDate;
import java.util.Random;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Optional;
public class StreamAPI_Methods2
{
	void m1()
	{
		String arr[]=new String[3];
		arr[1]="Sam";
		arr[2]="Ram";
		System.out.println(arr[0].length()); //NPE
	}
	
	void sorting()
	{
		int arr[]=new int[20];
		Random r=new Random();
		for(int i=0;i<arr.length;i++)
			arr[i]=r.nextInt(30);
		System.out.println("Data are following: ");
		for(int x:arr)System.out.println(x);
//		Arrays.sort(arr);
//		System.out.println("After sort...");
//		for(int x:arr)System.out.println(x);
		
		Arrays.parallelSort(arr);	//more efficient than Arrays.sort();
		System.out.println("After sort.....");
		for(int x:arr)System.out.println(x);
	}
	void zoneid()
	{
		for(String s:ZoneId.getAvailableZoneIds())
			System.out.println(s);
	}
	
	void dateTime()
	{
		System.out.println(LocalTime.now());
		System.out.println(LocalDate.now());
		System.out.println(LocalDateTime.now());
		System.out.println(LocalTime.now(ZoneId.of("Asia/Singapore")));
	}
	
	void optionalClass()
	{
		String s[]=new String[3];
		s[0]="Java";
		s[1]="Oracle";
		
		Optional<String> o=Optional.ofNullable(s[2]);
		
		if(o.isPresent())
			System.out.println("Data is: "+o);
		else
			System.out.println("Its Empty");
	}
	
	public static void main(String[] args)
	{
		StreamAPI_Methods2 sam=new StreamAPI_Methods2();
	//	sam.sorting();
		sam.dateTime();
	//	sam.optionalClass();
	//	sam.zoneid();
	}
}
