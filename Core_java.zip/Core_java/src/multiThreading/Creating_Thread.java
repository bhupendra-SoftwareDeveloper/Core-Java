package multiThreading;

public class Creating_Thread extends Thread
{
	public void run()
	{
		System.out.println("Thread is running");
	}
	
	
	public static void main(String[] args)
	{
		Thread ct=new Creating_Thread();
		ct.start();
	//this time thread will not created..
	//it acts like a normal method call as ct.run();==ct.start();
	// if we do following thing then new thread will be created.
		Thread t=new Thread(ct);
		t.start();
	}
}
