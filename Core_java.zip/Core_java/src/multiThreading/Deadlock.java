package multiThreading;

public class Deadlock
{
	public static void main(String[] args)
	{
		final String a="Java";
		final String b="Python";
		
		Thread t1=new Thread()
			{
				public void run()
				{
					synchronized (a)
					{
						System.out.println("Thread 1 locked in a");
						try
						{
							Thread.sleep(500);//Priority given to the another Thread
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						synchronized (b)  //Waiting for complete execution of b
						{
							System.out.println("Thread 1 locked in b");
						}
						System.out.println("No dead lock");
					}
				}
			};

		Thread t2=new Thread()
				{
					public void run()
					{
						synchronized (b)
						{
							System.out.println("Thread 2 locked in b");
							try
							{
								Thread.sleep(500);	//Priority given to the another Thread
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
							synchronized (a)	//Waiting for complete execution of a
							{
								System.out.println("Thread 2 locked in a");
							}
						}
						System.out.println("No dead lock");
					}
				};
				t1.start();
				t2.start();
		}
}