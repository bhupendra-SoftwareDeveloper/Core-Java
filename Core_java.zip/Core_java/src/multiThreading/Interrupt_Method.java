package multiThreading;

public class Interrupt_Method extends Thread
{
	public void run()
	{
		System.out.println("Ready for Interview");
		for(int i=1;i<6;i++)
			System.out.println("this is my "+i+" Interview");

		System.out.println("Selected");
		
		try 
		{
			Thread.sleep(5000);
		}
		
		catch(Exception c)
		{
			System.out.println("My sleep got disturbed");
		}
		
		System.out.println("Now i have to go to office");
	}
	
	public static void main(String[] args)
	{
		Interrupt_Method im=new Interrupt_Method();
		Thread t=new Thread(im);
		t.start();
		t.interrupt();
	}
}
//Whenever Thread will goto sleep then immediately interrupt method will bring back from sleep 