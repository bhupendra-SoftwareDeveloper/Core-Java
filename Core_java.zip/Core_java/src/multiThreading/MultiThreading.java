package multiThreading;
class Multi extends Thread
{
	public void run()
	{	String s=Thread.currentThread().getName();
		for(int i=1;i<=5;i++)
			System.out.println(s+" : "+i);
		System.out.println("-----------------------------");
	}
}

public class MultiThreading
{
	public static void main(String[] args) throws InterruptedException
	{
		Multi m=new Multi();
		Thread t=new Thread(m);
		Thread t2=new Thread(m);
		t.setName("First Thread");
		t2.setName("Second Thread");
		t.start();
		t.join();
		Thread.sleep(3000);
		t2.start();
	}
}
