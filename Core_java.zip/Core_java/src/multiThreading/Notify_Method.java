package multiThreading;

class Notify implements Runnable
{   int total=0;
	public void run()
	{	
		synchronized (this)
		{
			for(int i=1;i<6;i++)
			{
				System.out.println("Thread Executed: "+i+" Times");
				total+=100;
			}
			this.notify();
		}
	}
}

public class Notify_Method
{
	public static void main(String[] args) throws InterruptedException
	{
		Notify n=new Notify();
		Thread t=new Thread(n);
		t.start();
		synchronized(n)
		{
			n.wait();
		}
		System.out.println("Total amount : "+n.total);
	}
}
