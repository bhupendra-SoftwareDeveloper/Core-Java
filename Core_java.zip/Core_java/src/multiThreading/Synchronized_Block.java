package multiThreading;

class SynchroBlock extends Thread
{
	public void run()
	{
		String name=Thread.currentThread().getName();
		
		synchronized(this)
		{
			for(int i=1;i<6;i++)
				System.out.println(name+" is Executing "+i+ " Time");
			System.out.println(name+" Execution Complete");
			System.out.println();
		}
		
		for(int i=1;i<6;i++)
			System.out.println(name+"-->"+i);
	}
}

public class Synchronized_Block
{
	public static void main(String[] args)
	{
		SynchroBlock synblk=new SynchroBlock();
		Thread t1=new Thread(synblk);
		Thread t2=new Thread(synblk);
		Thread t3=new Thread(synblk);
		t1.setName("First Thread");
		t2.setName("Second Thread");
		t3.setName("Third Thread");
		t1.start();
		t2.start();
		t3.start();
	}
}
