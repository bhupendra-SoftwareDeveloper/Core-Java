package multiThreading;

class Synchronized extends Thread
{
	public void run()
	{
		criticalResource();
	}
	
	synchronized void criticalResource()
	{
		String name=Thread.currentThread().getName();
		for(int i=1;i<6;i++)
			System.out.println(name+" is Executing "+i+ " Time");
		System.out.println(name+" Execution Complete");
		System.out.println();
	}
}

public class Synchronized_Method
{
	public static void main(String[] args)
	{
		Synchronized syn=new Synchronized();
		Thread t1=new Thread(syn);
		Thread t2=new Thread(syn);
		
		t1.setName("First Thread");
		t2.setName("Second Thread");
		t1.start();
		t2.start();
	}
}
