package multiThreading;

class Yield extends Thread
{
	public void run()
	{
		for(int i=1;i<6;i++)
			System.out.println("First class "+i);
	}
}

public class Yield_Method extends Thread
{
	public static void main(String[] args)
	{
		Yield y=new Yield();
		y.start();
		Thread.yield();
		for(int i=1;i<6;i++)
		{
			System.out.println("Main Thread "+i);
		}
	}
}
