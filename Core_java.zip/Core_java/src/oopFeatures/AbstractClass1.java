package oopFeatures;

public abstract class AbstractClass1
{
	public abstract void m1();
	public abstract int m1(int a,int b);
	void m2()
	{
		System.out.println("M2 Method called");
	}
	static void m3()
	{
		System.out.println("static M3 Method called");
	}
	AbstractClass1()
	{
		this("Java is awesome");
		System.out.println("AbstractClass1 non-parameterized constructor executed");
	}
	AbstractClass1(String s)
	{
		System.out.println(s);
	}
	public static void main(String[] args)
	{
		System.out.println("main() called");
	//	AbstractClass1 abs=new AbstractClass1(); //C.E Abstract can't instantiate
		AbstractClass1.m3();
	}
}
