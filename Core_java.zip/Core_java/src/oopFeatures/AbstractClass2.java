package oopFeatures;

public class AbstractClass2 extends AbstractClass1
{
	public void m1()
	{
		System.out.println("Abstract method Overridden");
	}
	public int m1(int x,int y)
	{
		System.out.println("Abstract method can be Overloaded");
		return x+y;
	}
	public static void main(String[] args)
	{
		AbstractClass1 ab=new AbstractClass2();
		ab.m1();
		System.out.println(ab.m1(50,49));
		ab.m2();
	}
}
