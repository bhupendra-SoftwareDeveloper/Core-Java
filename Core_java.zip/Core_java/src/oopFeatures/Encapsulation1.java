package oopFeatures;

public class Encapsulation1
{
	private int eid;
	private String ename;
	private int salary;
	private int exp;
	
	public int getEid()
	{
		return eid;
	}
	
	public void setEid(int eid)
	{
		this.eid = eid;
	}
	
	public String getEname()
	{
		return ename;
	}
	
	public void setEname(String ename)
	{
		this.ename = ename;
	}
	
	public int getSalary()
	{
		return salary;
	}
	
	public void setSalary(int salary)
	{
		this.salary = salary;
	}
	
	public int getExp()
	{
		return exp;
	}

	public void setExp(int exp)
	{
		if(exp>10) salary+=salary*0.10;
		else if(exp>5&&exp<10) salary+=salary*0.05;
		else salary+=salary*0.02;
		this.exp = exp;
	}

}
