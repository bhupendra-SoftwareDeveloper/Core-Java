package oopFeatures;
import java.util.Scanner;

public class Encapsulation2
{	
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{	
		Encapsulation1 e1=new Encapsulation1();
		System.out.println("Enter Employee Id: ");
		e1.setEid(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Employee Name: ");
		e1.setEname(sc.nextLine());
		System.out.println("Enter Employee Salary: ");
		e1.setSalary(sc.nextInt());
		System.out.println("Enter Employee's Experiance: ");
		e1.setExp(sc.nextInt());
		System.out.println("------------------- ENCAPSULATED DATA -------------------");
		System.out.println("Employee Id: "+e1.getEid()+"\n"+"Employee Name: "+e1.getEname()+"\n"+"Employee Salary: "+e1.getSalary());
	}
}
