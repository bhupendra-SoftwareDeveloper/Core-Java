package oopFeatures;

public interface Interface1
{
	void m1();	//by default every method is public abstract
	
	static void m2()
	{
		System.out.println("Static method from Interface1");
		System.out.println("Available from 1.8v onwards");
	}
	default void m3()
	{
		System.out.println("Default method from Interface1");
		System.out.println("Available from 1.8v onwards");
		this.m4();
	}
	private void m4()
	{
		System.out.println("Private method from Interface1");
		System.out.println("Available from 1.9v onwards");
	}
	public static void main(String[] args)
	{
		System.out.println("Main method from Interface1");
		System.out.println("Available from 1.8v onwards");
		Interface1.m2();
	}
}
