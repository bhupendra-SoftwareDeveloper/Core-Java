package oopFeatures;

public interface Interface2
{
	void show();
}
