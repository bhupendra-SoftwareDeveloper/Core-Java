package oopFeatures;

public class Interface_ClassA
{
	void display()
	{
		System.out.println("ClassA method called");
	}
}
