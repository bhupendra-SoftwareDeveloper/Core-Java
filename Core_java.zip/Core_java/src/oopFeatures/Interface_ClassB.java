package oopFeatures;

public class Interface_ClassB extends Interface_ClassA implements Interface1,Interface2
{
	public void m1()
	{
		System.out.println("Interface1 M1 abstract method Overridden");
	}
	public void show()
	{
		System.out.println("Interface2 show abstract method Overridden");
	}
	public static void main(String[] args)
	{
		Interface1 i1=new Interface_ClassB();
		i1.m1();
		System.out.println("------------------------------");
		Interface2 i2=new Interface_ClassB();
		i2.show();
		System.out.println("------------------------------");
		i1.m3();
		System.out.println("------------------------------");
		new Interface_ClassA().display();
	}
}
