package oopFeatures;

public class MultiLevel_Inhertance1
{
	void m1()
	{
		System.out.println("Grand Parent Class Method Called");
	}
}
