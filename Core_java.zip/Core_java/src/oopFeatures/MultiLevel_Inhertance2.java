package oopFeatures;

public class MultiLevel_Inhertance2 extends MultiLevel_Inhertance1		
{
	void m2()
	{
		System.out.println("Parent Class Method Called");
	}
}
