package oopFeatures;

public class MultiLevel_Inhertance3 extends MultiLevel_Inhertance2
{
	void m3()
	{
		System.out.println("Child Class Method Called");
	}
	
	public static void main(String[] args)
	{
		MultiLevel_Inhertance3 ml3=new MultiLevel_Inhertance3();
		ml3.m1();
		ml3.m2();
		ml3.m3();
	}
}
