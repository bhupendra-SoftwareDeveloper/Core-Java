package oopFeatures;

public class Polymorphism_ConstructorOverLoading
{
	Polymorphism_ConstructorOverLoading()
	{
		this("Java");
		System.out.println("Non-Parameterized Constructor Executed");
	}
	Polymorphism_ConstructorOverLoading(String s)
	{
		this(55);
		System.out.println("String type-Parameterized Constructor Executed");
	}
	Polymorphism_ConstructorOverLoading(int a)
	{
		this('B');
		System.out.println("Int type-Parameterized Constructor Executed");
	}
	Polymorphism_ConstructorOverLoading(char x)
	{
		System.out.println("Char type-Parameterized Constructor Executed");
	}
	public static void main(String[] args)
	{
		new Polymorphism_ConstructorOverLoading();
	}
}
