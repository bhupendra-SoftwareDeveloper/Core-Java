//we can overload any method but must having different parameter
//either static,non-static,diffrent return type,any access modifier,final etc...

package oopFeatures;

public class Polymorphism_MethodOverLoading
{
	public final void m1()
	{
		System.out.println(10);
	}
	private final int m1(int a)
	{
		System.out.println(20);
		return a;
	}
	protected void m1(int a,String s)
	{
		System.out.println(30);
	}
	public String m1(String s,int a)
	{
		System.out.println(40);
		return s;
	}
	void m1(String s)
	{
		System.out.println(50);
	}
	
	public static void main(String[] args)
	{
		Polymorphism_MethodOverLoading methover=new Polymorphism_MethodOverLoading();
		methover.m1();
		methover.m1(300);
		methover.m1(400,"Java");
		methover.m1("How's",10);
		methover.m1("Java is Awesome");
		methover.m1(10);
		methover.main(999);	
		methover.main("C");
	}
	
	public static void main(String s)
	{
		System.out.println(s);
	}
	public static void main(int a)
	{
		System.out.println("C is middle level language");
	}
}
