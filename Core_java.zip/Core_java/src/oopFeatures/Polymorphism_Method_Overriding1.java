package oopFeatures;

public class Polymorphism_Method_Overriding1
{
	protected void m1() //Overridden Method
	{
		System.out.println("This is Super class method");
	}
	protected static void m2() //Overridden Method
	{
		System.out.println("This is parent class method ");
	}
	Polymorphism_Method_Overriding1 display(int a)	//Overridden Method
	{
		System.out.println("Hii");
		System.out.println(500+a);
		return this;
	}
}
