package oopFeatures;

public class Polymorphism_Method_Overriding2 extends Polymorphism_Method_Overriding1
{
	public void m1()	//Overriding Method
	{
		System.out.println("This is Sub class method");
	}
	protected static void m2() //Method Hiding
	{
		System.out.println("This is child class method ");
	}
	Polymorphism_Method_Overriding2 display(int x)	//Overriding Method
	{
		System.out.println("Hello");
		System.out.println(500-x);
		return this;
	}
	public static void main(String[] args)
	{
		Polymorphism_Method_Overriding1 ob1=new Polymorphism_Method_Overriding2();
		ob1.m1();
		ob1.m2();
		ob1.display(500);
		System.out.println("-----------------------------");
		new Polymorphism_Method_Overriding1().display(500);
	}
}
