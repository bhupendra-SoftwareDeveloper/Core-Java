package oopFeatures;

public class SingleLevel_Inhertance1
{
	void m1()
	{
		System.out.println("Parent Class Method Called");
	}
}
