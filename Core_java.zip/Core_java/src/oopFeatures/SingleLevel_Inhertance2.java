package oopFeatures;

public class SingleLevel_Inhertance2 extends SingleLevel_Inhertance1
{
	void m2()
	{
		System.out.println("Child Class Method Called");
	}
	
	public static void main(String[] args)
	{
		SingleLevel_Inhertance1 sli1=new SingleLevel_Inhertance1();
		
		sli1.m1();	//HAS-A RELATIONSHIP
	
		//	sli1.m2();	// C.E Parent Class reference can't call child class 
					//	methods
		
		SingleLevel_Inhertance2 sli2=new SingleLevel_Inhertance2();
		
		sli2.m1();	// Child Class reference can call both child class &
					//	Parent class methods
	
		sli2.m2();	//IS-A RELATIONSHIP
	}
}
