package oopFeatures;

public class SuperAndThis_Key_and_Construc_Inheritance1
{
	void m1()
	{
		System.out.println(10);
		System.out.println(this.m2()+56);
	}
	int m2()
	{
		System.out.println(75);
		System.out.println(96);
		return this.m3();
	}
	int m3()
	{
		System.out.println(74);
		System.out.println(92);
		return 74-92;
	}
	void m4()
	{
		System.out.println(56);
	}
	SuperAndThis_Key_and_Construc_Inheritance1()
	{
		this(52);
		this.m1();
		System.out.println(85);
	}
	SuperAndThis_Key_and_Construc_Inheritance1(int a)
	{
		System.out.println(a+7);
	}
}
