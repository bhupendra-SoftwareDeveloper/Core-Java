package oopFeatures;

public class SuperAndThis_Key_and_Construc_Inheritance2 extends SuperAndThis_Key_and_Construc_Inheritance1
{
	void display()
	{
		System.out.println("Hii");
		super.m4();
	}
	public static void main(String[] args)
	{
		new SuperAndThis_Key_and_Construc_Inheritance2().display();
	}
}
