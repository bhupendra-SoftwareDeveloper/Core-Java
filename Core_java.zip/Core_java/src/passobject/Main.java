package passobject;

public class Main {
	public static void main(String[] args) {
		Student s=new Student("Chiranjib",1601329090);
		University u=new University(s);
		u.print();
	}
}
