package passobject;

public class Student {
	String name;
	int rollNo;
	
	
	Student(String name, int rollNo){
		this.name=name;
		this.rollNo=rollNo;
	}
	
}
