package passobject;

public class University {
	String uName;
	int uRollNo;
	
	University(Student std){
		uName=std.name;
		uRollNo=std.rollNo;
	}
	
	
	void print() {
		Student s=new Student("Hello",1254);
		System.out.println("Name is:"+uName);
		System.out.println("Roll is:"+uRollNo);
		System.out.println("Name is:"+s.name);
		System.out.println("Roll is:"+s.rollNo);
	}
	
}
