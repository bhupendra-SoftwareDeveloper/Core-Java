package thisthis;

public class Test1 {
	int a =10;
	static int b=20;
	void m1(int a) {
		this.a=a;
		System.out.println(a);//111//0
		System.out.println(this);//string formate 2nd time diff
		System.out.println(this.b);//20//20
	}
	public static void main(String[] args) {
		Test1 t=new Test1();
		Test1 t1=new Test1();
		System.out.println(t);
		t.m1(111);
		t1.m1(0);
		System.out.println(t.a);//111
	}
}
