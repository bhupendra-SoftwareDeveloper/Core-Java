package wrapperClass;

public class Wrapper
{
	void autoBoxing()
	{
		System.out.println("-------------AutoBoxing-------------");
		int i=10;
		Integer ival=Integer.valueOf(i);
		System.out.println("int Primitive Data Type:"+i);
		System.out.println("Integer Wrapper Class Object:"+ival);

		char c='A';
		Character cval=Character.valueOf(c);
		System.out.println("char Primitive Data Type:"+c);
		System.out.println("Character Wrapper Class Object:"+cval);
		System.out.println("-------------------------------------");
	}
	
	void autoUnboxing()
	{
		System.out.println("-------------AutoUnboxing-------------");
		Integer ival=new Integer(100);
		int x=ival.intValue();
		System.out.println("Integer Wrapper Class Object:"+ival);
		System.out.println("int Primitive Data Type:"+x);
		
		Boolean booleanval=new Boolean("TruE");
		boolean flag=booleanval.booleanValue();
		System.out.println("Boolean Wrapper Class Object:"+booleanval);
		System.out.println("boolean Primitive Data Type:"+flag);
	}
	
	public static void main(String[] args)
	{
		Wrapper obj=new Wrapper();
		obj.autoBoxing();
		obj.autoUnboxing();
	}
}
