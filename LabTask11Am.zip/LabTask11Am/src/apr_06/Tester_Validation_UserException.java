package apr_06;

class Validator
{
	public boolean validatePassword(String s) throws Exception
	{
		int u=0,l=0,space=0,sp=0,d=0;
		for(int i=0;i<s.length();i++)
		{
			if(Character.isUpperCase(s.charAt(i))) u++;
			else if(Character.isLowerCase(s.charAt(i))) l++;
			else if(Character.isDigit(s.charAt(i))) d++;
			else if(Character.isSpace(s.charAt(i))) space++;
			else sp++;
		}
		
		if(s.length()<8)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password is too Short..");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		else if(u<1)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password Should Contain atleast One UpperCase Character..");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		else if(l<2)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password Should Contain atleast Two LowerCase Character..");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		else if(d<1)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password Should Contain atleast one Digit..");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		else if(sp<1)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password Should Contain atleast One Special Character....");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		else if(space>0)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password Should not Contain Spaces....");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		else if(u>l)
		{
			try
			{
				WrongPasswordException wpe1=new WrongPasswordException("Password Should not Contain More Capital Characters Than Small Character....");
				throw wpe1;
			}
			catch(WrongPasswordException w)
			{
				w.printStackTrace();
				return false;
			}
		}
		
		return true;
	}
}

class WrongPasswordException extends Exception
{
	public WrongPasswordException(String s)
	{
		super(s);
	}
}

public class Tester_Validation_UserException
{
	public static void main(String[] args) throws Exception
	{
		Validator v=new Validator();
		boolean	t=v.validatePassword("ABCd1f@h");
		if(t==true)System.out.println("Password Set Successfully...");
	}
}
