package apr_11;
import java.util.ArrayList;
import java.util.Scanner;
class Driver_CountStringGreaterThen5
{
	void operation()
	{
		Scanner sc=new Scanner(System.in);
		ArrayList al=new ArrayList();
		String s="";
		for(int i=0;i<10;i++)
		{
			System.out.println("Enter String : ");
			s=sc.nextLine();
			if(s.length()>5)al.add(s);
		}
		System.out.println("Strings having a length greater than 5: "+al.size());
	}
}
public class CountStringGreaterThen5
{
	public static void main(String[] args)
	{
		new Driver_CountStringGreaterThen5().operation();
	}
}
