package apr_11;
import java.util.ArrayList;

class Driver_Divisble_By_5
{
	void operation()
	{
		ArrayList <Integer>al=new ArrayList<Integer>();
		for(int i=1;i<101;i++)
			if(i%5==0)al.add(i);
		
		System.out.println(al);
	}
}
public class Divisble_By_5
{
	public static void main(String[] args)
	{
		new Driver_Divisble_By_5().operation();
	}
}
