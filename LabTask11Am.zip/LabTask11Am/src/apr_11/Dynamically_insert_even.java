package apr_11;
import java.util.ArrayList;
import java.util.Scanner;
class Driver_Dynamically_insert_even
{
	void oper()
	{
		ArrayList <Integer>al=new ArrayList<Integer>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Starting Range: ");
		int f=sc.nextInt();
		System.out.println("Enter the Starting Range: ");
		int l=sc.nextInt();
		for(int i=f;i<=l;i++)
			if(i%2==0)al.add(i);
		System.out.println(al);
	}
}
public class Dynamically_insert_even
{
	public static void main(String[] args)
	{
		new Driver_Dynamically_insert_even().oper();
	}
}
