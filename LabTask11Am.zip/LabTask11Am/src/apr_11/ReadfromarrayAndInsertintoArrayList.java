package apr_11;
import java.util.ArrayList;
class Driver
{
	void m1()
	{
		ArrayList<Object>al=new ArrayList<Object>();
		int a[]= {10,20,30,40,50};
		for(int i=0;i<a.length;i++)
			al.add(a[i]);
		System.out.println(al);
	}
}

public class ReadfromarrayAndInsertintoArrayList
{
	public static void main(String[] args)
	{
		new Driver().m1(); 
	}
}
