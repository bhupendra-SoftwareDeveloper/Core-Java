/*
 * Create a method that can accept an array of String objects and sort in alphabetical
 * order. The elements in the left half should be completely in uppercase and the
 * elements in the right half should be completely in lower case. Return the resulting
 * array. 
Note: If there are odd number of String objects, then (n/2)+1 elements should be in UPPPERCASE
Method Name 	getArrayList 
Method Description 	Converts the String array to ArrayList and sorts it 
Argument 	String []elements 
Return Type 	String [] modifiedArray 
Logic 	Load the elements in to an ArrayList ,sort it, convert the left half element 
to uppercase and right half elements to lower case . 
Hint : 
1. Use Collection 
2. Use String API 
 */
package apr_12;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

class Driver_HalfUpper_HalfLower
{
	String [] getArrayList(String s[])
	{
		int l;
		ArrayList<String> al=new ArrayList<String>();
		for(int i=0;i<s.length;i++)
			al.add(s[i]);
		
		Collections.sort(al);
		
		for(int i=0;i<s.length;i++)
		{
			l=al.get(i).length();
			 if(l%2==0) al.set(i, al.get(i).substring(0,l/2).toUpperCase()+al.get(i).substring(l/2).toLowerCase());
			 else	al.set(i, al.get(i).substring(0,(l/2)+1).toUpperCase()+(al.get(i).substring((l/2)+1).toLowerCase()));
		}
		
		for(int i=0;i<s.length;i++)
			s[i]=al.get(i);
		return s;
	}
}

public class HalfUpper_HalfLower
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("How many String you want to enter: ");
		int n=sc.nextInt();
		sc.nextLine();
		String s[]=new String[n];
		System.out.println("Enter the "+n+" Strings: ");
		for(int i=0;i<n;i++)
			s[i]=sc.nextLine();
		sc.close();
		Driver_HalfUpper_HalfLower dhul=new Driver_HalfUpper_HalfLower();
		String s2[]=dhul.getArrayList(s);
		for(int i=0;i<s2.length;i++)System.out.println(s2[i]);
	}
}
