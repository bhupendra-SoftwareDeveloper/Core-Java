/*
 * Program:3:
Create a method which accepts two Arraylist containing characters. Merge both arrays lists, 
sort the elements in the resulting list and return the resulting array.
Method Name 	mergeData 
Method Description 	Merge two arraylist , sort it and return the result as an integer array. 
Argument 	List, List 
Return Type 	char[] 
Logic 	Merge both arrays lists, sort the elements in the resulting list and return it as a char array. 
 */
package apr_12;
import java.util.ArrayList;
import java.util.Collections;
class Driver_Merge_TwoArrayList
{
	char[] mergeData(ArrayList<Character> al1,ArrayList<Character> al2)
	{
		char ch[]=new char[al1.size()+al2.size()];
		al1.addAll(al2);
		Collections.sort(al1);

		for(int i=0;i<al1.size();i++)
			ch[i]=al1.get(i);
		return ch;
	}
}

public class Merge_TwoArrayList
{
	public static void main(String[] args)
	{	
		Driver_Merge_TwoArrayList dmta=new Driver_Merge_TwoArrayList();
		ArrayList<Character> alc1=new ArrayList<Character>(); 
		ArrayList<Character> alc2=new ArrayList<Character>();
		alc1.add('A');
		alc1.add('k');
		alc1.add('s');
		alc1.add('h');
		alc1.add('a');
		alc1.add('y');
		alc2.add('K');
		alc2.add('u');
		alc2.add('m');
		alc2.add('a');
		alc2.add('r');
		for(char x:dmta.mergeData(alc1,alc2))System.out.println(x);
	}
}
