package apr_12;

/*
 * Create a method which accepts an integer array, reverse the numbers in 
 * the array and returns the resulting array in sorted order
Method Name 	getSorted 
Method Description 	Return the resulting array after reversing the numbers 
and sorting it 
Argument 	int [] 
Return Type 	int[] 
Logic 	Accept an integer array, reverse the numbers in the array, sort it and 
return the resulting array. Hint :
1. Convert the numbers to String to reverse it 
2. Use Collection APIs to sort it 
Ex: {12,23,96,45} 
Step 1: Reverse numbers {21,32,69,54} 
Step2: Sort it {21,32,54,69} 
Hint: Use String to reverse number 
To sort it, Convert array to ArrayList and use Collections.sort 
 */
import java.util.ArrayList;
import java.util.Collections;
class Driver_Sorted_Reverse
{
	int[]  getSorted(int arr[])
	{
		String s,s2;
		ArrayList<String>al=new ArrayList<String>();
		
		int[] arr1=new int[arr.length];
		for(int i=0;i<arr.length;i++)
		{
			s=""+arr[i];
			s2="";
			for(int j=s.length()-1;j>=0;j--)
				s2=s2+""+s.charAt(j);
			al.add(s2);
		}
		Collections.sort(al);
		
		for(int i=0;i<al.size();i++)
				arr1[i] = Integer.parseInt(al.get(i));
		
		return arr1;
	}
}

public class Sorted_Reverse
{
	public static void main(String[] args)
	{
		Driver_Sorted_Reverse dsr=new Driver_Sorted_Reverse();
		int arr[]=new int[]{10,23,96,45};
		for(int x:dsr.getSorted(arr))System.out.println(x);
	}
}