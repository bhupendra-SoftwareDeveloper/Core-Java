package apr_13;
import java.util.ArrayList;
import java.util.TreeSet;
/*
 * 
Program4:Create a method which accepts an integer array and removes all the 
duplicates in the array. Return the resulting array in descending order
Method Name 	modifyArray 
Method Description 	Remove duplicates 
Argument 	int [] 
Return Type 	int [] 
Logic 	Remove the duplicate elements in the array and sort it in descending order 
Hint: 
1. Use Collection API (TreeSet) to remove duplicates and sort the result in ascending 
order 
2. Create a new array, iterate through elements in TreeSet and add it in the reverse 
order 
 */

class Driver_DescendingOrder
{
	int [] modifyArray(int []a)
	{
		ArrayList <Integer>al=new ArrayList <Integer>();
		for(int i=0;i<a.length;i++)
			al.add(a[i]);
		TreeSet<Integer> ts=new TreeSet<Integer>();
		ts.addAll(al);
		al.clear();
		al.addAll(ts);
		int arr[]=new int[al.size()];
		for(int i=0,k=1;i<al.size();i++,k++)
			arr[i]=al.get(al.size()-k);
		return arr;
	}
}
public class DescendingOrder
{
	public static void main(String[] args)
	{
		Driver_DescendingOrder ddo=new Driver_DescendingOrder();
		int a[]=new int[]{15,45,10,9,70,15};
		for(int x:ddo.modifyArray(a))System.out.println(x);
	}
}
