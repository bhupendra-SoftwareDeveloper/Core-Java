/*
 * Program-6
Three classes are given to you, 
COJ_58_CabCustomer
COJ_58_CabCustomerService
COJ_58_CabCustomerServiceTester


Define the following in the class COJ_58_CabCustomer 

  private : custId int, customerName String, pickupLocation String,dropLocation String,
   distance int,phone String
 
    Generate Getter/Setter for the all fields.

    Implement the default constructor.

    Implement/Generate the parameterized constructor in the order as defined above, i.e.,
      custId,Name,Pickup,Drop,Distance,Phone

Define the following in the  class COJ_58_CabCustomerService and write logics in the following 
methods:
	  
	 
       private : Generic ArrayList to represent list of CabCustomers.
	   public : addCabCustomer() : Add the customer object parameter to the ArrayList
			    isFirstCustomer(): Check whether the customer object parameter is already 
			    existing in arrayList. 
			    
				
		Note : If phone number of a customer matches with any of the phone numbers of the array 
		list, then consider it as a existing customer, otherwize consider
		the customer as new customer. 
				 
	   			calculateBill() should calculate and return the customer bill based on following 
	   			rules
				1) if the customer is new return 0;
				2) if the customer's travel distance is below or equal    
		   			to 4 kms then return 80 (Rs).
				3) if the customer travel distance is above 4 kms calculate bill 80 + 6 per each 
				km.
		
				Ex: Any distance for new customer return 0;
						distance 4 return 80
						distance 6 return 80 + 6 * 6;
		
	   			printBill() which should return the bill of the customer object parameter in 
	   			the following format:
	   
				output : JOHN Please pay your bill of Rs.0.0
						 SMITH Please pay your bill of Rs.180.0

	Note : 
	   Assume one customer books only one cab at a time.
	   No charge for customer booking the cab for the first time.
	   Customer's phone number is key to test a new customer or old customer.
	   Distance should be treated as kilometers 				 
				 
A class COJ_58_CabCustomerServiceTester is given with main() where you can create various 
objects and test them.
 */
package apr_13;
import java.util.ArrayList;
class COJ_58_CabCustomer
{
	  private int custId,distance;
	  private String customerName,pickupLocation,dropLocation,phone;
	  
	public COJ_58_CabCustomer()
	{
		super();
	}
	public COJ_58_CabCustomer(int custId,  String customerName, String pickupLocation, String dropLocation,int distance,
			String phone)
	{
		super();
		this.custId = custId;
		this.distance = distance;
		this.customerName = customerName;
		this.pickupLocation = pickupLocation;
		this.dropLocation = dropLocation;
		this.phone = phone;
	}
	protected String getPhone() {
		return phone;
	}
	protected int getDistance() {
		return distance;
	}
	protected String getCustomerName() {
		return customerName;
	}
	 
}
class COJ_58_CabCustomerService
{
	int count;
	boolean t;
	public void addCabCustomer(COJ_58_CabCustomer c,ArrayList al)
	{
		ArrayList<COJ_58_CabCustomer>al2=new ArrayList<COJ_58_CabCustomer>();
				
		t=isFirstCustomer(c,c.getPhone(),al);
		printBill(calculateBill(c.getDistance(),t),c.getCustomerName());
		
	}
	
	boolean isFirstCustomer(COJ_58_CabCustomer c,String phone,ArrayList al)
	{
		for(int i=0;i<al.indexOf(c);i++)
			if(c.getPhone().equals(((COJ_58_CabCustomer) al.get(i)).getPhone())) count++;
		if(count==0)return true;
		else return false;
	}
	int calculateBill(int dis,boolean t)
	{	
		if(t==true)
			return 0;
		else if(dis<=4)
			return 80;
		else if(dis>4)
			return 80+(dis*dis);
		else return 0;
	}
	void printBill(int amt,String name)
	{
		System.out.println(name.toUpperCase()+" Please pay your bill of Rs."+amt);
	}
}

public class Tester_COJ_58_CabCustomerService
{
	public static void main(String[] args)
	{
		COJ_58_CabCustomer cojccust1=new COJ_58_CabCustomer(110,"Rahul","Pandesara","Udhna",6,"8754965410");
		COJ_58_CabCustomer cojccust2=new COJ_58_CabCustomer(120,"Aman","Limbayat","Udhna",4,"8754968845");
		COJ_58_CabCustomer cojccust3=new COJ_58_CabCustomer(30,"Sanjay","Limbayat","Althan",16,"8754968845");
		COJ_58_CabCustomer cojccust4=new COJ_58_CabCustomer(180,"Piyush","Nanpura","Dumas",110,"9658765410");
		ArrayList<COJ_58_CabCustomer>al=new ArrayList<COJ_58_CabCustomer>();
		al.add(cojccust1);
		al.add(cojccust2);
		al.add(cojccust3);
		al.add(cojccust4);
		COJ_58_CabCustomerService cojcser1=new COJ_58_CabCustomerService();
		cojcser1.addCabCustomer(cojccust2,al);
	}
}
