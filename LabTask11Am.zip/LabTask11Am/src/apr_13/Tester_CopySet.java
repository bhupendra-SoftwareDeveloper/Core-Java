/*
 * Program-5
Write a java program to copy a set to another.

A SetCopy class is given to you. Add the following implementations in the class:

1. Implement the method copySets(source, destination):

2. The source and destination are two Sets of Integers. You have to copy all the elements in the source 
to the destination. Return 0 on successful copy

3. If either the destination Set or source Set is null, return 1.

A class called Tester with the main method is given to you. Use this class to test your solution.

 */
package apr_13;
import java.io.FileInputStream;
import java.io.FileOutputStream;
class CopySet
{
	int copySets(String source,String desti) throws Exception
	{
		FileInputStream fr=new FileInputStream(source);
		FileOutputStream fw=new FileOutputStream(desti);
		int i,c=0;
		while((i=fr.read())!=-1)
		{
			fw.write(i);
			c++;
		}
		fr.close();fw.close();
		if(c==0) return -1;
		else return 0;
	}
}
public class Tester_CopySet
{
	public static void main(String[] args) throws Exception
	{
		CopySet cs=new CopySet();
		System.out.println(cs.copySets("D:\\Let's Do It\\IOStreams\\Source-LabTask-13-Apr-QueNo.2.txt","D:\\Let's Do It\\IOStreams\\Destination-LabTask-13-Apr-QueNo.2.txt")
);
	}

}
