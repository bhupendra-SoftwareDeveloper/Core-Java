/*
 * Create a method which accepts an array of numbers and returns the numbers and their squares 
 * in an HashMap
Method Name :	getSquares 
Argument :	int[] 
Return Type 	Map 
 */
package apr_19;

import java.util.HashMap;

class Driver_Collection_Squares_of_Numbers
{
	HashMap<Integer,Integer> getSquares(int a[])
	{
		HashMap <Integer,Integer>hm=new HashMap<Integer,Integer>(); 
		for(int i=0;i<a.length;i++)
			hm.put(a[i],a[i]*a[i]);
		return hm;
	}
}

public class Collection_Squares_of_Numbers
{
	public static void main(String[] args)
	{
		int a[]= {2,4,3,5};
		System.out.println(new Driver_Collection_Squares_of_Numbers().getSquares(a));
	}

}
