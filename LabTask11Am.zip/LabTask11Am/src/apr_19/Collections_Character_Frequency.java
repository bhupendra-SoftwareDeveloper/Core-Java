/*
 * 
Program:4
Create a method that accepts a character array and count the number of times each 
character is present in the array. Add how many times each character is present to a hash 
map with the character as key and the repetitions count as value
Method Name :	countCharacter 
Argument :	char[] 
Return Type 	map 
Example: 
{�A�,�P�,�P�,�L�,�E�} 
Output: Will be hashmap with the following contents{�A�:1,�P�:2,�L�:1,�E�:1} 
 */
package apr_19;
import java.util.HashMap;

class Driver_Collections_Character_Frequency
{
	HashMap<Character,Integer> countCharacter(char[] ch)
	{
		int k;
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		for(int i=0;i<ch.length;i++)
		{	k=0;
			for(int j=0;j<ch.length;j++)
				if(ch[i]==ch[j])k++;
			
			hm.put(ch[i],k);
		}
		return hm;
	}
}

public class Collections_Character_Frequency
{
	public static void main(String[] args)
	{
		char[] ch= {'A','P','P','L','E'};
		System.out.println(new Driver_Collections_Character_Frequency().countCharacter(ch));
	}
}
