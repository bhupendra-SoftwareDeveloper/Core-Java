/*
 * Create a method which accepts an integer array and removes all the duplicates in the array. 
 * Return the resulting array in descending order
Method Name :	modifyArray 
Argument :	int [] 
Return Type :	int []
 */
package apr_19;
import java.util.Iterator;
import java.util.TreeSet;
class Driver_Collections_DescendingOrder
{
	int [] modifyArray(int[] a)
	{
		TreeSet<Integer> ts=new TreeSet<Integer>();
		for(int i=0;i<a.length;i++)
			ts.add(a[i]);
		int b[]=new int[ts.size()];
		int k=ts.size();
		Iterator <Integer>i=ts.iterator();
		while(i.hasNext())
			b[--k]=(int) i.next();
		return b;
	}
}

public class Collections_DescendingOrder
{
	public static void main(String[] args)
	{
		int a[]= {10,20,15,7,8,10,10,9,50};
		for(int x:new Driver_Collections_DescendingOrder().modifyArray(a))System.out.println(x);
	}
}
