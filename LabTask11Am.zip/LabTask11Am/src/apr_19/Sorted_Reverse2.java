package apr_19;

import java.util.ArrayList;
import java.util.Collections;

class Driver_Sorted_Reverse2
{
	int[]  getSorted(int arr[])
	{
		String s,s2;
		ArrayList<String>al=new ArrayList<String>();
		
		int[] arr1=new int[arr.length];
		for(int i=0;i<arr.length;i++)
		{
			s=""+arr[i];
			s2="";
			for(int j=s.length()-1;j>=0;j--)
				s2=s2+""+s.charAt(j);
			al.add(s2);
		}
		Collections.sort(al);
		
		for(int i=0;i<al.size();i++)
				arr1[i] = Integer.parseInt(al.get(i));
		
		return arr1;
	}
}

public class Sorted_Reverse2
{
	public static void main(String[] args)
	{
		Driver_Sorted_Reverse2 dsr=new Driver_Sorted_Reverse2();
		int arr[]=new int[]{10,23,96,45};
		for(int x:dsr.getSorted(arr))System.out.println(x);
	}
}