package mar_03;

class Prog2
{ int sum,sum2;
	int calculateDifference(int n)
	{
		for(int i=1;i<=n;i++)
		{
			sum+=i*i;
			sum2+=i;
		}
		return sum-(sum2*sum2);
	}
}
public class Tester_Difference
{
	public static void main(String[] args)
	{
		Prog2 ob=new Prog2();
		System.out.println(ob.calculateDifference(3));;
	}
}
