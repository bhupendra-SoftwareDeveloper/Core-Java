package mar_03;

import java.util.Scanner;
class Employee
{
	int id;
	String name;
	double basicSalary,HRAPer,DAPer;
	
	
	public Employee(String name,int id,double basicSalary,double hRAPer, double dAPer)
	{
		this.id = id;
		this.name = name;
		this.basicSalary=basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
	}

	public double calculateGrossSalary()
	{
		return basicSalary+HRAPer+DAPer;
	}
}

class Manager
{
	int id;
	String name;
	double basicSalary,HRAPer,DAPer, projectAllowance;
	
	public Manager(String name,int id,double basicSalary,double hRAPer, double dAPer,double projectAllowance)
	{
		this.id = id;
		this.name = name;
		this.basicSalary=basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
		this.projectAllowance=projectAllowance;
	}

	public double calculateGrossSalary()
	{
		return basicSalary+HRAPer+DAPer+projectAllowance;
	}
}

class Trainer
{
	int id,batchCount;
	String name;
	double basicSalary,HRAPer,DAPer,perkPerBatch;
	public Trainer(String name,int id, double basicSalary,double hRAPer, double dAPer,int batchCount,double perkPerBatch)
	{
		this.id = id;
		this.batchCount = batchCount;
		this.name = name;
		this.basicSalary = basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
		this.perkPerBatch = perkPerBatch;
	}
	
	double calculateGrossSalary()
	{
		return (basicSalary +HRAPer +DAPer +(batchCount * perkPerBatch));
	}
}

class Sourcing
{
	String name;
	int id,enrollmentTarget,enrollmentReached;
	double basicSalary,HRAPer,DAPer,perkPerEnrollment;
	
	public Sourcing(String name, int id, int enrollmentTarget, int enrollmentReached, double basicSalary, double hRAPer,
			double dAPer, double perkPerEnrollment)
	{
		this.name = name;
		this.id = id;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.basicSalary = basicSalary;
		this.HRAPer = hRAPer;
		this.DAPer = dAPer;
		this.perkPerEnrollment = perkPerEnrollment;
	}

	double calculateGrossSalary()
	{
		return (basicSalary +HRAPer +DAPer +((enrollmentReached/enrollmentTarget)*100)*perkPerEnrollment);
	}
}

class FindTax
{
	public double calculateTax(Employee e)
	{
		if(e.calculateGrossSalary()>30000)
			return ((e.calculateGrossSalary())*20)/100;
		else
			return ((e.calculateGrossSalary())*5)/100;
	}
	
	public double calculateTax(Manager m)
	{
		if(m.calculateGrossSalary()>30000)
			return ((m.calculateGrossSalary())*20)/100;
		else
			return ((m.calculateGrossSalary())*5)/100;
	}
	
	public double calculateTax(Trainer t)
	{
		if(t.calculateGrossSalary()>30000)
			return ((t.calculateGrossSalary())*20)/100;
		else
			return ((t.calculateGrossSalary())*5)/100;
	}
}

public class Tester_Employee
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter Name"+"\n"+"Enter Id"+"\n"+"Enter Basic Salary"+"\n"+"Enter HRA"+"\n"+"Enter DA");
		
		Employee e=new Employee(sc.nextLine(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt());
		System.out.println("Gross Salary Of Employee:"+e.calculateGrossSalary());
		
//		System.out.println("Enter Name"+"\n"+"Enter Id"+"\n"+"Enter Basic Salary"+"\n"+"Enter HRA"+"\n"+"Enter DA"+"\n"+"Enter Project Allowance");
//		
//		Manager m=new Manager(sc.nextLine(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextInt());
//		System.out.println("Gross Salary Of Manager:"+m.calculateGrossSalary());
//	
//		System.out.println("Enter Name"+"\n"+"Enter Id"+"\n"+"Enter Basic Salary"+"\n"+"Enter HRA"+"\n"+"Enter DA"+"\n"+"Enter Batch"+"\n"+"Enter per Batch");
//		
//		Trainer t=new Trainer(sc.nextLine(),sc.nextInt(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextInt(),sc.nextDouble());
//		System.out.println("Gross Salary Of Trainer:"+t.calculateGrossSalary());
//	
//		System.out.println("Enter name"+"\n"+"Enter id"+"\n"+"Enter enrollmentTarget"+"\n"+"Enter enrollmentReached"+"\n"+"Enter basicSalary"+"\n"+"Enter hRA"+"\n"+"Enter DA"+"\n"+"Enter perkPerEnrollment");
//		Sourcing s=new Sourcing(sc.nextLine(),sc.nextInt(),sc.nextInt(),sc.nextInt(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
//		System.out.println("Gross Salary Of Sourcing:"+s.calculateGrossSalary());
	
		FindTax tax=new FindTax();
		System.out.println("Income Tax:"+tax.calculateTax(e));
//		System.out.println("Income Tax:"+tax.calculateTax(m));
//		System.out.println("Income Tax:"+tax.calculateTax(t));
	}
}
