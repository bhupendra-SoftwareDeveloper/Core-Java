package mar_03;

class A
{  int sum;
	int calculateSum(int n)
	{
		for(int i=1;i<=n;i++)
		{
			if(i%3==0||i%5==0)
				sum+=i;
		}
		return sum;
	}
}

public class Tester_Sum
{
	public static void main(String[] args)
	{
		A ob=new A();
		System.out.println(ob.calculateSum(5));;
	}
}
