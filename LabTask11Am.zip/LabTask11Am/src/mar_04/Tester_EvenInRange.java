package mar_04;
import java.util.Scanner;

class EvenInRange
{	String str="";
	String getEvenNumbers(int a,int b)
	{
		if(a<0||b<0)  return "-1";
		else if(a==0||b==0||a==b)  return "-2";
		else
		{
			if(a<b)
			{
				for(int i=a;i<=b;i++)
					if(i%2==0) str+=i+" ";
				return str;
			}
			else
			{
				for(int i=a;i>=b;i--)
					if(i%2==0) str+=i+" ";
				return str;
			}
		}
	}
}

public class Tester_EvenInRange
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		EvenInRange er=new EvenInRange();
		System.out.println("Enter first value:");
		int f=sc.nextInt();
		System.out.println("Enter Second value:");
		int s=sc.nextInt();
		System.out.printf(null);
		System.out.println(er.getEvenNumbers(f,s));
	}
}
