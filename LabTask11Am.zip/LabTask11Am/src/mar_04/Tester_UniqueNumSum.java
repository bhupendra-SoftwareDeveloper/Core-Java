package mar_04;
import java.util.Scanner;

class UniqueSum
{	static int sum=0;
	int sumOfArray(int[] arr)
	{
		for(int i=0,c=0;i<arr.length;i++,c=0)
		{
			if(arr[i]<0) return -2;
			for(int j=0;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
					c++;
			}
			if(c==1)sum+=arr[i];
		}
		return sum;
	}
}

public class Tester_UniqueNumSum
{	static Scanner sc=new Scanner(System.in);
	static int[] arr=new int[6];
	
	public static void main(String[] args)
	{
		System.out.println("Enter array size:");
		int n=sc.nextInt();
		System.out.println("Enter "+n+" Integer values");
		for(int i=0;i<arr.length;i++)
			arr[i]=sc.nextInt();
		
		UniqueSum us=new UniqueSum();
		System.out.println(us.sumOfArray(arr));;
	}
}
