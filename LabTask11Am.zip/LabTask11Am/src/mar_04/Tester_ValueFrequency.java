package mar_04;
import java.util.Scanner;

class ValueFrequency
{	int c=0;
	int getCount(int[] array,int search)
	{	int temp=0;
		for(int i=0;i<array.length;i++)
		{
			for(int j=i+1;j<array.length;j++)
			{
				if(array[i]>array[j])
				{
					temp=array[j];
					array[j]=array[i];
					array[i]=temp;
				}
					
			}
		}
		
		for(int i=0;i<array.length;i++)
			
			if(array[i]==search) c++;

		return c;
	}
}
public class Tester_ValueFrequency
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter the array size:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Ineger values:");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		System.out.println("Enter the search value:");
		int s=sc.nextInt();
		
		ValueFrequency vf=new ValueFrequency();
		System.out.println(s+" Found "+vf.getCount(a,s)+" Times");
	}
}
