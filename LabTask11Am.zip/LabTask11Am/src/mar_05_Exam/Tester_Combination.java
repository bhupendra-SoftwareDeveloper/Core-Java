package mar_05_Exam;
import java.util.Scanner;

class Combination
{
	void combinationSum(int[] a,int s)
	{
		 int count = 1;
	        int n = a.length;
	        for (int i = 0; i < n - 3; i++) 
	        {
	            for (int j = i + 1; j < n - 2; j++) 
	            {
	                for (int k = j + 1; k < n - 1; k++) 
	                {
	                    for (int l = k + 1; l < n; l++) 
	                    {
	                        if (a[i] + a[j] + a[k] + a[l] == s)
	                        {
	                            System.out.print("Combination " + count + ": " + a[i] + " " + a[j] + " " + a[k] + " " + a[l] + "\n");
	                            count++; 
	                            break;
	                        }
	                    }
	                }
	            }
	        }
	    }
	}

public class Tester_Combination
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("How many values you want to enter:");
		int n=sc.nextInt();
		System.out.println("Enter "+n+" Integer values:");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		System.out.println("Enter Sum value:");
		int s=sc.nextInt();
		Combination cmb=new Combination();
		cmb.combinationSum(a,s);
	}
}
