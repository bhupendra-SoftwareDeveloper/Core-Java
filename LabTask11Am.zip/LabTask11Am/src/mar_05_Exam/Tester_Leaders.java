package mar_05_Exam;
import java.util.Scanner;

class Leader_num
{	static int temp,t=-1,j;
	
	void find(int []a,int n)
	{
		int b[]=new int[n];
		while(t!=a.length-1)
		{
			for(int i=t+1;i<a.length;i++)
			{
				if(a[i]>temp)
				{
					temp=a[i];
					t=i;
				}
			}
			b[j]=temp;
			j++;temp=0;
		}
		for(int k=0;k<j;k++) System.out.print(b[k]+" ");
	}	
}

public class Tester_Leaders
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("How many values you want to enter:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Int Value:");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		Leader_num l=new Leader_num();
		l.find(a,n);
	}
}
