package mar_05_Exam;
import java.util.Scanner;

class Sum
{
	void sumofmat(int a[][],int b[][],int r,int d)
	{
		int c[][]=new int[r][d];

			for(int i=0;i<r;i++)
			{
				for(int j=0;j<d;j++)
				{
					c[i][j]=a[i][j]+b[i][j];
				}
			}
			
			for(int i=0;i<r;i++)
			{
				for(int j=0;j<d;j++)
				{
					System.out.print(c[i][j]+" ");
				}
				System.out.println();
			}
		}
	}

public class Tester_SumofMatrix
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter Row Size for 1st matrix:");
		int row1=sc.nextInt();
		System.out.println("Enter Column Size for 1st matrix:");
		int col1=sc.nextInt();
		
		System.out.println("Enter Row Size for 2nd matrix:");
		int row2=sc.nextInt();
		System.out.println("Enter Column Size for 2nd matrix:");
		int col2=sc.nextInt();
		
		int a[][]=new int[row1][col1];
		
		System.out.println("Enter "+row1*col1+" values for 1st matrix:");
		for(int i=0;i<row1;i++)
		{
			for(int j=0;j<col1;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		
		int b[][]=new int[row2][col2];
		
		System.out.println("Enter "+row2*col2+" values for 2nd matrix:");
		for(int i=0;i<row2;i++)
		{
			for(int j=0;j<col2;j++)
			{
				b[i][j]=sc.nextInt();
			}
		}
		
		Sum s=new Sum();
		s.sumofmat(a,b,row1,col1);
	}
}
