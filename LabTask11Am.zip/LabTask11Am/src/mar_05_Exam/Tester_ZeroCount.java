package mar_05_Exam;
import java.util.Scanner;

class Zero
{
	void countZero(int[] a,int n)
	{
		int c=0;
		for(int i=0;i<n;i++)
		{
			if(a[i]==0) c++;
			else System.out.print(a[i]+" ");
		}
		
		if(c>0)
		{
			for(int k=0;k<c;k++)
				System.out.print("0 ");
		}
	}
}
public class Tester_ZeroCount
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter how many Integer values you want to enter:");
		int n=sc.nextInt();
		int a[]=new int[n];
		
		System.out.println("Enter "+n+" Integer values");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		
		Zero z=new Zero();
		z.countZero(a,n);
	}
			
}
