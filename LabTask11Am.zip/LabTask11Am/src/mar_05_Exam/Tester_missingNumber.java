package mar_05_Exam;
import java.util.Scanner;

class Missing
{
	void missnum(int[] a,int v)
	{
		for(int i=0;i<v;i++)
		{
			if(((a[i+1]-a[i])!=1))
				System.out.println((a[i]+1));
		}
	}
}

public class Tester_missingNumber
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter how many values you want to enter:");
		int val=sc.nextInt();
		int a[]=new int[val];
		System.out.println("Enter "+val+" Integer values:");
		for(int i=0;i<val;i++)
		{
			a[i]=sc.nextInt();
		}
		Missing m=new Missing();
		m.missnum(a,val);
	}
}
