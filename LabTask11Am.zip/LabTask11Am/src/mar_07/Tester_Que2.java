package mar_07;

public class Tester_Que2
{
	public static void main(String[] args)
	{
		Tester_Que2 q2=new Tester_Que2();
		char a[][]=new char [1][5];
		System.out.println(a.getClass());
		System.out.println(q2.getClass());
	}
}
//if we use getClass() it will return class name only
//if we use reference it will call internally toString() and it returns class name with hexacode.