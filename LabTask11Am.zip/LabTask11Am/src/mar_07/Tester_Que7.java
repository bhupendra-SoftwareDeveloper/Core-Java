package mar_07;

public class Tester_Que7
{

	    public static void main(String args[])
	    {
	       /* int arr[][] = new int[3][];
	        arr[0] = new int[1];
	        arr[1] = new int[2];
	        arr[2] = new int[3];               
	 int sum = 0;
	 for (int i = 0; i < 3; ++i) 
	     for (int j = 0; j < i + 1; ++j) arr[i][j] = j + 1;
	 
	 for (int i = 0; i < 3; ++i) 
	     for (int j = 0; j < i + 1; ++j)
	                sum += arr[i][j];
	 System.out.print(sum);*/ 	
	    	int x[][]= new int[3][3];
//	    	 int [ ] y=new int[5];
//	    	 float d[ ]= {1,2,3};
//	    	 int a[ ] = {1, 2,3}; int b[ ]; b=a;

	    	for(int i=0;i<3;i++)
	    	{for(int j=0;j<3;j++)System.out.print(x[i][j]);
	    	System.out.println();}
	    } 
	}
/*arr[0][0]=1
 * arr[1][0]=1  
 * 		arr[1][1]=2
 * arr[2][0]=1
 * 	 	arr[2][1]=2
 * 		arr[2][2]=3
 * 
 * sum=10
 */