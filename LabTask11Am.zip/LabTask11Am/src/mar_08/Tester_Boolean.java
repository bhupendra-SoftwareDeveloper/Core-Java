package mar_08;
import java.util.Scanner;

class Boolean
{
	public boolean countBoolean(boolean a,boolean b,boolean c)
	{ 
		int count=0;
		if(a==true)
		{
			count++;
			if(b==true)
				count++;
				if(c==true)
					count++;
		}
		else
		{
			if(b==true)
				count++;
				if(c==true)
					count++;
		}
		if(count>1)
			return true;
		else return false;
	}
}

public class Tester_Boolean
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 1st Boolean value:");
		boolean f=sc.nextBoolean();
		System.out.println("Enter 2nd Boolean value:");
		boolean s=sc.nextBoolean();
		System.out.println("Enter 3rd Boolean value:");
		boolean t=sc.nextBoolean();
		Boolean boo=new Boolean();
		System.out.println(boo.countBoolean(f, s, t));
	}
}
