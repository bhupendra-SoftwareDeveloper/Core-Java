package mar_08;
import java.util.Scanner;

class Prog4
{	int sum,sum2;
	int calculateDifference(int n)
	{
		for(int i=1;i<=n;i++)
		{
			sum+=i*i;
			sum2+=i;
		}
		return sum-(sum2*sum2);
	}
}
public class Tester_Prog4
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter a value:");
		int n=sc.nextInt();
		Prog4 p=new Prog4();
		System.out.println(p.calculateDifference(n));
	}
}
