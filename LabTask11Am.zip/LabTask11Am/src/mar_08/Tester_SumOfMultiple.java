package mar_08;
import java.util.Scanner;

class SumOfMultiple
{	static int sum,r1,r2,r3;
	
	public int sumOfMultiples(int a,int b,int c)
	{
		if(a<=0||b<=0||c<=0)
			return sum=-1;
		
		else if(a%2==1||b%2==1||c%2==1)
		{
			if(a%2==1)
				sum=a*a*a;
			else if(b%2==1)
				sum=b*b*b;
			else if(c%2==1)
				sum=c*c*c;
			return sum;
		}
		else
		{
			if(a%10==0)
				System.out.println(a+" Is Multiple of 10");
			r1=a%10;
			if(r1!=0)
			{
				a=a-r1;
				a=a+10;
			}
			else a+=r1;
		
			if(b%10==0)
				System.out.println(b+" Is Multiple of 10");
			r2=b%10;
			if(r2!=0)
			{
				b=b-r2;
				b=b+10;
			}
			else b+=r2;
		
			if(c%10==0)
				System.out.println(c+" Is Multiple of 10");
			r3=c%10;
			if(r3!=0)
			{
				c=c-r3;
				c=c+10;
			}
			else c+=r3;
			
			return sum=a+b+c;
		}

	}
}
public class Tester_SumOfMultiple
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 1st value:");
		int f=sc.nextInt();
		System.out.println("Enter 2nd value:");
		int s=sc.nextInt();
		System.out.println("Enter 3rd value:");
		int t=sc.nextInt();
		SumOfMultiple som=new SumOfMultiple();
		System.out.println(som.sumOfMultiples(f, s, t));
	}
}
