package mar_08;
import java.util.Scanner;

class SumOfNatural
{
	int sum;
	int calculateSum(int n)
	{
		for(int i=1;i<=n;i++)
		{
			if(i%3==0||i%5==0)
				sum+=i;
		}
		return sum;
	}
}
public class Tester_SumOfNatural
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter a value:");
		int n=sc.nextInt();
		System.out.println(new SumOfNatural().calculateSum(n));
	}
}
