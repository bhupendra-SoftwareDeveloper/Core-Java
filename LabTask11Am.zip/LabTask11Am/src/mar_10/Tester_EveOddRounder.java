package mar_10;
import java.util.Scanner;

class EvenOdd
{
	public int oddRounder(int n)
	{	
		if(n<0) return -1;
		else if(n==0) return -2;
		else if(n%2!=0)			
			return n=(n-n%10)+10;
		else return n;
	}
}
public class Tester_EveOddRounder
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter the number:");
		int n=sc.nextInt();
		EvenOdd eo=new EvenOdd();
		System.out.println(eo.oddRounder(n));
	}
}
