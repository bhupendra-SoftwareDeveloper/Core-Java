package mar_10;
import java.util.Scanner;

class EveOddInvalid
{
	public String isEvenOrOdd(int n)
	{
		if(n<0||n==0) return "INVALID INPUT";
		else if(n%2==0) return "EVEN";
		else return "ODD";
	}
}
public class Tester_EveOdd_Invalid
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter the number:");
		int n=sc.nextInt();
		EveOddInvalid eoi=new EveOddInvalid();
		System.out.println(eoi.isEvenOrOdd(n));
	}
}
