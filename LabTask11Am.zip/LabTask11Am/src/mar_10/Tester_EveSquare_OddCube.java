package mar_10;
import java.util.Scanner;

class EveSquare_OddCube
{
	public int calculate(int n)
	{
		if(n<0||n==0) return -1;
		else if(n%2==0) return n*n;
		else return n*n*n;
	}
}

public class Tester_EveSquare_OddCube
{	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args)
	{
		System.out.println("Enter the number:");
		int n=sc.nextInt();
		EveSquare_OddCube esoc=new EveSquare_OddCube();
		System.out.println(esoc.calculate(n));
	}
}