package mar_10;
import java.util.Scanner;

class Greatest
{
	int getGreatest(int a,int b)
	{
		if(a<0||b<0) return -1;
		else if(a==0||b==0) return -2;
		else if(a>b) return a;
		else return b;
	}
}
public class Tester_GreatestNum
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter 1st number:");
		int f=sc.nextInt();
		System.out.println("Enter 2nd number:");
		int s=sc.nextInt();
		Greatest g=new Greatest();
		System.out.println(g.getGreatest(f, s));
	}
}
