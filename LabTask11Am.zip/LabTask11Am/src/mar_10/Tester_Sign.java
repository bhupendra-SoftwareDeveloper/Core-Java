package mar_10;
import java.util.Scanner;

class Sign
{
	public int findSign(int a)
	{
		if(a<0) return -1;
		else if(a==0) return 0;
		else return 1;
	}
}

public class Tester_Sign
{	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter the number:");
		int n=sc.nextInt();
		Sign s=new Sign();
		System.out.println(s.findSign(n));
	}
}
