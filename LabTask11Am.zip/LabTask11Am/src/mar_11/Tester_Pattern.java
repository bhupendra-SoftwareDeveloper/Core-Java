package mar_11;
import java.util.Scanner;

class BoxPattern
{	String result="";
	public String createBoxPattern(int row,int col)
	{
		if(row<0||col<0) return "-1";
		else if(row==0||col==0) return "-2";
		else
		{
			for(int i=1;i<=row;i++)
			{
				for(int j=1;j<=col;j++)
				{
					if(i==1||i==row) result+="*";
					else if((i!=1||i!=row)&&(j==1||j==col)) result+="*";
					else result+=" ";
				}
				result+="\n";
			}
		}
		return result;
	}
}
public class Tester_Pattern
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the Row size:");
		int r=sc.nextInt();
		System.out.println("Enter the Column size:");
		int c=sc.nextInt();
		
		BoxPattern b=new BoxPattern();
		System.out.println(b.createBoxPattern(r, c));
	}
}
