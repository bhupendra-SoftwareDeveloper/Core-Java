package mar_11;
import java.util.Scanner;

class Alarm
{ 
	public String ringAlarm(int dayOfweek,boolean vacation)
	{
		
		if((dayOfweek<0&&dayOfweek>6)||(vacation!=true||vacation!=false)) return "INVALID INPUTS";
		else if((dayOfweek>0&&dayOfweek<6&&vacation==true)||((dayOfweek==0||dayOfweek==6)&&vacation==false)) return "10:00";
		else if(dayOfweek>0&&dayOfweek<6&&vacation==false) return "07:00";
		else return "OFF";
	}
}

public class Tester_Prog07
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Sun=0"+"\n"+"Mon=1"+"\n"+"Tue=2"+"\n"+"Wed=3"+"\n"+"Thur=4"+"\n"+"Fri=5"+"\n"+"Sat=6");
		System.out.println("Enter day of week:");
		int d=sc.nextInt();
		System.out.println("Is it Vacation?:");
		boolean v=sc.nextBoolean();
		Alarm a=new Alarm();
		System.out.println(a.ringAlarm(d,v));
	}
}
