package mar_11;
import java.util.Scanner;

class NaturalNum
{	String result="";
	public String getNaturalNumbers(int a,int b)
	{
		if(a<0||b<0) return "-1";
		else if(a==0||b==0) return "-2";
		else if(a<b&&a!=b-1)
		{
			a++;
			result+=a+" ";	
			getNaturalNumbers(a, b);
		}
		return result;
	}
}

public class Tester_Prog08
{	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 1st number:");
		int f=sc.nextInt();
		System.out.println("Enter 2nd number:");
		int s=sc.nextInt();
		NaturalNum n=new NaturalNum();
		System.out.println(n.getNaturalNumbers(f,s));
	}
}
