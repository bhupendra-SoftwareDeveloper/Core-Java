package mar_11;

import java.util.Scanner;

class Natural
{	String result="";
	public String getNumbersInRange(int start_val,int end_val)
	{	
		if(start_val<end_val) return "-3";
		else if((start_val-end_val)==1) return "-4";
		else if(start_val>end_val)
		  for(int i=start_val-1;i>end_val;i--) result+=i+" ";
		return result;
	}
}
public class Tester_Prog09
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter 1st number:");
		int f=sc.nextInt();
		System.out.println("Enter 2nd number:");
		int s=sc.nextInt();
		Natural n=new Natural();
		System.out.println(n.getNumbersInRange(f, s));
	}
}
