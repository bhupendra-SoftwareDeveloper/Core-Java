package mar_12_Exam;
import java.util.Scanner;

class NaturalNum
{	String result="";
	public String getNumbersInRange(int a,int b,int c)
	{
		if(a<0||b<0) return "-1";
		else if(a==b) return "-2";
		else if(a>b) return "-3";
		else if(a<b&&a!=b-1)
		{
			a+=c;
			result+=a+" ";	
			getNumbersInRange(a, b,c);
		}
		return result;
	}
}

public class Tester_Prog01
{	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter Starting Number:");
		int f=sc.nextInt();
		System.out.println("Enter Ending Number:");
		int s=sc.nextInt();
		System.out.println("How much you want to increment:");
		int t=sc.nextInt();
		NaturalNum n=new NaturalNum();
		System.out.println(n.getNumbersInRange(f,s,t));
	}
}
