package mar_12_Exam;
import java.util.Scanner;

class Prog2
{	String result="";
	int i;
	public String getFourPerLine(int n)
	{
		if(n<0) return "-1";
		else if(n==0) return "-2";
		else if(n>99) return "-3";
		else
		{
			for(i=1;i<=n;i++)
			{
				result+=i+" ";
				if(i%4==0) result+="\n";
			}
		}
		return result;
	}
}
public class Tester_Prog02 
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		Prog2 p=new Prog2();
		System.out.println(p.getFourPerLine(n));
	}
}
