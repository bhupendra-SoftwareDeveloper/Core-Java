package mar_12_Exam;
import java.util.Scanner;

class Prog3
{	String result="";
	public String NumberPattern4(int row)
	{
		if(row<0) return "-1";
		else if(row==0) return "-2";
		else
		{
			for(int i=1;i<=row;i++)
			{
				for(int j=1;j<=i;j++)result+=i*j+" ";
				result+="\n";
			}
		}
		return result;
	}
}

public class Tester_Prog03
{
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("Enter Row size:");
		int n=sc.nextInt();
		Prog3 p=new Prog3();
		System.out.println(p.NumberPattern4(n));
	}
}
