package mar_12_Exam;
import java.util.Scanner;

class Prog4
{	static int sum,r1,r2,r3;
	
	public int sumOfMultiples(int a,int b,int c)
	{
		if(a<=0||b<=0||c<=0)
			return sum=-1;
		else
		{
			r1=a%10;
			if(r1!=0)
			{
				a=a-r1;
				a=a+10;
			}
			else a+=r1;
			r2=b%10;
			if(r2!=0)
			{
				b=b-r2;
				b=b+10;
			}
			else b+=r2;
			r3=c%10;
			if(r3!=0)
			{
				c=c-r3;
				c=c+10;
			}
			else c+=r3;
			return sum=a+b+c;
		}

	}
}
public class Tester_Prog04
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 1st value:");
		int f=sc.nextInt();
		System.out.println("Enter 2nd value:");
		int s=sc.nextInt();
		System.out.println("Enter 3rd value:");
		int t=sc.nextInt();
		Prog4 p=new Prog4();
		System.out.println(p.sumOfMultiples(f, s, t));
	}
}
