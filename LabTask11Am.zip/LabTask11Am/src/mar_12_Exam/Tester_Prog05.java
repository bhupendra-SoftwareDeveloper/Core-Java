package mar_12_Exam;
import java.util.Scanner;

class Prog5
{	static int sum,r1,r2,r3;
	
	public int sumOfRoundedValues(int a,int b,int c)
	{
		if(a<=0||b<=0||c<=0)
			return sum=-1;
		else
		{
			r1=a%10;
			if(r1<5) a=a-r1;
			else a=(a-r1)+10;
			
			r2=b%10;
			if(r2<5) b=b-r2;
			else b=(b-r2)+10;
			
			r3=c%10;
			if(r3<5) c=c-r3;
			else c=(c-r3)+10;
			
			return sum=a+b+c;
		}

	}
}
public class Tester_Prog05
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 1st value:");
		int f=sc.nextInt();
		System.out.println("Enter 2nd value:");
		int s=sc.nextInt();
		System.out.println("Enter 3rd value:");
		int t=sc.nextInt();
		Prog5 p=new Prog5();
		System.out.println(p.sumOfRoundedValues(f, s, t));
	}
}
