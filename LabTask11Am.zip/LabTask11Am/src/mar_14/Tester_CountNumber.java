package mar_14;
import java.util.Scanner;

class CountNumber
{	int c;
	public int getCount(int a[],int s)
	{
		for(int i=0;i<a.length;i++) if(a[i]==s) c++;
		return c;
	}
}

public class Tester_CountNumber
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("How many numbers you want to enter:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Integer values:");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		System.out.println("Enter number which occurance you want to see: ");
		int s=sc.nextInt();
		CountNumber c=new CountNumber();
		System.out.println(+s+" Occured : "+c.getCount(a,s)+" Times");
	}
}
