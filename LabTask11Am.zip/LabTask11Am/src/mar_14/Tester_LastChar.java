package mar_14;
import java.util.Scanner;

class LastChar
{	String result="";
	public String lastChar(String l[])
	{
		for(int i=0;i<l.length;i++)
			result+=l[i].charAt(l[i].length()-1);
		return result;
	}
}

public class Tester_LastChar
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("How many words you want to enter:");
		int n=sc.nextInt();
		sc.nextLine();
		String l[]=new String[n];
		for(int i=0;i<n;i++)
			l[i]=sc.nextLine();
		LastChar lc=new LastChar();
		System.out.println(lc.lastChar(l));
	}
}
