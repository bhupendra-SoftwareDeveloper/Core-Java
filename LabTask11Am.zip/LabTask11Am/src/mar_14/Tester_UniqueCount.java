package mar_14;
import java.util.Scanner;

class UniqueCount
{	
	
	int temp,u,c,i;
	public int uniqueCount(int a[])
	{
		for(i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		for(i=0;i<a.length;i++)
		{ 
			if(i==a.length-1&&a[i]!=a[a.length-2]) u++;
			
			for(int j=i+1,c=1;j<a.length;j++)
			{
				if(a[i]==a[j]) c++;
				else if(a[i]!=a[j]&&c==1)
				{
					u++;
					break;
				}
				else
				{
					i+=c-1;
					break;
				}
			}
		}
		return u;
	}
}

public class Tester_UniqueCount
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("How many numbers you want to enter:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Integer values:");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		UniqueCount uc=new UniqueCount();
		System.out.println("Total Unique Number is : "+uc.uniqueCount(a));
	}
}
