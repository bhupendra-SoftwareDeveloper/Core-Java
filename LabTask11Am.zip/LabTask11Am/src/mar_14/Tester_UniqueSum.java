package mar_14;
import java.util.Scanner;

class UniqueSum
{	
	int temp,sum,c,i;
	public int sumOfArray(int a[])
	{
		for(i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		for(i=0;i<a.length;i++)
		{ 
			if(i==a.length-1&&a[i]!=a[a.length-2]) sum+=a[i];
			
			for(int j=i+1,c=1;j<a.length;j++)
			{
				if(a[i]==a[j]) c++;
				else if(a[i]!=a[j]&&c==1)
				{
					sum+=a[i];
					break;
				}
				else
				{
					i+=c-1;
					break;
				}
			}
		}
		return sum;
	}
}

public class Tester_UniqueSum
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("How many numbers you want to enter:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Integer values:");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		UniqueSum us=new UniqueSum();
		System.out.println("Sum Of Unique Number is : "+us.sumOfArray(a));
	}
}
