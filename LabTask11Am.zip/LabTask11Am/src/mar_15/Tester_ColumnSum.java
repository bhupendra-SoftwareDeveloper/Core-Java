package mar_15;
import java.util.Scanner;

class ColumnSum
{ int sum;
	public int[] getColumnSum(int [][]a)
	{
		int b[]=new int[3];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				sum+=a[j][i];
			b[i]=sum;
			sum=0;
		}
		return b;
	}
}

public class Tester_ColumnSum
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 9 Numbers for 3x3 matrix:");
		int a[][]=new int[3][3];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				a[i][j]=sc.nextInt();
		}
		ColumnSum c=new ColumnSum();
		int b[]=c.getColumnSum(a);
		for(int x:b)System.out.print(x+" ");
	}
}
