package mar_15;
import java.util.Scanner;

class DiagonalSum
{ int sum;
	public int getDiagonalSum(int [][]a)
	{
		int b[]=new int[3];
		for(int i=0;i<3;i++)
			for(int j=0;j<3;j++)
				if(i==j)sum+=a[i][j];
		return sum;
	}
}

public class Tester_DiagonalSum
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 9 Numbers for 3x3 matrix:");
		int a[][]=new int[3][3];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				a[i][j]=sc.nextInt();
		}
		DiagonalSum d=new DiagonalSum();
		System.out.println(d.getDiagonalSum(a));
	
	}
}
