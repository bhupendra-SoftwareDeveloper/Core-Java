package mar_15;

import java.util.Scanner;

class GetMaxNumber
{	int temp;
	public int findMax(int a[])
	{
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a[a.length-1];
	}
}

public class Tester_GetMaxNumber
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("How many numbers you want to enter:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Integer values:");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		GetMaxNumber g=new GetMaxNumber();
		System.out.println("Max number is : "+g.findMax(a));
	}
}
