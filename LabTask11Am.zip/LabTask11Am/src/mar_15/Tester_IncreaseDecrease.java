package mar_15;
import java.util.Scanner;

class IncreaseDecrease
{ int temp,c;
	public int[] getIncreaseDecrease(int a[])
	{
		int b[]=new int[a.length];
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		if(a.length%2==0)
		{
			for(int i=0,j=0;i<a.length/2;i++,j++)
			{
					b[j]=a[i];
					c++;
					if(i<a.length/2)
					b[++j]=a[a.length-c];
			}
		}
		else
		{
			for(int i=0,j=0;i<=a.length/2;i++,j++)
			{
					b[j]=a[i];
					c++;
					if(i<a.length/2)
					b[++j]=a[a.length-c];
			}
		}
		return b;
	}

}

public class Tester_IncreaseDecrease
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("How many numbers you want to enter:");
		int n=sc.nextInt();
		int a[]=new int [n];
		System.out.println("Enter "+n+" Integer Numbers:");
		for(int i=0;i<a.length;i++)
			a[i]=sc.nextInt();
		IncreaseDecrease id=new IncreaseDecrease();
		int[] x=id.getIncreaseDecrease(a);
		for(int y:x) System.out.println(y);
	}
}
