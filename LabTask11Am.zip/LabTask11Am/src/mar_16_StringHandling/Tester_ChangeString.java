package mar_16_StringHandling;
import java.util.Scanner;

class ChangeString
{	static Scanner sc=new Scanner(System.in);
	
	public String changeString(String s,char c)
	{	
		String str="";
		switch(c)
		{
			case 'A':
			case 'a':
				str=s+s;
				break;
			
			case 'B':
			case 'b':
				System.out.println("Enter the character position which you want to replace with *");
				int p=sc.nextInt();
				for(int i=0;i<s.length();i++)
					if(i==p-1) str=s.replace(s.charAt(i),'*');
				break;
			
			case 'C':
			case 'c':
				int count=0;
				for(int i=0;i<s.length();i++)
				{
					for(int j=i+1;j<s.length();j++)
						if(s.charAt(i)==s.charAt(j)) count++;
					if(count==0) str+=s.charAt(i);
					count=0;
				}
				break;
				
			case 'D':
			case 'd':
				System.out.println("Enter the character which you want in UpperCase");
				String b=sc.nextLine();
				str=s.replace(b.charAt(0),Character.toUpperCase(b.charAt(0)));
				break;
				
			default : str="INVALID SELECTION";
		}
		return str;
	}
}
public class Tester_ChangeString
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		System.out.println("A: Add the String to itself \r\n"
				+ "B: Replace alternate positions with * \r\n"
				+ "C: Remove duplicate characters in the String \r\n"
				+ "D: Change alternate characters to upper case\n");
		System.out.println("Enter the choice: ");
		String op=sc.nextLine();
		ChangeString cs=new ChangeString();
		char c=op.charAt(0);
		System.out.println(cs.changeString(s, c));
	}
}
