package mar_16_StringHandling;
import java.util.Scanner;

class Check_IncreasingNum
{	int c;
	public boolean checkNumber(String number)
	{
		for(int i=0;i<number.length()-1;i++)
			if(number.charAt(i+1)<number.charAt(i))c++;
		if(c>0)
			return false;
		else return true;
		
	}
}

public class Tester_Check_IncreasingNum
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the Number: ");
		String s=sc.next();
		Check_IncreasingNum ci=new Check_IncreasingNum();
		System.out.println(ci.checkNumber(s));
	}
}
