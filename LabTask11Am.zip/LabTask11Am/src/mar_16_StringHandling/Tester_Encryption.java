package mar_16_StringHandling;
import java.util.Scanner;

class Encryption
{
	String str="";
	char ch;
	
	public String encryptString(String s)
	{	
		for(int i=0;i<s.length();i++)
		{
			ch=s.charAt(i);
			ch+=9;
			if(ch>'z')ch-=26;
			str+=ch;
		}
		return str;
	}
}

public class Tester_Encryption
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{	String s="";
		System.out.println("Enter the String: ");
		s=sc.nextLine();
		Encryption encry=new Encryption();
		System.out.println(encry.encryptString(s));
	}
}
