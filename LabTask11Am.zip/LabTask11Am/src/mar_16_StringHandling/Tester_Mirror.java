package mar_16_StringHandling;
import java.util.Scanner;

class Mirror
{
	public String getImage(String s)
	{
		String b="";
		for(int i=s.length()-1;i>=0;i--)
				b+=s.charAt(i);
		return s+"|"+b;
	}
}
public class Tester_Mirror
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the String: ");
		String s=sc.next();
		Mirror m=new Mirror();
		System.out.println(m.getImage(s));
	}
}
