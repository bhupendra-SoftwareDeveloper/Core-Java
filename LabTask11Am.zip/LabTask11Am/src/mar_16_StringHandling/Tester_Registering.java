package mar_16_StringHandling;
import java.util.Scanner;

class Registering
{	String b="_job";
	int c;
	public boolean validateUserName(String userName)
	{
		if(userName.length()<12)
			return false;
		else 
		{
			for(int i=1;i<4;i++)
				if(userName.charAt(userName.length()-i)!=b.charAt(b.length()-i)); c++;
			if(c>0) return true;
			else return false;
		}
	}
}

public class Tester_Registering
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter UserName: ");
		String s=sc.next();
		
		Registering r=new Registering();
		System.out.println(r.validateUserName(s));
	}
}
