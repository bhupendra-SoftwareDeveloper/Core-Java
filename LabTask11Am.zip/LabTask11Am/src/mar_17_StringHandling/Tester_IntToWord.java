package mar_17_StringHandling;
import java.util.Scanner;

class IntToWord
{	
	public String getNumber(int n)
	{
		String s= Integer.toString(n);
		StringBuffer buff=new StringBuffer("");
		
		for (int a=0;a<s.length();a++)
		{
			switch(s.charAt(a))
			{	
				case '1':
					buff.append(" ONE ");
					break;
				case '2':
					buff.append(" TWO ");
					break;
				case '3':
					buff.append(" THREE ");
					break;
				case '4':
					buff.append(" FOUR ");
					break;
				case '5':
					buff.append(" FIVE ");
					break;
				case '6':
					buff.append(" SIX ");
					break;
				case '7':
					buff.append(" SEVEN ");
					break;
				case '8':
					buff.append(" EIGTH ");
					break;
				case '9':
					buff.append(" NINE ");
					break;
				case '0':
					buff.append(" ZERO ");
					break;
			}
		}
		
		return buff.toString();
	}
}

public class Tester_IntToWord
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the Number: ");
		int n=sc.nextInt();
		
		IntToWord it=new IntToWord();
		System.out.println(it.getNumber(n));
	}
}
