package mar_17_StringHandling;
import java.util.Scanner;

class MovesLowerToBegin
{	char ch;
	int d;
	public String rearrangeCharacters(String str)
	{	
		StringBuffer str2=new StringBuffer("");
		for(int i=0;i<str.length();i++)
		{
			d=ch=str.charAt(i);
			if(d>96&&d<123)
				str2.append(ch);
				
		}
		for(int i=0;i<str.length();i++)
		{
			d=ch=str.charAt(i);
			if(d>64&&d<91)
				str2.append(ch);
		}
		return str2.toString();
	}
}

public class Tester_MovesLowerToBegin
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		
		MovesLowerToBegin m=new MovesLowerToBegin();
		System.out.println(m.rearrangeCharacters(s));
	}
}
