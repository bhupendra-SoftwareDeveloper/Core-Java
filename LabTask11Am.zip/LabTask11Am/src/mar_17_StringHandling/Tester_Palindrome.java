package mar_17_StringHandling;
import java.util.Scanner;

class Palindrome
{
	 boolean checkPalindrome(int n)
	 {
		String s=""+n;	//n concated into String s
		for(int i=0;i<s.length()/2;i++)
			if(s.charAt(i)!=s.charAt(s.length()-1-i))
				return false;
		 return true;
	 }
}

public class Tester_Palindrome
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the Number: ");
		int n=sc.nextInt();
		
		Palindrome p=new Palindrome();
		System.out.println(p.checkPalindrome(n));
	}
}
