package mar_17_StringHandling;
import java.util.Scanner;

class PositiveString
{	
	public boolean checkPositive(String str)
	{
		str=str.toLowerCase();
		for(int i=0;i<str.length()-1;i++)
				if((str.charAt(i)>str.charAt(i+1))) return false;
		return true;
	}
}

public class Tester_PositiveString
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		
		PositiveString ps=new PositiveString();
		System.out.println(ps.checkPositive(s));
	}
}
