package mar_18_StringHandling;
import java.util.Scanner;

class AverageWordLength
{
	int getAverageWordLength(String s)
	{	int k=0,i=0;
	
	if(s.isEmpty())return 0;
	else
	 {
		s=s.concat(" ");
		for(i=0;i<s.length();i++)
		    	if(s.charAt(i)==' ') k++;
		return (i-k)/k;
	 }
	}
}

public class Tester_AverageWordLength
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		AverageWordLength a=new AverageWordLength();
		System.out.println(a.getAverageWordLength(s));
	}
}
