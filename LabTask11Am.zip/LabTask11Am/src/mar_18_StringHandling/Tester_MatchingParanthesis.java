package mar_18_StringHandling;
import java.util.Scanner;

class MatchingParanthesis
{
	boolean isMatchingParanthesis(String s)
	{	int left=0,right=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='(') left++;
			if(s.charAt(i)==')') right++;
		}
		if(left==right||s.isEmpty())return true;
		else return false;
	}
}

public class Tester_MatchingParanthesis
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Expression: ");
		String s=sc.nextLine();
		MatchingParanthesis mp=new MatchingParanthesis();
		System.out.println(mp.isMatchingParanthesis(s));
	}
}
