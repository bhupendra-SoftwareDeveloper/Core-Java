package mar_18_StringHandling;
import java.util.Scanner;

class Moving_Char
{
	String rotate(String s,int p)
	{
		if(p<0||p>s.length()) return s;
		else
		{
			StringBuffer s2=new StringBuffer();
			s2.append(s.substring(s.length()-p));
			s2.append(s.substring(0,s.length()-p));
			return s2.toString();
		}
	}
}

public class Tester_Moving_Char
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		System.out.println("Enter the Moving Character postion number from right to left: ");
		int p=sc.nextInt();
		Moving_Char mc=new Moving_Char();
		System.out.println(mc.rotate(s,p));
	}
}
