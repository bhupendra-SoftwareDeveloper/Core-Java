package mar_18_StringHandling;
import java.util.Scanner;

class QuadraticSequence
{
	String getQuadricSequence(int n)
	{	int j=2,i=1,count=0;
		String s="";
		if(n<0||n==0) return "null";
		else
		{
			for(;;)
			{
				count++;
				s+=i+(count<n?",":"");
				i+=j;
				j++;
				if(count==n)break;
			}
			return s;
		}
	}
}

public class Tester_QuadraticSequence
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number: ");
		int n=sc.nextInt();
		QuadraticSequence q=new QuadraticSequence();
		System.out.println(q.getQuadricSequence(n));
	}
}
