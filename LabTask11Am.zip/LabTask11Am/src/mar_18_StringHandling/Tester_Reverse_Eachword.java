package mar_18_StringHandling;
import java.util.Scanner;
//Same question done by using Split method in LabTask->onlineTask->Split_Method
class Reverse_Eachword
{	int k;
	String reverse(String s)
	{
		if(s.isEmpty()) return "null";
		else
		{
			s=s.concat(" ");
			StringBuffer buff=new StringBuffer();
			
			for(int i=0;i<s.length();i++)
			{
				if(s.charAt(i)==' ')
				{
					for(int j=i-1;j>=k;j--)
						buff.append(s.charAt(j));
					k=i+1;
					buff.append(" ");
				}
			}
			return buff.toString();
		}
	}
}

public class Tester_Reverse_Eachword
{	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String :");
		String s=sc.nextLine();
		Reverse_Eachword re=new Reverse_Eachword();
		System.out.println(re.reverse(s));
	}
}
