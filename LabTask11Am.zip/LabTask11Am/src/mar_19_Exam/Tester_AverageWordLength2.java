package mar_19_Exam;
import java.util.Scanner;

class AverageWordLength2
{
	int getAverageWordLength(String s)
	{	int k=0,i=0;
	
	if(s.isEmpty())return 0;
	else
	 {
		s=s.concat(" ");
		StringBuffer buff=new StringBuffer();
		
		for(i=0;i<s.length();i++)
		    	if(s.charAt(i)==' ') k++;
		return (i-k)/k;
	 }
	}
}

public class Tester_AverageWordLength2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s=sc.nextLine();
		AverageWordLength2 a=new AverageWordLength2();
		System.out.println(a.getAverageWordLength(s));
	}
}
