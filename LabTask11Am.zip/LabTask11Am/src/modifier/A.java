package modifier;

 class B
{
	public int a=10;
	private int b=20;
	protected int c=30;
	int d=40;
}

public class A
{
	public static void main(String argd[])
	{
		B ob=new B();
		System.out.println(ob.a);
	//	System.out.println(ob.b);
		System.out.println(ob.c);
		System.out.println(ob.d);
	}
}
