package modifier;

class Ab
{
    protected static String s = "A";
}
 
class Bc extends Ab
{
     
}
 
class C extends Bc
{   
    static void methodOfC()
    {
        System.out.println(s);
    }
}
 
public class Q14_28Feb
{
    public static void main(String[] args)
    {
        C.methodOfC();
    }
}