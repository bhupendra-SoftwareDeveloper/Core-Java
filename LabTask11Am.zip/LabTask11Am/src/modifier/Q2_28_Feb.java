package modifier;

public class Q2_28_Feb
{
	private Q2_28_Feb()
	{
		System.out.println("First Constructor");
	}
	
	private Q2_28_Feb(int i)
	{
		System.out.println("Second Constructor");
	}
	
	public static void main(String[] args)
	{
	//	Q2_28_2 ob=new Q2_28_Feb();
	//	new D().m1();
		//ob.m1();
	}
	class D
	{
		void m1()
		{
			System.out.println("Class D m1()");
		}
	} 
}
