package modifier;
/*
private class Q3_28_Feb
{
	private class B
	{
		
	}
}
*/
//error:-Illegal modifier for the class Q3_28_Feb; only public, abstract & final are permitted