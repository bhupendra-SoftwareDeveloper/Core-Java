package modifier;

class Q4_28Feb
{
	protected int i;
}
/*
class B extends Q4_28Feb
{
	public static void main(String[] args)
	{
		B ob=new B();
		System.out.println(ob.i);
	}
}*/