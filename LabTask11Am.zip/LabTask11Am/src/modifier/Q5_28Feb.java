package modifier;

class Q5_28Feb
{
	private class B
	{
		
	}
}/*
public class MainClass extends B 
{
	public static void main(String[] args)
	{
		B b=new B();
	}
}
*/