package modifier;

public class UsingIn_Constructor1
{
	public UsingIn_Constructor1(int a)
	{
		System.out.println("Public constructor called="+a);
	}
	private UsingIn_Constructor1(int a,int b)
	{
		System.out.println("Private constructor called="+(a+b));
	}
	protected UsingIn_Constructor1(int a,int b, int c)
	{
		System.out.println("Protected constructor called="+(a+b+c));
	}
	UsingIn_Constructor1()
	{
		System.out.println("Default constructor called");
	}

	public static void main(String[] args)
	{
		UsingIn_Constructor1 dob=new UsingIn_Constructor1();
		UsingIn_Constructor1 pob=new UsingIn_Constructor1(5);
		UsingIn_Constructor1 protob=new UsingIn_Constructor1(5,6,4);
		UsingIn_Constructor1 privob=new UsingIn_Constructor1(5,2);
	}
}
