package modifier;

public class UsingIn_Constructor2
{
	public static void main(String[] args)
	{
		UsingIn_Constructor1 defaultobject=new UsingIn_Constructor1();
		UsingIn_Constructor1 publicob=new UsingIn_Constructor1(10);
//		UsingIn_Constructor1 privateob=new UsingIn_Constructor1(10,20);
		UsingIn_Constructor1 protectedob=new UsingIn_Constructor1(10,20,2);
	}
}
