package multiThreading;
class TicketDispenser implements Runnable
{
	int allotedSeats=0;
	int maxSeats=100;
	synchronized public void run()
	{
		if(allotedSeats<100)
			System.out.println(Thread.currentThread().getName()+" Ticket Has been Booked & Your Seat no is:"+allotSeatNumber());
		else System.out.println(Thread.currentThread().getName()+" Ticket Not Booked...Seat Is Full..Try Next Time");		
	}
	
	int allotSeatNumber()
	{ 	if(allotedSeats>100) return -1;
		else allotedSeats++;
		return allotedSeats;
	}
}

public class Tester_Railway_Reservation
{
	public static void main(String[] args) throws InterruptedException
	{
		TicketDispenser td=new TicketDispenser();
		for(int i=1;i<=100;i++)
		{
			Thread t=new Thread(td);
			t.start();
//			t.join();
		}
	}
}
