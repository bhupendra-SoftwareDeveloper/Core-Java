package myTask;
@FunctionalInterface
interface A{
	public int square(int x);
}
