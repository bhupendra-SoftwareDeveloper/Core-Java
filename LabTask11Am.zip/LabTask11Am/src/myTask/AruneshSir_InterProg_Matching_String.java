package myTask;

public class AruneshSir_InterProg_Matching_String {

	public static void main(String[] args)
	{
		int c=0,m=0,c2=1,k=0;
	//	String s1[]= {"arc","nep","tis"};
	//	String s2[]= {"sit","car","pen"};
		String s1[]= {"cnhul","estl","rakeb","ahev"};
		String s2[]= {"lets","have","lunch","break"};
		
		for(int i=0;i<s1.length;i++)
		{
			for(int j=0;j<s1[i].length();j++)
			{
				for(k=0;k<s2.length;k++)
				{
					for(int l=0;l<s2[k].length();l++)
					{
						if(s2[k].length()==s1[i].length())
							if(s1[i].charAt(j)==s2[k].charAt(l))c++;
					}
					
					if(c>0)
					{
						if(m==k)c2++;
						m=k;
						c=0;
						break;
					}
				}
			}
			System.out.print(k);
			c2=1;
		}
	}

}
