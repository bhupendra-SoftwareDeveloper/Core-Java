package myTask;
import java.util.Scanner;

class Rank
{
	void rankList(String name[],int scholar[],int marks[])
	{
		String tempName=null,tmplen=null;
		int tempMarks=0,tmpschlr=0;
		int tempScholar=0;
		for(int i=0;i<marks.length;i++)
		{
			for(int j=i+1;j<marks.length;j++)
			{
				if(marks[j]>=marks[i])
				{
					if(marks[j]==marks[i])
					{
						if(name[j]==name[i])
						{
							for(int k=0;k<=1;k++)
							{
								if(scholar[j]<scholar[i])
								{
									tmpschlr=scholar[i];
									scholar[i]=scholar[j];
									scholar[j]=tmpschlr;
								}
							}
						}
						else
						{
							for(int k=0;k<=1;k++)
							{
								if(name[j].length()<name[i].length())
								{
									tmplen=name[i];
									name[i]=name[j];
									name[j]=tmplen;
								}
							}
						}
					}
					else
					{
						tempMarks=marks[i];
						tempName=name[i];
						tempScholar=scholar[i];
						marks[i]=marks[j];
						name[i]=name[j];
						scholar[i]=scholar[j];
						marks[j]=tempMarks;
						name[j]=tempName;
						scholar[j]=tempScholar;
					}
				}
			}
		}
		
		for(int i=0;i<name.length;i++)
			System.out.println("NAME: "+name[i]+"\n"+"SCHOLAR NUMBER: "+scholar[i]+"\n"+"MARKS "+marks[i]+"\n");
	}
}

public class Arunesh_sir_Interview_Prog
{	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter Total Students:");
		int student=sc.nextInt();
		
		int a[]=new int[student];
		String name[]=new String[student];
		int scholar[]=new int[student];
		int marks[]=new int[student];
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println("Enter Name:");
			sc.nextLine();
			name[i]=sc.nextLine();
			
			System.out.println("Enter Scholar Number:");
			scholar[i]=sc.nextInt();
			System.out.println("Enter Marks:");
			marks[i]=sc.nextInt();
		}
		Rank r=new Rank();
		r.rankList(name,scholar,marks);
	}
}
