package myTask;

public class Arunesh_sir_Reverse_And_Add_Untill_ReverseSame
{
	public static String pal(int a)
	{
		String s="",s2="";
		int val=a;
		int rev=0,c=0;
		while(a!=0)
		{
			int rem=a%10;
			rev=rev*10+rem;
			a/=10;
		}
		if(val==rev)
			s+=val;
		else
		{
			val+=rev;
			s2=Arunesh_sir_Reverse_And_Add_Untill_ReverseSame.pal(val);
			c++;
			if(c==1)return s2;
		}
		return s;
	}
	public static void main(String[] args)
	{
		String str=Arunesh_sir_Reverse_And_Add_Untill_ReverseSame.pal(165);
		System.out.println("S: "+str);
	}

}
