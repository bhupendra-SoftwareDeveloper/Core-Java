package myTask;
import java.util.*;
public class CJSS_InterView_Ques {

	public static void main(String[] args)
	{
		/*
		//1st Prog
		String s="CJSS TECHNOLOGY IS AWESOME";
		
		String sar[]=s.split(" ");
		for(int i=sar.length-1;i>=0;i--)
			System.out.print(sar[i]+" ");
		*/
		
		/*
		//2nd Prog
		int c=0;
		String s="cjssxcjssnjsd";
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='c')
			{
				
				if(s.charAt(i+1)=='j')
				{
					
					if(s.charAt(i+2)=='s')
					{
						
						if(s.charAt(i+3)=='s')
						{
							i+=3;
							c++;
						}
					}
				}
			}
		}
		System.out.println(c);
		*/
		/*
		 //3rd Prog
		int ar[]= {1,1,3,2,1,3,4,5,6};
		int c=0,m=0,t=0;
		
		for(int i=0;i<ar.length-1;i++)
		{
			for(int j=0;j<ar.length;j++)
			{
				if(ar[i]>ar[j])
				{
					t=ar[i];
					ar[i]=ar[j];
					ar[j]=t;
				}
			}
		}
		for(int i=0;i<ar.length-1;i++)
		{
			for(int j=0;j<ar.length;j++)
			{
				if(ar[i]==ar[j])c++;
			}
			if(c>1)
			{
				m++;
				c=0;
			}
			if(m==2)
			{
				System.out.println(ar[i]);
				break;
			}
		}
		*/
		
		//4th Prog
		List<String> al=new ArrayList<>();
		al.add("AP 05 CY6747");
		al.add("TS 09 C86447");
		al.add("AP 04 KY6747");
		al.add("JB 03 CL6847");
		al.add("KL 04 UL9847");
		
		String s=null;
		System.out.println("----1st condition----");
		System.out.println(al);
		System.out.println("----2nd condition----");
		for(int i=0;i<al.size();i++)
		{
			s=al.get(i);
			
			if(s.contains("AP "))System.out.println(s);
		}
		
		System.out.println("----3rd condition----");
		for(int i=0;i<al.size();i++)
		{
			s=al.get(i);
			
			if(s.contains("AP 05"))System.out.println(s);
		}
	}

}
