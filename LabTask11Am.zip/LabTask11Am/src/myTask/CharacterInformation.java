package myTask;
// import java.util.Scanner;
public class CharacterInformation
{
	int c;
	public static void main(String[] args)
	{
		String s2="abc bbc";
		System.out.println(s2.compareTo(" bbc"));
	 //	int c=0;
	//	Scanner sc=new Scanner(System.in);
		String s1="J@v@ 123";
//		for(int i=0;i<s1.length();i++)
//		{	c=s1.charAt(i);
//			if(c>65&&c<90) System.out.println("Character '"+s1.charAt(i)+"' is letter in Upper Case");
//			else if(c>96&&c<123) System.out.println("Character '"+s1.charAt(i)+"' is letter in Lower Case");
//			else if(c>47&&c<59) System.out.println("Character '"+s1.charAt(i)+"' is Digit");
//			else System.out.println("Character '"+s1.charAt(i)+"' is Special Character");
//			System.out.println();
//		}
//		for(int i=0;i<s1.length();i++)
//		{	
//			if(Character.isUpperCase(s1.charAt(i)))System.out.println("Character '"+s1.charAt(i)+"' is letter in Upper Case");
//			else if(Character.isLowerCase(s1.charAt(i)))System.out.println("Character '"+s1.charAt(i)+"' is letter in Lower Case");
//			else if(Character.isDigit(s1.charAt(i)))System.out.println("Character '"+s1.charAt(i)+"' is Digit");
//			else System.out.println("Character '"+s1.charAt(i)+"' is Special Character");
		}
	}
	
