package myTask;

class Parent_DownCasting
{
	void vehical()
	{
		System.out.println("This is parents vehical down");
	}
}

public class Child_DownCasting extends Parent_DownCasting
{
	void vehical()
	{
		System.out.println("This is child vehical down");
	}
	
	public static void main(String[] args)
	{
		Parent_DownCasting	pd1=new Child_DownCasting();
		Child_DownCasting dc=(Child_DownCasting)pd1;
		dc.vehical();
	}
}
