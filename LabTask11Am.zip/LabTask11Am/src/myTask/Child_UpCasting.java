package myTask;

class Parent_UpCasting
{
	void vehical()
	{
		System.out.println("This is parents vehical");
	}
}

public class Child_UpCasting extends Parent_UpCasting
{
	void vehical()
	{
		System.out.println("This is child vehical");
	}
	
	public static void main(String[] args)
	{
		Child_UpCasting uc=new Child_UpCasting();
		uc.vehical();
		System.out.println("---------------------------------");
		Parent_UpCasting uc2=(Parent_UpCasting) new Child_UpCasting(); //UpCasting
		uc.vehical();
	}
}
