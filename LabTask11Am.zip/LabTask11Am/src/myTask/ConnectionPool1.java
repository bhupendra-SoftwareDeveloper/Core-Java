package myTask;
import java.sql.*;
import java.util.*;
public class ConnectionPool1
{
	public String url,uname,pwd;
	
	public ConnectionPool1(String url, String uname, String pwd)
	{
		super();
		this.url = url;
		this.uname = uname;
		this.pwd = pwd;
	}

	public Vector<Connection> v = new Vector<Connection>();
	
	public void createConnection()
	{
		try
		{
			while(v.size()<5)
			{
				System.out.println("Connection pool is Not Full...");
				Connection con=DriverManager.getConnection(url,uname,pwd);
				v.addElement(con);
				System.out.println(con);
			}
			if(v.size()==5)
				System.out.println("Connection pool Full...");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public synchronized Connection useConnection()
	{
		Connection con=v.firstElement();
		v.remove(con);
		return con;
	}
	
	public synchronized void returnConnection(Connection con)
	{
		v.addElement(con);
		System.out.println("Connection Returned into Pool...");
	}
}
