package myTask;
import java.sql.*;
public class ConnectionPool2
{

	public static void main(String[] args)
	{
		try
		{
			ConnectionPool1 cp=new ConnectionPool1
			("jdbc:oracle:thin:@localhost:1521:XE","C##PRACTICE","ORACLE");
			
			cp.createConnection();
			System.out.println("Total Connections: "+cp.v.size());
			Connection con=cp.useConnection();
			System.out.println("User Using: "+con);
			System.out.println("Total Connections: "+cp.v.size());
			cp.returnConnection(con);
			System.out.println("Total Connections: "+cp.v.size());
			System.out.println("-----------Following are Connections from the Connection Pool-----------");
			cp.v.forEach(data->System.out.println(data));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
