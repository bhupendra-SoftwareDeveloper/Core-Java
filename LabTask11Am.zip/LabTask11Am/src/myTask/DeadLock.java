package myTask;

public class DeadLock extends Thread
{
	static final String a="java";
	static final String b="orcale";
	public static void main(String[] args)
	{
		Thread t1=new Thread()
		{
			public void run()
			{
				System.out.println("This is 1st Thread 1st stmt..");
				
				synchronized(a)
				{
					System.out.println("This is 1st synchronized block of 1st thread "+a);
					
					try
					{
						Thread.sleep(1000);
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					
					synchronized(b)
					{
						System.out.println("This is 2nd synchronized block of 1st thread "+b);
					}
				}
				System.out.println("No deadlock...");
			}
		};
		
		Thread t2=new Thread()
		{
			public void run()
			{
				System.out.println("This is 2nd Thread 1st stmt..");
				
				synchronized(b)
				{
					System.out.println("This is 1st synchronized block of 2nd thread "+b);
					
					try
					{
						Thread.sleep(1000);
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					
					synchronized(a)
					{
						System.out.println("This is 2nd synchronized block of 2nd thread "+a);
					}
				}
				System.out.println("No deadlock...");
			}
		};
		
		t1.start();
		t2.start();
	}

}
