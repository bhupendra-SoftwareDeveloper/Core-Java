package myTask;
import java.util.HashSet;
public class Dupli_Char_Recursion_EngageBay 
{
	static int c,k=0;
	static HashSet<String> hm=new HashSet<String>();
	
	static void dupli(int i,int j)
	{
		String s="Java Programmer";
		if(i<s.length()-1)
		{
			if(j<s.length())
			{
				if(s.charAt(i)==s.charAt(j))
				{				
					c++;
					dupli(i,++k);
				}
				else dupli(i,++k);
			}
			else 
			{
				if(c>1 && s.charAt(i)!=' ') hm.add(s.charAt(i)+" = "+c);
				c=0;
				k=0;
				dupli(++i,++k);
			}
			
		}
		else System.out.println(hm);
	}
	public static void main(String[] args) 
	{
		Dupli_Char_Recursion_EngageBay p=new Dupli_Char_Recursion_EngageBay();
		p.dupli(0,0);
	}

}
