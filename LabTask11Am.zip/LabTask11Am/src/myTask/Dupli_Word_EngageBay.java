package myTask;

public class Dupli_Word_EngageBay
{	int c,k;
	void m()
	{
		String s[]= {"java","oracle","javaScript","html","java"};
		String s2[]=new String[s.length];
		for(int i=0;i<s.length-1;i++)
		{	c=0;
			for(int j=i+1;j<s.length;j++)
			{
				if(s[i]==s[j])
					c++;
			}
			if(c<1)s2[k++]=s[i];
		}
		for(int i=0;i<s2.length;i++)
		{
			if(s2[i]!=null)System.out.println(s2[i]);
			else break;
		}
	}
	public static void main(String[] args) {
		new Dupli_Word_EngageBay().m();
	}
}
