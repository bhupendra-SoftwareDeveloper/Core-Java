package myTask;

public class Filter_Method
{
	int m(Filter_Method_Interface p)
	{
		boolean k=false;
		int c=0;
		int ar[]= {5,8,10,96,4,17,45};
		for(int i=0;i<ar.length;i++)
		{
			k=p.count(ar[i]);
			if(k==true)c++;
		}
		return c;
	}
	public static void main(String[] args)
	{
		Filter_Method p=new Filter_Method();
		int k=p.m(x->x>10);
		System.out.println(k);
	}

}
