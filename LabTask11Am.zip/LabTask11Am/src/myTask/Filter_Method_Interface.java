package myTask;

public interface Filter_Method_Interface
{
	boolean count(int i);
}
