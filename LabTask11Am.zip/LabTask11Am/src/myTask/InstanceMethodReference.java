package myTask;
class Hello{
	public int sqr(int a) {
		return a*a;
	}
}
public class InstanceMethodReference {
	public static void main(String[] args) {
		Hello obj=new Hello();
		A a=obj::sqr;
		int result=a.square(6);
		System.out.println(result);
	}
}
