/*
 Given an array arr[] and an integer K where K
 is smaller than size of array, the task is to find the Kth 
 smallest element in the given array. It is given that all array 
 elements are distinct.
 Input:
N = 5
arr[] = 7 10 4 20 15
K = 4
Output : 15
Explanation :
4th smallest element in the given 
array is 15.*/

package myTask;
import java.util.Scanner;

class Smallest
{	int temp,i;
	int getsmall(int []a,int k)
	{
		for(i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[j]<a[i])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		return a[k-1];
	}
}
public class Kth_Smallest_elem
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		byte b1= 25;
		byte b2=45;
		byte b3= (byte)(b1+b2);
		System.out.println(b3);
		System.out.println("Enter array size:");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter "+n+" Integer values");
		for(int i=0;i<a.length;i++)
			a[i]=sc.nextInt();
		System.out.println("Enter kth number:");
		int k=sc.nextInt();
		Smallest s=new Smallest();
	//	System.out.println(s.getsmall(a,k));
	}
}
