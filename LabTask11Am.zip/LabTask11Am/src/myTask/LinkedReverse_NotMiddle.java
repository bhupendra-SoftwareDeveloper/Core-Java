package myTask;
import java.util.LinkedList;

class LinkedReverse
{
	void m1(LinkedList<Integer> ll)
	{
		int i,j=0;
		for(i=ll.size()-1,j=0;i>=0;i--,j++)
		{
			if(i==ll.size()/2)
				System.out.print(ll.get(j)+" ");
			else if(i==((ll.size()/2)-1))
				System.out.print(ll.get(j)+" ");
			else
		     	System.out.print(ll.get(i)+" ");
		}
	}
}
	
public class LinkedReverse_NotMiddle
{
	public static void main(String[] args)
	{
		LinkedList<Integer> ll=new LinkedList<Integer>();
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(5);
		ll.add(6);
		LinkedReverse l=new LinkedReverse();
		l.m1(ll);
		//1 2 3 4 5 6
		//6 5 3 4 2 1
	}
}
