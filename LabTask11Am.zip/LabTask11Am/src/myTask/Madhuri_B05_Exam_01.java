package myTask;
import java.util.*;

public class Madhuri_B05_Exam_01 {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter number: ");
		int num=sc.nextInt();
		
		if(((num%9)==0)&&(num%13)==0)
			System.out.println("Foo Bar");
		else if((num%9)==0)
			System.out.println("Foo");
		else if((num%13)==0)
			System.out.println("Bar");
		
		sc.close();
	}

}
