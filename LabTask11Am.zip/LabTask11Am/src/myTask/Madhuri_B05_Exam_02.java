package myTask;
import java.util.Scanner;

public class Madhuri_B05_Exam_02 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sum=0,rem=0;
		System.out.println("Enter number: ");
		int num=sc.nextInt();
		
		while(num!=0)
		{
			rem=num%10;
			sum+=rem;
			num/=10;
		}
		System.out.println("Total : "+sum);
		sc.close();
	}

}
