package myTask;

public class MaximumOccuranceOfAnayChar {

	public int maxOccurance(String s)
	{
		int max=0,c=0;
		
		for(int i=0;i<s.length();i++)
		{
			for(int j=0;j<s.length();j++)
				if(s.charAt(i)==s.charAt(j)) c++;
			
			if(max<c) max=c;
			c=0;
		}
		return max;
	}
	public static void main(String[] args)
	{
		String s="success";
		int max=new MaximumOccuranceOfAnayChar().maxOccurance(s);
		System.out.println(max);
	}

}
