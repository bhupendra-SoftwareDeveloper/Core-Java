package myTask;

public class Method_ReferenceA 
{
	void sum(int x,int y)
	{
		System.out.println("Addition in Non static method: "+(x+y));
	}
	
	static void sub(int x,int y)
	{
		System.out.println("Subtraction in static method: "+(x-y));
	}
	
	void div(int x,int y)
	{
		System.out.println("Division in Non static method: "+(x/y));
	}
	
	Method_ReferenceA(int x,int y)
	{
		System.out.println("Multiplication in Constructor: "+(x*y));
	}
}
