package myTask;

public class Method_ReferenceB 
{
	public static void main(String[] args) 
	{
	//	Method_Reference_Inter data=new Method_ReferenceA(10,20)::sum;
		
	//	Method_Reference_Inter data=Method_ReferenceA::sub;
		
		Method_Reference_Inter data=new Method_ReferenceA(10,20)::div;
		
	//	Method_Reference_Inter data=Method_ReferenceA::new;
		data.operation(70, 20);
	}

}
