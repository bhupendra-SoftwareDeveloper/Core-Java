package myTask;

public interface Method_Reference_Inter 
{
	void operation(int a,int b);
}
