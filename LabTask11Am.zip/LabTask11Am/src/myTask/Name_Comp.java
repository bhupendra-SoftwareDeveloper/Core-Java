package myTask;
import java.util.Comparator;
public class Name_Comp implements Comparator<Prac_Comparable>
{
	public int compare(Prac_Comparable ob1,Prac_Comparable ob2)
	{
		return ob1.name.compareTo(ob2.name);
	}
}
