package myTask;
import java.util.Scanner;

class PassValid
{
	String validate(String s)
	{	int u=0,l=0,d=0,sp=0;
		if(s.length()<8) return "PassWord Length must be atleast 8";
		else
		{
			for(int i=0;i<s.length();i++)
			{
				if(Character.isUpperCase(s.charAt(i)))u++;
				else if(Character.isLowerCase(s.charAt(i)))l++;
				else if(Character.isDigit(s.charAt(i)))d++;
				else if(s.charAt(i)=='@')sp++;
			}
			if(u<1) return "Atleast One Character Should Be Upper Case";
			if(l<1) return "Atleast One Character Should Be Lower Case";
			if(sp<1) return "Use '@' Atleast One Time";
			if(d<1) return "Atleast One Digit is Neccessary";
		}
		return "PassWord Set Successfully...";
	}
}

public class Password_Validation
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String s="";
		System.out.println("Enter the PassWord: ");
		s=sc.nextLine();
		PassValid pv= new PassValid();
		System.out.println(pv.validate(s));
	}
}
