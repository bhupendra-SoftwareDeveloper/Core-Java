package myTask;

public class Prac_Comparable implements Comparable<Prac_Comparable>
{
	int rollNo,fee,math_marks,sci_marks;
	String name;
	
	public Prac_Comparable(int rollNo, int fee, int math_marks, int sci_marks, String name) {
		super();
		this.rollNo = rollNo;
		this.fee = fee;
		this.math_marks = math_marks;
		this.sci_marks = sci_marks;
		this.name = name;
	}
	
	public int compareTo(Prac_Comparable ob)
	{
		return this.fee-ob.fee;
	}

	@Override
	public String toString() {
		return "Prac [rollNo=" + rollNo + ", fee=" + fee + ", math_marks=" + math_marks + ", sci_marks=" + sci_marks
				+ ", name=" + name + "]";
	}
	
}
