package myTask;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
public class Prac_Imple
{
	public static void main(String[] args)
	{
		ArrayList<Prac_Comparable> al=new ArrayList<Prac_Comparable>();
		al.add(new Prac_Comparable(100,5000,66,72,"Rahul"));
		al.add(new Prac_Comparable(101,7500,60,20,"Pankaj"));
		al.add(new Prac_Comparable(104,6200,86,73,"Virat"));
		al.add(new Prac_Comparable(102,4000,75,88,"Hardik"));
		
	/*	Collections.sort(al);			//Comparable
		Iterator<Prac_Comparable>i=al.iterator();
		while(i.hasNext())
			System.out.println(i.next());*/
		
		Collections.sort(al,new Id_Comp());
		Iterator<Prac_Comparable>i=al.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		
		System.out.println();
		
		Collections.sort(al,new Name_Comp());
		Iterator<Prac_Comparable> j=al.iterator();
		while(j.hasNext())
			System.out.println(j.next());
		
		System.out.println();
		
		Collections.sort(al,new Fee_Comp());
		Iterator<Prac_Comparable> k=al.iterator();
		while(k.hasNext())
			System.out.println(k.next());
	}
}
