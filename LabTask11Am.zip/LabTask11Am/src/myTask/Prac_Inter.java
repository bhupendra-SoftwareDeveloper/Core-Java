package myTask;

public interface Prac_Inter
{
	void prac(int x);
}
