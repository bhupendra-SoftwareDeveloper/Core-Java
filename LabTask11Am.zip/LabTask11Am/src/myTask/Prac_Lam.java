package myTask;

public class Prac_Lam
{
	static void m1(int a)
	{
		System.out.println("This is static method...");
		System.out.println(a);
	}
	public static void main(String[] args)
	{
		Prac_Inter x=data->System.out.println(500);
		x.prac(100);
		
		Prac_Inter y=Prac_Lam::m1;	//Method Reference 
		y.prac(20);
	}

}
 