package myTask;
import java.io.FileInputStream;
import java.io.FileOutputStream;

class Driver
{
	void readFromFile() throws Exception
	{
		FileInputStream fis=new FileInputStream("D:\\Let's Do It\\IOStreams\\R&W&CPY.txt");
		int i;
		while((i=fis.read())!=-1)
			System.out.print((char)i);
		fis.close();
	}
	
	void writeInFile() throws Exception
	{
		FileOutputStream fos=new FileOutputStream("D:\\Let's Do It\\IOStreams\\R&W&CPY.txt",true);
		String data="And i am talking to my friend.";
		byte b[]=data.getBytes();
		fos.write(b);
		System.out.println("Data Updated...");
		fos.close();
	}
	
	void copy() throws Exception
	{
		FileInputStream fis=new FileInputStream("D:\\Let's Do It\\IOStreams\\R&W&CPY.txt");
		FileOutputStream fos=new FileOutputStream("D:\\Let's Do It\\IOStreams\\R&W&CPY2.txt");
		int i;
		while((i=fis.read())!=-1)
			fos.write(i);
		System.out.println("Data copied...");
		fis.close();
		fos.close();
	}
}
public class Reading_Writing_Coping_IntoFile2
{
	public static void main(String[] args) throws Exception
	{
		Driver d=new Driver();
		d.readFromFile();
	//	d.writeInFile();
	//	d.copy();
	}
}
