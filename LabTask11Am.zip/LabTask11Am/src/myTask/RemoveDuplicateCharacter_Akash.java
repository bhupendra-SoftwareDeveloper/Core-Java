package myTask;

public class RemoveDuplicateCharacter_Akash {

	public String removeDupli(String s)
	{
		int c=0;
		String sar[]=s.split(" ");
		String merged="", actual="";
		
		for(int i=0;i<sar.length;i++)
			merged+=sar[i];
		
		actual+=merged.charAt(0);
		
		for(int i=1;i<merged.length();i++)
		{
			for(int j=i-1;j>=0;j--)
			{
				if(merged.charAt(i)==merged.charAt(j))c++;
			}
			if(c>0)c=0;
			else actual+=merged.charAt(i);
		}
			
		return actual;
	}
	
	public static void main(String[] args) {
		String s="object oriented programming";
		String s2=new RemoveDuplicateCharacter_Akash().removeDupli(s);
		System.out.println(s2);
	}

}
