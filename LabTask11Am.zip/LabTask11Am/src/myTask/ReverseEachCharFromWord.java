package myTask;

public class ReverseEachCharFromWord
{
	public String reverseEachWord(String s)
	{
		String sar[]=s.split(" ");
		String s2="";
		for(int i=0;i<sar.length;i++)
		{
			for(int j=sar[i].length()-1;j>=0;j--)
			{
				s2+=sar[i].charAt(j);
			}
			s2+=" ";
		}
		return s2;
	}
	public static void main(String[] args)
	{
		String s="all cows eat grass";
		
		String st=new ReverseEachCharFromWord().reverseEachWord(s);
		
		System.out.println(st);
	}
}
