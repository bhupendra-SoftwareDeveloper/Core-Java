package myTask;
public class Split_Method
{
	public static void main(String[] args)
	{
		String s1="Hare,Ram,Hare,Krishna";
		String s2[]=s1.split(",");	//4
		System.out.println(s2.length);
		System.out.println(java.util.Arrays.toString(s2));
		
		s2=s1.split("e");
		System.out.println(s2.length);	//3
		System.out.println(java.util.Arrays.toString(s2));
		
		s2=s1.split("H");
		System.out.println(s2.length);	//3
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="aaaaa";
		s2=s1.split("a");
		System.out.println(s2.length);	//0
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="aaaaab";
		s2=s1.split("a");
		System.out.println(s2.length);	//6
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="Jay Shree Ram";
		s2=s1.split("J");
		System.out.println(s2.length);	//2
		System.out.println(java.util.Arrays.toString(s2));
	//empty String as 1st token Because there is nothing before J(regular expression)
	//& right side String as 1 token
		
		s1="Jay Shree Ram Jay Bajrang bali";
		s2=s1.split("J");
		System.out.println(s2.length);	//3
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="Jay Shree Ram";
		s2=s1.split("m");
		System.out.println(s2.length);	//1
		System.out.println(java.util.Arrays.toString(s2));
	//Empty string not added to the right side
		
		s1="Jay Shree Ram";
		s2=s1.split("k");
		System.out.println(s2.length);	//1
		System.out.println(java.util.Arrays.toString(s2));
	// If k(regex) not found then it will return whole string as 1 token
		
		s1="Jay Shree Ram";
		s2=s1.split("JSR");
		System.out.println(s2.length);	//1 // because k(regex) not found then so returns whole string as 1 token
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="Jay Shree Ram";
		s2=s1.split("[JSR]");
		System.out.println(s2.length);	//4
		System.out.println(java.util.Arrays.toString(s2));
	// by every character splitting
		
		s1="abc.txt";
		s2=s1.split(".");//delimeter
		System.out.println(s2.length);	//0
		System.out.println(java.util.Arrays.toString(s2));
	// .Dot is not regular expression,it will consider each character as delimeter
		
		s1="abc.txt";
		s2=s1.split("[.]");//delimeter
		System.out.println(s2.length);	//2
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="abc.txt";
		s2=s1.split("//.");//delimeter
		System.out.println(s2.length);	//0
		System.out.println(java.util.Arrays.toString(s2));
		
		s1="How Are You?";
		s2=s1.split(" ");//delimeter
		System.out.println(s2.length);	//3
		for(int i=s2.length-1;i>=0;i--) System.out.print(s2[i]+" ");
	//	System.out.println(java.util.Arrays.toString(s2));
		
		s1="sab moh maya hai";	//s1 is String var
		s2=s1.split(" ");//delimeter//s2 is a String array var
		StringBuilder s4=new StringBuilder();
		System.out.println(s2.length);
		for(int i=s2.length-1;i>=0;i--)
		{
			//s4.append(s2[i]+" ");
		//don't concat " " with StringBuffer & StringBuilder becuase due to 
		//this 1 string object also created internally..so always write as follow
			s4.append(s2[i]);
			s4.append(" ");
		}
		System.out.println(s4.append(s4.toString().trim()).reverse());
	}
}
