package myTask;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.ArrayList;
import java.util.List;

public class StreamAp
{
	private void m1()
	{
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(0);
		al.add(10);
		al.add(20);
		al.add(30);
		
		Stream <Integer>s=al.stream().filter(x->x!=0);
		long l=s.count();
		System.out.println(l);
	}
	
	private void m2()
	{
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(0);
		al.add(20);
		al.add(10);
		al.add(30);
		
		Stream <Integer>s=al.stream().map(x->(x%50)+x);
		List<Integer>li=s.collect(Collectors.toList());
		System.out.println(li);
	}
	
	private void m3()
	{
		ArrayList<Integer>al=new ArrayList<Integer>();
		al.add(0);
		al.add(20);
		al.add(10);
		al.add(30);
		
		Stream<Integer>s=al.stream().sorted();
		List<Integer>li=s.collect(Collectors.toList());
		System.out.println(li);
	}
	public static void main(String[] args)
	{
		StreamAp sap=new StreamAp();
	//	sap.m1();
	//	sap.m2();
		sap.m3();
	}
}
