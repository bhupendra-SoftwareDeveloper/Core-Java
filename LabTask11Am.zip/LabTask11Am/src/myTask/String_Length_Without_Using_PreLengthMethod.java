package myTask;

public class String_Length_Without_Using_PreLengthMethod
{
	public static void main(String[] args)
	{

		String s1="Monday";
		int count=0;
		char ch[]=s1.toCharArray();
		System.out.println(ch.length);
		
		byte b[]=s1.getBytes();
		System.out.println(b.length);
		
		try
		{
			for(int i=0;;i++)
			{
				s1.charAt(i);
				count++;
			}
		}
		
		catch(Exception e)
		{
			System.out.println(count);	
		}
	}
}
