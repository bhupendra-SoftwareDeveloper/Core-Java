package myTask;
class NoRepeatedCharacter
{
	public String noReapeatChar(String s)
	{
		String s2="";
		int c=0;
		for(int i=0;i<s.length();i++)
		{
			c=0;
			for(int j=0;j<s.length();j++)
			{
				if(s.charAt(i)!=' ')
				{
					if(s.charAt(i)==s.charAt(j))
						c++;
				}
			}
		if(c==1)s2=s2+s.charAt(i);
		}
		
		return s2;
	}
}
public class Tester_NoRepeatedCharacter 
{
	public static void main(String[] args)
	{
		String s="jennis";
		NoRepeatedCharacter nrc=new NoRepeatedCharacter();
		String s2=nrc.noReapeatChar(s);
		System.out.println(s2);
	}
}
