package myTask;
import java.util.Scanner;

class Union
{	int temp;
	static int i,count=1;
	
	int getUnion(int []a,int[] b)
	{
		int c[]=new int[a.length+b.length];
		
		for(i=0;i<a.length;i++) c[i]=a[i];
		
		for(int j=0;j<b.length;j++,i++) c[i]=b[j];
		
		for(int j=0;j<c.length;j++)
			{
				for(int k=j+1;k<c.length;k++)
				{
					if(c[j]>c[k])
					{
						temp=c[j];
						c[j]=c[k];
						c[k]=temp;
					}
				}
			}
		for(int j=0;j<c.length-1;j++)
				if(c[j]!=c[j+1]) count++;

		return count;
	}
}

public class Tester_Union
{
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("Enter 1st array size:");
		int fa=sc.nextInt();
		int a[]=new int[fa];
		System.out.println("Enter 2nd array size:");
		int sa=sc.nextInt();
		int b[]=new int[sa];
		System.out.println("Enter "+fa+" Integer values for 1st array:");
		for(int i=0;i<a.length;i++)
			a[i]=sc.nextInt();
		System.out.println("Data Entered in 1st array...");
		System.out.println("Now,Enter "+sa+" Integer values for 2nd array:");
		for(int i=0;i<b.length;i++)
			b[i]=sc.nextInt();
		System.out.println("Data Entered in 2nd array...");
		System.out.println("Total Union Numbers "+new Union().getUnion(a, b));
	}
}
