package thisKeyword;

class Student
{
	private int studentId;
	private String studentName; 
	private  int marks;
	private char grade; 
		
	public Student()
	{
		
	}

	public Student(int studentId, String studentName, int marks)
	{	
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;		
	}

	 public String toString()
	 {	
		 return "Student [studentId=" + studentId +", studentName=" + studentName + ", marks=" + marks + ", grade=" + grade +"]";
	 }
	 
	public String displayDetails()
	{
		return toString();
	}
	
	public void calculateGrade()
	{
		if(marks>90) this.grade='A';
		else if(marks>80 && marks<=90) this.grade='B';
		else if(marks>70 && marks<=80) this.grade='C';
		else if(marks>60 && marks<=70) this.grade='D';
		else this.grade='E';
	}
}

public class Tester
{
	public static void main(String[] args)
	{
		Student ob=new Student(152,"ABC",85);
		ob.calculateGrade();
	//	System.out.println(ob.displayDetails());
		System.out.println(ob);
	}
}