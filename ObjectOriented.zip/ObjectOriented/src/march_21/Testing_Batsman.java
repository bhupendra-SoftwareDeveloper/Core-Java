package march_21;

class Batsman
{
	String name;
	int runs;
	int matches;
	float batting_avg;
	
	public Batsman()
	{
	
	}

	public Batsman(String name, int runs, int matches)
	{
		this.name = name;
		this.runs = runs;
		this.matches = matches;
	}
	
	void computeBattingAverage()
	{
		if(matches<0||runs<0) System.out.println("Error");
		else if(matches<1&&runs>0) System.out.println("Error");
		else System.out.println("Name:"+name+"\n"+"Batting Average:"+((float)runs/matches));
	}
	void getStatistics()
	{
		if(matches<0||runs<0) System.out.println("Error");
		else if(matches<1&&runs>0) System.out.println("Error");
		else System.out.println("Name:"+name+"\n"+"Runs:"+runs+"\n"+"Matches:"+matches);
	}
}

public class Testing_Batsman
{
	public static void main(String[] args)
	{
		Batsman b=new Batsman("Sachin",245,10);
	//	b.computeBattingAverage();
		b.getStatistics();
	}
}
