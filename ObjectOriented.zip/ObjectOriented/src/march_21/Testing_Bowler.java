package march_21;

class Bowler
{
	String name;
	int wickets;
	int matches;
	int balls_bowled;
	int runs_conceded;
	
	Bowler()
	{
		
	}

	Bowler(String name,int wickets, int matches,int balls_bowled,int runs_conceded)
	{
		this.name=name;
		this.wickets=wickets;
		this.matches=matches;
		this.balls_bowled=balls_bowled;
		this.runs_conceded=runs_conceded;
	}
	
	void computeBowlingAverage()
	{	
		if(wickets<0||matches<0||balls_bowled<0||runs_conceded<0)
			System.out.println("Error");
		
		else if(matches<1)
		{
			if(runs_conceded>0||balls_bowled>0||wickets>0)
				System.out.println("Error");
		}
		
		else
		{
			System.out.println("Name:"+name+"\n"+"Bowling_average:"+((float)runs_conceded/wickets));
		}
	}
	
	void showStatistics()
	{	
		if(wickets<0||matches<0||balls_bowled<0||runs_conceded<0)
			System.out.println("Error");
		else if(matches<1)
		{
			if(runs_conceded>0||balls_bowled>0||wickets>0)
				System.out.println("Error");
		}
		else
		{
			System.out.println("Name:"+name+"\n"+"Wickets:"+wickets+"\n"+"Matches:"+matches+"\n"+"Balls_bowled:"+balls_bowled+"\n"+"Runs_conceded:"+runs_conceded);
		}
	}
	
	void computeStrikeRate()
	{		
		if(wickets<0||matches<0||balls_bowled<0||runs_conceded<0)
			System.out.println("Error");
		
		else if(matches<1)
		{
			if(runs_conceded>0||balls_bowled>0||wickets>0)
				System.out.println("Error");
		}
		
		else
		{
			System.out.println("Name:"+name+"\n"+"Strike_rate:"+((float)runs_conceded/balls_bowled)*100);
		}
	}
}

public class Testing_Bowler
{
	public static void main(String[] args)
	{
		Bowler ob=new Bowler("Sachin",7,5,755,125);
	
		ob.showStatistics();
	//	ob.computeBowlingAverage();
	//	ob.computeStrikeRate();
	}
}
