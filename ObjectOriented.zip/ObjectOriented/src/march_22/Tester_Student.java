package march_22;
import java.util.Scanner; 
class Student
{
	private int studentId,marks;
	private String studentName; 
	private char grade;
	 private void calculateGrade()
	 {
		if(marks>90) this.grade='A';
		else if(marks>80) this.grade='B';
		else if(marks>70) this.grade='C';
		else if(marks>60) this.grade='D';
		else this.grade='E';
	 }
	public Student()
	{

	}
	public Student(int studentId, String studentName,int marks)
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
	}
	String displayDetails()
	{
		return this.toString();
	}
	public String toString()
	{
		this.calculateGrade();
		return "Name:"+studentName+"\n"+"Id:"+studentId+"\n"+"Marks:"+marks+"\n"+"Grade:"+grade;
	}
}

public class Tester_Student
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ID:");
		int studentId=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name:");
		String studentName=sc.nextLine();
		System.out.println("Enter Marks:");
		int marks=sc.nextInt();
		Student s=new Student(studentId,studentName,marks);
		System.out.println(s.displayDetails());
	}
}
