/*
 Methods:
 1. Name: calculateSalary
    Arguments: Employee
    ReturnType: double
    Access Specifiers: static private
    
    Note: This method should calculate the salary based on employee working hours and perform any of the below
    1. return base pay for every hour employee work.
    2. reurn base pay and half for every hour over 40 hours per week.
    3. return -1 if working hours is negative or more than 40 hours.
    4. return 0 if the employee wage is less than $8.0.
    
    Input:(name, id, hoursWorked, basePay):
        Employee: "John", 123, 50, 17 
    Output:
        935.0 (Return value) 
    
    Input:
        Employee: "John", 123, 50, 7
    Output:
        0.0 (Return value)
 */
package march_23;
import java.util.Base64;
import java.util.Scanner;
class Employee
{
	String name="";
	int id;
	int hoursWorked;
	double basePay;
	
	public Employee()
	{
	
	}

	public Employee(String name, int id, int hoursWorked, double basePay)
	{
		super();
		this.name = name;
		this.id = id;
		this.hoursWorked = hoursWorked;
		this.basePay = basePay;
	}
}

class DayPay
{
	private static double calculateSalary(Employee e1)
	{
		if(e1.hoursWorked<0||e1.hoursWorked>60) return -1;
		else if(e1.basePay<8) return 0;
		else if(e1.hoursWorked<41) return e1.hoursWorked*e1.basePay;
		else
			return (40*e1.basePay)+(e1.hoursWorked-40)*e1.basePay*1.5;
	}
	public static String displayEmployeeDetails(Employee e2)
	{	
		return "Employee[Name: "+e2.name+", Id: "+e2.id+", Base Pay: "+e2.basePay+", No. of hours worked: "+e2.hoursWorked+", Payed: "+calculateSalary(e2);
	}
}

public class Tester_Employee
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name\nId\nWork Hour\nBase Pay");
		Employee e1=new Employee(sc.nextLine(),sc.nextInt(),sc.nextInt(),sc.nextDouble());
		System.out.println(DayPay.displayEmployeeDetails(e1));
	}
}