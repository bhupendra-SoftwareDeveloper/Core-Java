package march_24;

class Sports
{
	String getName(String s)
	{
		return "Sports";
	}
	String getNumberOfTeamMembers()
	{
		return "Each team has n players in Sports";
	}
}

class Soccer extends Sports
{
	String getName(String s)
	{
		return s;
	}
	String getNumberOfTeamMembers()
	{
		return "In "+getName("Soccer ")+"each team has 11 players";
	}
}

public class Tester_Sports
{
	public static void main(String[] args)
	{
		Sports s1= new Soccer();
		Sports s2= new Sports();
		Soccer s3= new Soccer();
		System.out.println(s1.getNumberOfTeamMembers());
		System.out.println(s2.getNumberOfTeamMembers());
		System.out.println(s3.getNumberOfTeamMembers());
	}
}
