package march_24;

class Student
{
	 int studentId;
	 String name;
	 double examFee;
	 
	public Student()
	{
		super();
	}
	
	public Student(int studentId, String name, double examFee)
	{
		super();
		this.studentId = studentId;
		this.name = name;
		this.examFee = examFee;
	} 
}

class DayScholar extends Student
{
	double  transportFee;
	
	public DayScholar()
	{
		
	}
	
	public DayScholar(int studentId, String name, double examFee, double transportFee)
	{
		super(studentId, name, examFee);
		this.transportFee = transportFee;
	}

	
	@Override
	public String toString()
	{
		return "DayScholar [transportFee=" + transportFee + ", studentId=" + studentId + ", name=" + name + ", examFee="
				+ examFee + "]";
	}

	String displayDetails()
	{
		return this.toString();
	}
	double payFee(double amount)
	{
		return amount-(transportFee+examFee);
	}
}

class Hosteller extends Student
{
	double hostelFee;
	
	public Hosteller()
	{
		
	}
	
	public Hosteller(int studentId, String name, double examFee, double hostelFee)
	{
		super(studentId, name, examFee);
		this.hostelFee = hostelFee;
	}

	
	@Override
	public String toString()
	{
		return "Hosteller [hostelFee=" + hostelFee + ", studentId=" + studentId + ", name=" + name + ", examFee="
				+ examFee + "]";
	}

	String displayDetails()
	{
		return this.toString();
	}
	double payFee(double amount)
	{
		return amount-(hostelFee+examFee);
	}
}

public class Tester_Strudent_Prog02
{
	public static void main(String[] args)
	{
//		DayScholar ds=new DayScholar(11,"Ram",3000,5000);
//		System.out.println(ds.displayDetails());
//		System.out.println("Remaining Amount= "+ds.payFee(50000));
		Hosteller h=new Hosteller(11,"John",3000,5000);
		System.out.println(h.displayDetails());
		System.out.println("Remaining Amount= "+h.payFee(50000));
	}
}
