package march_25;
public abstract class Cake
{
		private String shape;
		private String flavour;
		private int qty;
		private float price;
		
		
		public Cake()
		{
			super();
		}

		protected Cake(String shape, String flavour, int qty)
		{
			super();
			this.shape = shape;
			this.flavour = flavour;
			this.qty = qty;
		}

		protected String getShape() {
			return shape;
		}

		protected void setShape(String shape) {
			this.shape = shape;
		}

		protected String getFlavour() {
			return flavour;
		}

		protected void setFlavour(String flavour) {
			this.flavour = flavour;
		}

		protected int getQty() {
			return qty;
		}

		protected void setQty(int qty) {
			this.qty = qty;
		}

		protected float getPrice() {
			return price;
		}

		protected void setPrice(float price) {
			this.price = price;
		}
		
		protected void showCake()
		{
			System.out.println("A "+getFlavour()+" Cake Of "+getQty()+" Kg's "+"@ Rs."+getPrice()*getQty()+"/-");
		}
	}
