package march_25;
import java.util.Scanner;
class OrderCake extends Cake
{	Scanner sc=new Scanner(System.in);
	private String message;
	
	protected OrderCake(String shape, String flavour, int qty)
	{
		super(shape, flavour, qty);
	}
	
	public OrderCake()
	{
		super();
	}

	public OrderCake(String shape, String flavour, int qty, String message)
	{
		super(shape, flavour, qty);
		this.message = message;
	}	
	protected String getMessage() {
		return message;
	}

	protected void setMessage(String message) {
		this.message = message;
	}
	
	public void showCake()
	{	message=sc.nextLine();
		System.out.println("Enter Cake Price");
		setPrice(sc.nextFloat());
		if(message==null||message.isBlank()) super.showCake();
		else System.out.println("A "+getFlavour()+" Cake Of "+getQty()+" Kg's "+"@ Rs."+getPrice()*getQty()+"/-"+ getMessage());
	}
}

public class Tester_Cake
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Cake Shape\nEnter Cake Flavour\nEnter Cake Quantity in Kg\nIf you want to print any message then write message otherwise press enter");
		Cake oc=new OrderCake(sc.nextLine(),sc.nextLine(),sc.nextInt(),sc.nextLine());
		oc.showCake();
	}
}
