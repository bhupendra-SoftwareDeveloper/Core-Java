package march_25;

class Circle 
{
	double radius;

	public Circle()
	{
		super();
	}

	public Circle(double radius)
	{
		super();
		this.radius = radius;
	}
	
	double getArea()
	{
		if(radius<0) return -1;
		else return 3.14*radius*radius;
	}
}

class Cylender extends Circle
{
	double height;

	public Cylender()
	{
		super();
	}

	public Cylender(double radius, double height)
	{
		super(radius);
		this.height = height;
	}
	double getVolume()
	{
		if(height<0) return -1;
		else  return 3.14*radius*radius*height;
	}
}

public class Tester_Circle_Cylender_Prog1
{
	public static void main(String[] args)
	{
		Circle c=new Circle(5);
		System.out.println("Area of the Circle: "+c.getArea());
		Cylender cy=new Cylender(10,20);
		System.out.println("Volume of the Cylender: "+cy.getVolume());
	}
}
