package march_26_Exam;
public abstract class Cake2
{
		private String shape;
		private String flavour;
		private int qty;
		private float price;
		
		
		public Cake2()
		{
			super();
		}

		protected Cake2(String shape, String flavour, int qty)
		{
			super();
			this.shape = shape;
			this.flavour = flavour;
			this.qty = qty;
		}

		protected String getShape() {
			return shape;
		}

		protected void setShape(String shape) {
			this.shape = shape;
		}

		protected String getFlavour() {
			return flavour;
		}

		protected void setFlavour(String flavour) {
			this.flavour = flavour;
		}

		protected int getQty() {
			return qty;
		}

		protected void setQty(int qty) {
			this.qty = qty;
		}

		protected float getPrice() {
			return price;
		}

		protected void setPrice(float price) {
			this.price = price;
		}
		
		protected void showCake()
		{
			System.out.println("A "+getFlavour()+" Cake Of "+getQty()+" Kg's "+"@ Rs."+getPrice()*getQty()+"/-");
		}
	}
