package march_26_Exam;
import java.util.Scanner;
abstract class Book
{
	String title="";
	abstract void  setTitle(String s);
	String getTitle()
	{
		return "The title of my book is : "+title;
	}
}
class MyBook extends Book
{
	@Override
	public void setTitle(String s)
	{
		title=s;
		System.out.println(getTitle());
	}
}
public class Tester_Book_MyBook
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Book mb=new MyBook();
		System.out.println("Enter Book Title: ");
		mb.setTitle(sc.nextLine());
	}
}
