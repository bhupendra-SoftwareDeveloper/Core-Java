package march_26_Exam;
import java.util.Scanner;
abstract class Student
{
	protected String studentName;
	protected String studentClass;
	protected static int totalNoOfStudents; 
	
	public abstract int getPercentage( );
	
	public static int getTotalNoStudents()
	{
		return totalNoOfStudents;
	}
	
	public Student()
	{
		super();
	}
	
	public Student(String studentName, String studentClass)
	{
		super();
		this.studentName = studentName;
		this.studentClass = studentClass;
		totalNoOfStudents++;
	}
}

class ScienceStudent extends Student
{
	private int physicsMarks; 
	private int chemistryMarks;
	private int mathsMarks;
	
	public ScienceStudent()
	{
		super();
	}
	
	public ScienceStudent(String studentName, String studentClass, int physicsMarks, int chemistryMarks,
			int mathsMarks)
	{
		super(studentName, studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}

	public int getPercentage()
	{
		return (physicsMarks+chemistryMarks+mathsMarks)/3;
	}
}
class HistoryStudent extends Student
{
	private int historyMarks;
	private int civicsMarks;
	
	public HistoryStudent()
	{
		super();
	}
	
	public HistoryStudent(String studentName, String studentClass, int historyMarks, int civicsMarks)
	{
		super(studentName, studentClass);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}

	public int getPercentage()
	{
		return (historyMarks+civicsMarks)/2;
	}
}

public class Tester_Student_Prog04
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("***Science Class***\nEnter Student Name\nEnter Class\nEnter Physics Marks\nEnter Chemistry Marks\nEnter Maths Marks");
		ScienceStudent sci=new ScienceStudent(sc.nextLine(),sc.nextLine(),sc.nextInt(),sc.nextInt(),sc.nextInt());
		System.out.println(sci.getPercentage());
		sc.nextLine();
		System.out.println("***History Class***\nEnter Student Name\nEnter Class\nEnter History Marks\nEnter Civics Marks");
		HistoryStudent hi=new HistoryStudent(sc.nextLine(),sc.nextLine(),sc.nextInt(),sc.nextInt());
		System.out.println(hi.getPercentage());
		System.out.println("Total Students: "+sci.getTotalNoStudents());
	}
}
