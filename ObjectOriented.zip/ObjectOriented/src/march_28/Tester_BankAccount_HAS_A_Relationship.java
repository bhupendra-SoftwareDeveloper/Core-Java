package march_28;

class Account
{
	Customer customer;	//Has-A Relationship
	double balance;
	int accountNo;
	float interestRate;
	
	void deposite(double amount)
	{
		balance+=amount;
	}
	void withdraw(double amount)
	{
		if(amount<balance)
			balance-=amount;
	}
	
	public Account() {
		super();
	}
	
	public Account(Customer customer, double balance, int accountNo, float interestRate) {
		super();
		this.customer = customer;
		this.balance = balance;
		this.accountNo = accountNo;
		this.interestRate = interestRate;
	}
	@Override
	public String toString() {
		return "Account [customer=" + customer + ", balance=" + balance + ", accountNo=" + accountNo + ", interestRate="
				+ interestRate + "]";
	}
	
}

class Customer
{
	String firstName;
	String lastName;
	
	protected String getFirstName() {
		return firstName;
	}
	protected void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	protected String getLastName() {
		return lastName;
	}
	protected void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Customer() {
		super();
	}
	public Customer(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + "]";
	}
	
}

public class Tester_BankAccount_HAS_A_Relationship
{
	public static void main(String[] args)
	{
		Customer cus=new Customer("Chiranjeev","Das");
		Account ac=new Account(cus,1000,2745215,4);
		ac.deposite(500);
		ac.withdraw(100);
		System.out.println(ac);
	}
}
