package march_28;
class Customer02
{
	private String customerName;
	private int creditPoints;
	
	public Customer02()
	{
		super();
	}
	
	public Customer02(String customerName, int creditPoints)
	{
		super();
		this.customerName = customerName;
		this.creditPoints = creditPoints;
	}
	
	public int getCreditPoints()
	{
		return creditPoints;
	}
	
	protected String getCustomerName() {
		return customerName;
	}

	protected void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	protected void setCreditPoints(int creditPoints) {
		this.creditPoints = creditPoints;
	}

	@Override
	public String toString()
	{
		return "Customer '" + customerName;
	}
}

class CardType
{
	private Customer02 customer; 
	private String cardType;
	
	public CardType()
	{
		super();
	}

	public CardType(Customer02 customer, String cardType)
	{
		super();
		this.customer = customer;
		this.cardType = cardType;
	}
	
	protected Customer02 getCustomer() {
		return customer;
	}

	protected void setCustomer(Customer02 customer) {
		this.customer = customer;
	}

	protected String getCardType() {
		return cardType;
	}

	protected void setCardType(String cardType) {
		this.cardType = cardType;
	}

	@Override
	public String toString()
	{
		return customer+"'"+" Is Eligible For '" + cardType+"' Card";
	}
}

class CardsOnOffer
{
	public static CardType getOfferedCard(Customer02 c)
	{
		CardType ctype=new CardType();
		ctype.setCustomer(c);
		if(c.getCreditPoints()>99&&c.getCreditPoints()<501) ctype.setCardType("Silver");
		else if(c.getCreditPoints()>500&&c.getCreditPoints()<1001)ctype.setCardType("Gold");
		else if(c.getCreditPoints()>1001)ctype.setCardType("Platinum");
		else ctype.setCardType("EMI");
	
		return ctype;
	}
}

public class Tester_CreditCard_Prog02
{
	public static void main(String[] args)
	{
		Customer02 cust=new Customer02();
		cust.setCustomerName("Umakaant");
		cust.setCreditPoints(600);
		System.out.println(CardsOnOffer.getOfferedCard(cust));
	}
}