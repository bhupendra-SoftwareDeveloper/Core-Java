package march_28;
class Person
{
	int age;
	String name;
	Address address;
	public Person()
	{
		super();
	}
	public Person(int age, String name, Address address)
	{
		super();
		this.age = age;
		this.name = name;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", address=" + address + "]";
	}
	
}
class Address
{
	private String doorNo,street,city;

	protected String getDoorNo() {
		return doorNo;
	}

	protected void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}

	protected String getStreet() {
		return street;
	}

	protected void setStreet(String street) {
		this.street = street;
	}

	protected String getCity() {
		return city;
	}

	protected void setCity(String city) {
		this.city = city;
	}

	public Address()
	{
		super();
	}

	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", street=" + street + ", city=" + city + "]";
	}
	
}
public class Tester_PersonAddress
{
	public static void main(String[] args)
	{
		Address add=new Address();
		add.setDoorNo("207");
		add.setStreet("Ameeerpet");
		add.setCity("Hyderabad");
		Person p=new Person(20,"Yash",add);
		System.out.println(p);
	}
}
