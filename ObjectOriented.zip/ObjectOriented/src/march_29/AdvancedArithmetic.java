package march_29;

public interface AdvancedArithmetic
{
	public abstract int divisorSum(int n);
}
