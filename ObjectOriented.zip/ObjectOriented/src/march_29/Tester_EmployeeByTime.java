package march_29;
abstract class EmployeeAbstract
{
	private int id;
	private String name;
	abstract double computeSalary();
	public EmployeeAbstract()
	{
		super();
	}
	public EmployeeAbstract(int id, String name)
	{
		super();
		this.id = id;
		this.name = name;
	}
	protected int getId() {
		return id;
	}
	protected void setId(int id) {
		this.id = id;
	}
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	
}

class FullTimeEmployee extends EmployeeAbstract
{
	private double salary; 
    private static final double BONUS=2000;
    
    public double computeSalary()
	{
		return salary+BONUS;
	}

	public FullTimeEmployee()
	{
		super();
	}

	public FullTimeEmployee(int id, String name, double salary)
	{
		super(id, name);
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "FullTimeEmployee -> Name:"+getName()+", Id: "+getId()+", Salary=" + computeSalary();
	}

	
}

class PartTimeEmployee extends EmployeeAbstract
{
	 private int working_hours;
	 private double wagePerHours;
	 
	 public double computeSalary()
	 {
		return working_hours*wagePerHours;
	 }

	public PartTimeEmployee()
	{
		super();
	}

	public PartTimeEmployee(int id, String name, int working_hours, double wagePerHours)
	{
		super(id, name);
		this.working_hours = working_hours;
		this.wagePerHours = wagePerHours;
	}

	@Override
	public String toString() {
		return "PartTimeEmployee -> Working_hours=" + working_hours + ", WagePerHours=" + wagePerHours + ", Total : "+computeSalary();
	}
	
}
public class Tester_EmployeeByTime
{
	public static void main(String[] args)
	{
		FullTimeEmployee fm=new FullTimeEmployee(45,"Chiranjeev",45000);
		System.out.println(fm);
		System.out.println();
		PartTimeEmployee pm=new PartTimeEmployee(69,"Bhupendra",2,1500);
		System.out.println(pm);
	}
}
