package march_29;

/*
 This exercise is to understand how to implement abstract class.

Now your task is to define the classes with respective specifications as given below.

Define an abstract class 'Shape' with following specifications

Methods:
	1. Name: getArea
	   ReturnType: double
	   Modifier: abstract

	2. Name: printDetails
	   ReturnType: double
	   Modifier: abstract

Define sub-classes of Shape as Rectangle, Circle, Triangle that overrides the methods of shape

1. class name: Rectangle

Fields:
	1. length - double
	2. breath - double

Constructors:
	A parametrized constructor the accepts and initializes length and breath.


2. class name: Circle

Fields:
	1. radius - double
	
Constructors:
	A parametrized constructor the accepts and initializes radius.

3. class name: Triangle

Fields:
	1. base - double
	2. height - double

Constructors:
	A parametrized constructor the accepts and initializes base and height.



All the sub-classes of Shape should override the methods of the shape.
getArea() should return the area of the respective shape.
printDetails() should print the shape details as below

	input:  Rectangle(30.3, 45.4)

	output:
		Type = Rectangle
		Length = 30.3
		Breadth = 45.4
		Area = 1375.62


	input: Circle(23.2)

	output:
		Type = Circle
		Radius = 23.2
		Area = 1690.0736

	input: Triangle(146.2, 40.0);

	output:
		Type = Triangle
		Base = 146.2
		Height = 40.0
		Area = 2924.0


Given a class Testing with main method to test your code.

 */
abstract class Shape
{
	abstract double getArea();
	abstract void printDetails();
}

class Rectangle extends Shape
{
	double length;
	double bredth; 
	public double getArea()
	{
		return length*bredth;
	}
	public void printDetails()
	{
		System.out.println("Type = Rectangle\nLength = "+length+"\nBreadth = "+bredth+"\nArea = "+getArea());
	}
	
	public Rectangle(double length, double bredth)
	{
		super();
		this.length = length;
		this.bredth = bredth;
	}
}

class Circle extends Shape
{
	double radius;
	public double getArea()
	{
		return 3.14*radius*radius;
	}
	public void printDetails()
	{
		System.out.println("Type = Circle\nRadius = "+radius+"\nArea = "+getArea());
	}
	
	public Circle(double radius)
	{
		super();
		this.radius = radius;
	}
}

class Triangle extends Shape
{
	double base;
	double height;
	
	public double getArea()
	{
		return (base*height)/2;
	}
	public void printDetails()
	{
		System.out.println("Type = Triangle\nBase = "+base+"\nHeight = "+height+"\nArea = "+getArea());

	}
	
	public Triangle(double base, double height)
	{
		super();
		this.base = base;
		this.height = height;
	}
	
}
public class Tester_Shapes
{
	public static void main(String[] args)
	{
		new Rectangle(30.3, 45.4).printDetails();
		System.out.println("----------------------------");
		new Circle(23.2).printDetails();
		System.out.println("----------------------------");
		new Triangle(146.2,45).printDetails();
		System.out.println("----------------------------");
	}
}
