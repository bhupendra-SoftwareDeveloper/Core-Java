package basic;

public class Employee
{
	int eid;
	String name;
	static String companyName="Suresh It";
	
	void department(String dept)
	{
		System.out.println("Company Name: "+companyName);
		System.out.println("Employee Id: "+eid);
		System.out.println("Employee Name: "+name);
		System.out.println("Department Name: "+dept);
	}
	
	static void workHours()
	{
		System.out.println("Work Timing 9Am To  6pm");
	}
	
	public static void main(String[] args)
	{
		Employee ram=new Employee();
		ram.eid=100;
		ram.name="Ram";
		ram.department("cashier");
		workHours();
		System.out.println();
		
		Employee lakshman=new Employee();
		lakshman.eid=101;
		lakshman.name="Lakshman";
		lakshman.department("Designer");
		workHours();
	}
}
