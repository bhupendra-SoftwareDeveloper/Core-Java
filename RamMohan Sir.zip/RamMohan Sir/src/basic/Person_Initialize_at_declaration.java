package basic;

public class Person_Initialize_at_declaration
{
	String name="Ram";
	int age=40;
	
	public void talking()
	{
		System.out.println("My name is: "+name);
		System.out.println("My age is: "+age);
	}
	
	public static void main(String[] args)
	{
		Person_Initialize_at_declaration ram=new Person_Initialize_at_declaration();
		ram.talking();
		
		Person_Initialize_at_declaration seeta=new Person_Initialize_at_declaration();
		seeta.talking();
		Person_Initialize_at_declaration ravi=new Person_Initialize_at_declaration();
		ravi.talking();
	}
}
