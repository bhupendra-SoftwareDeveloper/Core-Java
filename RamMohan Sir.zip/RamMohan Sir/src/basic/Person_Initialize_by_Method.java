package basic;

public class Person_Initialize_by_Method
{
	String name;
	int age;
	
	public void assign(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	public void talking()
	{
		System.out.println("My name is: "+name);
		System.out.println("My age is: "+age);
	}
	
	public static void main(String[] args)
	{
		Person_Initialize_by_Method ram=new Person_Initialize_by_Method();
		ram.assign("Ram", 45);
		ram.talking();
	}
}
