package basic;

public class Person_Initialize_by_reference
{
	String name;
	int age;
	
	public void talking()
	{
		System.out.println("My name is: "+name);
		System.out.println("My age is: "+age);
	}
	
	public static void main(String[] args)
	{
		Person_Initialize_by_reference ram=new Person_Initialize_by_reference();
		ram.name="Ram";
		ram.age=40;
		ram.talking();
		
		Person_Initialize_by_reference seeta=new Person_Initialize_by_reference();
		seeta.name="Seeta";
		seeta.age=35;
		seeta.talking();
		
		Person_Initialize_by_reference ravi=new Person_Initialize_by_reference();
		ravi.name="Ravi";
		ravi.age=25;
		ravi.talking();
	}
}
