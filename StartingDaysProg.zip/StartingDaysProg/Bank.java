public class Bank
{
    static String name="SBI";
    static String ifsc="SBIN0010947";
    static String branch="Pandesara";
    public void m1(String h,String ac,String mob)
    {
	System.out.println("Account Holder Name:"+h);
	System.out.println("Account Number:"+ac);
	System.out.println("Holder Mob Number:"+mob);
    }
   public void m2()
   {
       System.out.println();
   }  
   public static void main(String ag[])
   {
    System.out.println("Bank Name:"+name);
    System.out.println("Bank Branch Name:"+branch);
    System.out.println("IFSC code:"+ifsc);
    Bank ob=new Bank();
    ob.m2();
    ob.m1("Rajesh","27642642512","9652413652");
    ob.m2();
    ob.m1("Rajeshwari","27632541350","6985761231");
   }
} 