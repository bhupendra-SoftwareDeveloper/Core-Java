package Basic;

public class Class0402
{
    void m1()
     {
        System.out.println("Method 1() Called");
     }
 public static void main(String arfs[])
 {
   Class0402 obj1=new Class0402();
   Class0402 obj2=new Class0402();

   System.out.println("hashCode of obj1=="+obj1.hashCode());
   System.out.println("hashCode of obj2=="+obj2.hashCode());
   
   System.out.println("equals=="+obj1.equals(obj2));
   System.out.println("equals=="+obj2.equals(obj2));

   System.out.println("getClass=="+obj1.getClass());

   System.out.println("toString=="+obj1.toString());
 }
}