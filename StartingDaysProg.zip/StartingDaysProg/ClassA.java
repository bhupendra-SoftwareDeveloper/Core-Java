package Basic;

public class ClassA
{
  public void meth1()
  {
	System.out.println("Hello this is Class A meth1()");
  }
  public void meth2()
  {
	System.out.println("Hello this is Class A meth2()");
  }
}
class ClassB
{
  public void meth1()
  {
	System.out.println("Hello this is Class B meth1()");
  }
  public void meth2()
  {
	System.out.println("Hello this is Class B meth2()");
  }
}