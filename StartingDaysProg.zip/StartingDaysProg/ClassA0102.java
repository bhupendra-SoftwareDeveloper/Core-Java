package Basic;
public class ClassA0102
{
	public void meth1()
	{
	  System.out.println("Hii");
	}
}