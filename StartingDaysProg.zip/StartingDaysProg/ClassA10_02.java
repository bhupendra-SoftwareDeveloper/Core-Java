package Basic;
public ClassA10_02
{
	int a=10;
	static int b=20;
	int x=50;
	int y;
	static int m=50;
	static int n;
  void m1()
   {
     int c=30;
     int x=100;
     int m=500;
     int i;
     System.out.println("Instance Variable a"+a);
     System.out.println("Static Variable b"+b);
     System.out.println("Local Variable c"+c);

     System.out.println("====Instance Variable====");
     System.out.println("Instance Variable X"+new ClassA10_02().x);  
     System.out.println("Local Variable X"+x);

     System.out.println("Instance Variable Y"+y);
  
     System.out.println("====Static Variable====");
     System.out.println("Static Variable n"+n);
 
     System.out.println("Loacl Variable m"+m);
     System.out.println("Static Variable m"+new ClassA10_02A().m);
     System.out.println("Static Variable m"+ClassA10_02.m);

     System.out.println("====Local Variable====");
   }
  void m2()
   {
     System.out.println("Instance Variable a"+a);
     System.out.println("Static Variable b"+b);
   }
public static void main(String oooi[])
{
  ClassA10_02A obj=new ClassA10_02A();
         obj.m1();
         obj.m2();
} 