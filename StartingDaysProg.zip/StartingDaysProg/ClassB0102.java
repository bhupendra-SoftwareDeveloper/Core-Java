package Basic;
public class ClassB0102
{
	public void meth2()
	{
	   System.out.println("Hello");
	}
	public static void main(String afg[])
	{
	  new ClassA0102().meth1();
	}
}