package Basic2;
import Basic.ClassA;
public class ClassC
{
  public static void main(String argd[])
  {
	new ClassA().meth2();
  }
}