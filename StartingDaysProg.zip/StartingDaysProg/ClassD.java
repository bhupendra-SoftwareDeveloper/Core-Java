package Basic;
public class ClassD{
public static void main(String[] ar){
System.out.println("HI");
}
}