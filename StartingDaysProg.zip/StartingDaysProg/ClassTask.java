public class ClassTask
{
  static int a=0;
         int b=0;

   ClassTask()
   {
     a++;
     b++;
     System.out.println("Static variable="+a);	//1-->1 ,4-->2 ,7-->3 ,11-->4 ,17-->5
     System.out.println("Instance variable="+b);   //2-->1 ,5-->1 ,8-->1 ,12-->1 ,18-->1 
     System.out.println("------------------------"); //3,6,9,13,19
    }

   void display()
   {
     System.out.println("****Accessing Static Variable****"); //14
     System.out.println(ClassTask.a); 	//15-->4
     System.out.println(a); 	//16-->4
     System.out.println(new ClassTask().a); //20-->5 
   }

  public static void main(String argd[])
  {
    new ClassTask();
    new ClassTask();
    new ClassTask();
    System.out.println("##############################");  //10
    new ClassTask().display();
  }
}