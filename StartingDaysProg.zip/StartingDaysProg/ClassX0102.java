package Basic2;
import Basic.ClassA0102;
import Basic.ClassB0102;

public class ClassX0102
{
	public static void main(String ag[])
	{
	   new ClassA0102().meth1();
	   new ClassB0102().meth2();
	}
}