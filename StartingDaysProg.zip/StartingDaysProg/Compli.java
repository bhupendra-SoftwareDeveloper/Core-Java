package Basic;
public class Compli
{
   void m1()
   {
     int a=9,b=-4;
	System.out.println("1.A="+a);
	System.out.println("2.B="+b);
	System.out.println("3.A="+~a);
	System.out.println("4.B="+~b);
	System.out.println("5.A="+(~a++));
	System.out.println("6.B="+(~++b));
	System.out.println("7.A="+(~++a));
	System.out.println("8.B="+(~b++));
	System.out.println("9.A="+(++a));
	System.out.println("10.B="+(++b));
	int c=b;
	System.out.println("11.C="+c);
	System.out.println("12.C="+~c);
	System.out.println("13.C="+(~c++));
	System.out.println("14.C="+(~++c));

    }
public static void main(String args[])
  {
    new Compli().m1();
  }}