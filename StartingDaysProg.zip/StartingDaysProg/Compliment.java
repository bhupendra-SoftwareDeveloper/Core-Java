package Basic;
public class Compliment
{
  void m1()
  {
    int a=10;int b=-10;
	System.out.println("a1="+a);
	System.out.println("b2="+b);
	System.out.println("a3="+(~a));
	System.out.println("b4="+(~b));
	System.out.println("a5="+(~++a));
	System.out.println("b6="+(~++b));
	System.out.println("a7="+(~a++));//12
	System.out.println("b8="+(~b++));
	int c=a;	
	System.out.println("c9="+c);
	System.out.println("c10="+(~c));
	System.out.println("c11="+(~++c));
	System.out.println("c12="+(~c++));
  }
public static void main(String areg[])
 {
   new Compliment().m1();}}