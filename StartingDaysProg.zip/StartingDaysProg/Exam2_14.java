public class Exam2_14
{
  public static void main(String afr[])
  {
   int i=1;
   for(System.out.println("Hii");i<=3;i++)
   {
    System.out.println("Hello");
   }
  }
}