public class Exam2_18
{
	public static void main(String[] args)
	{
	   System.out.println('j'+'a'+'v'+'a');
	}
}