public class Exam2_19
{
	public static void main(String args)
	{
		System.out.println("Good Morning");
	}
	public static void main(String[] args)
	{
		System.out.println("Good Night");
	}
}