public class Exam3_15
{
  Exam3_15()
  {
    new Exam3_15(5);
    System.out.println("The Default Constructor");
  }
 
 Exam3_15(int x)
  {
    new Exam3_15(5,15);
    System.out.println(x);
  }

  Exam3_15(int x,int y)
  {
    System.out.println(x*y);
  }

public static void main(String arg[])
 {
   new Exam3_15();
  }
}