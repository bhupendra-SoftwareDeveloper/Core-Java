public class Exam3_16
{
  int id;
  String name;
 
 Exam3_16(int i,String n)
 {
  id=i;
  name=n;
 }
Exam3_16(Exam3_16 c)
 {
  id=c.id;
  name=c.name;
 } 
 void display()
 {
   System.out.println(id+" "+name);
 }

public static void main(String args[])
 {
   Exam3_16 c1= new Exam3_16(100,"Joy");
   Exam3_16 c2= new Exam3_16(c1);
   c1.display();
   c2.display();
 }
}