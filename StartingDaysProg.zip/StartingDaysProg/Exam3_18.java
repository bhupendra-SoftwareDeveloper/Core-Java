public class Exam3_18
{
  int rollNo=123; static int code=456;
  public static void main(String srg[])
  {
    Exam3_18 stu=new Exam3_18();
    System.out.println(stu.rollNo);
    System.out.println(stu.code);
    System.out.println(rollNo);
    }
}