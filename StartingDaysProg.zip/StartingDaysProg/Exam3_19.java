public class Exam3_19
{
  int x=12;
  static int y=45;
  void m1()
  {
    System.out.println("Instance method");
  }
  void m2()
  {
    System.out.println(x);
    new Exam3_19().m1();
    System.out.println(y);
    new Exam3_19().m3();
    System.out.println("Instance method");
  }
 static void m3()
  {
    System.out.println("Static method");
  }
public static void main(String gh[])
 {
   System.out.println(y);
   new Exam3_19().m3();
   Exam3_19 a=new Exam3_19();
   System.out.println(a.x);
   a.m2();
 }
}