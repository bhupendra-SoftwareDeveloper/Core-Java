public class Exam3_20
{
  int x;
  static int y;
  public static void main(String agf[])
  {
   Exam3_20 stu1=new Exam3_20();
   stu1.x++;
   stu1.y++;
   System.out.println(stu1.x+" "+stu1.y);

   Exam3_20 stu2=new Exam3_20();
   stu2.x++;
   stu2.y++;
   System.out.println(stu2.x+" "+stu2.y);

   Exam3_20 stu3=new Exam3_20();
   stu3.x++;
   stu3.y++;
   System.out.println(stu3.x+" "+stu3.y);
  }
}