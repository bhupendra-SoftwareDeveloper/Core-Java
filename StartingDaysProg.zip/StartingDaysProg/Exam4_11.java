class Exam4_11
{
  static int a=10;
  static{
          System.out.println(a);
	  System.out.println(getB());
        }
 public static void main(String args[])
 {
   System.out.println(a);
   System.out.println(b);
  }
 static int getB()
  {
    return b;
  }
 static int b=20;
}