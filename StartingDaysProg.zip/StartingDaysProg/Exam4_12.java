public class Exam4_12
{
  static int a=10;
 public static void main(String args[])
 {
   Exam4_12 t1=new Exam4_12();
   Exam4_12 t2=new Exam4_12();
   
   System.out.println(t1.a);
   System.out.println(t2.a);
   int a=20;
   System.out.println(t1.a);
   System.out.println(t2.a);
 }
}