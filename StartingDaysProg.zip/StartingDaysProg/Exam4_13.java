public class Exam4_13
{
  public static void main(String args[])
  {
    int x=1,y=2,z=5;
   System.out.println("x:"+(!((x+2)==(1+2))));
   System.out.println("y:"+(!(y==z)));
   System.out.println("z>x:"+(!(z>x)));
  
   if(!(x==y)&&((y+5)>z)&&(!((z-3)==0)))
   {
    System.out.println("Hello");
   }
 }
}