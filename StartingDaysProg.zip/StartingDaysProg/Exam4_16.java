public class Exam4_16
{
  public static void main(String args[])
  {
    Exam4_16 tc= new Exam4_16();
  }
 
 Exam4_16()
  {
    this(5,6);
    System.out.println("Called 1st Constructor");
  }

 Exam4_16(int a)
  {
    System.out.println("Called 2nd Constructor");
  }

 Exam4_16(int a,int b)
  {
    this(5);
    System.out.println("Called 3rd Constructor");
  }
}