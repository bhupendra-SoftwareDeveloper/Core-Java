public class Exam4_3
{
  public static void main(String args[])
  {
    long l=30;
    int i=50;
    short s=60;
    byte b=70;
    int sum=l+i+s+b;
    System.out.println("Sum="+sum);
   }
}