public class Exam4_4
{
  int c;
  static int e;
  Exam4_4()
  {
    System.out.println(++c);
    System.out.println(++e);
  }
public static void main(String argd[])
{
  int a=34;
  int b=21;
  
  new Exam4_4().c-=a++ + ++b;
  int d=--a + --b + new Exam4_4().c--;
  e=a + +b + +new Exam4_4().c+d--;
  int f=-a + b-- + -new Exam4_4().c-d++;
  int sum=a+b+new Exam4_4().c+d+e+f;
  System.out.println("Sum="+sum);
 }
}