class Lab 
{
  public static void m1(char c1)
  {
	char c=Character.toLowerCase(c1);
	if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')

		System.out.println("VOWEL");
	else
		System.out.println("CONSONANTS");
  }  

  public static void main(String arg[])
  {
   	m1('Z');
  }
}
