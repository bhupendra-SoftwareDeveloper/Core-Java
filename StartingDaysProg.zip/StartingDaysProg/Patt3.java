package pattern;
public class Patt3
{
  public static void main(String arg[])
  {int a,n=5,i,j;
	for(i=1;i<=n;i++)
	{a=64;
	   for(j=1;j<=i;j++)
	    {
		System.out.printf("%c",a+i);
		a--;
	    }
	System.out.println();
	}
  }
}