package LabTask;
class Person
{
 //instance variables
 String name;
 int age;
 char sex;
 //To initialize variables with parameterized constructor
 public Person(String name, int age, char sex)
 {
  this.name = name;
  this.age = age;
  this.sex = sex;
 }
 public void display()
 {
  System.out.println("Name: "+name);
  System.out.println("Age: "+age);
  System.out.println("Sex: "+sex);
 }
 Person modify(Person p)
 {
  p.name = "john";
  p.age = 27;
  p.sex = 'M';
  return p;
 }
}
 
public class InstanceMethodsDemo
{
 public static void main(String args[]) throws Exception
 {
  Person p = new Person("shaki", 24, 'F');
  p.display();
  Person p1 = p.modify(p);
  p1.display();
  Person p2 = p1.modify(new Person("murugan", 25, 'M'));
  p2.display();
 }
}
