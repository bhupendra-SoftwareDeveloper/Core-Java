package Basic2;
import Basic.ClassA;
import Basic.Prac;

public class Pr
{
   public static void main(String arhs[])
   {
    new Prac().m1();
    new ClassA().meth1();
    new ClassA().meth2(); 
   }
}