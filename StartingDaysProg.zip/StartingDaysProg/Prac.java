package Basic;

public class Prac
{
   public void m1()
   {
	System.out.println("Hello this is method1() of Prac class of basic package");
  	new Prac2().m1();
	new Prac4().m1();
   }
class Prac2
{
   public void m1()
   {
	System.out.println("Hello this is method1() of Prac2 class of basic package");
   }
   public void m2()
   {
	System.out.println("Hello this is method2() of Prac2 class of basic package");
   }
}
class Prac3
   {
     public void m1()
     {
	System.out.println("Hello this is method1() of Prac3 class of basic package");
     }
   }
class Prac4
   {
     public void m1()
     {
	System.out.println("Hello this is method1() of Prac4 now");
     }
   }
}